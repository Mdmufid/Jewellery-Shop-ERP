import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext.jsx';
import { ToastProvider } from './context/ToastContext.jsx';
import Layout from './components/Layout.jsx';
import Login from './pages/Login/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import RateMaster from './pages/RateMaster/RateMaster.jsx';
import InventoryList from './pages/Inventory/InventoryList.jsx';
import BarcodeLabels from './pages/Inventory/BarcodeLabels.jsx';
import Billing from './pages/Billing/Billing.jsx';
import InvoiceHistory from './pages/Billing/InvoiceHistory.jsx';
import InvoiceView from './pages/Billing/InvoiceView.jsx';
import Customers from './pages/Customers/Customers.jsx';
import CustomerDetail from './pages/Customers/CustomerDetail.jsx';
import Suppliers from './pages/Suppliers/Suppliers.jsx';
import SupplierDetail from './pages/Suppliers/SupplierDetail.jsx';
import Purchases from './pages/Purchases/Purchases.jsx';
import NewPurchase from './pages/Purchases/NewPurchase.jsx';
import Karigar from './pages/Artisans/Artisans.jsx';
import KarigarDetail from './pages/Artisans/ArtisanDetail.jsx';
import OldGold from './pages/OldGold/OldGold.jsx';
import Repairs from './pages/Repairs/Repairs.jsx';
import Reports from './pages/Reports/Reports.jsx';
import Settings from './pages/Settings/Settings.jsx';
import NewSupplier from './pages/Suppliers/NewSupplier';

function RequireAuth({ children }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/*"
        element={
          <RequireAuth>
            <Layout>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/rates" element={<RateMaster />} />
                <Route path="/inventory" element={<InventoryList />} />
                <Route path="/inventory/barcodes" element={<BarcodeLabels />} />
                <Route path="/billing" element={<Billing />} />
                <Route path="/billing/history" element={<InvoiceHistory />} />
                <Route path="/billing/history/:id" element={<InvoiceView />} />
                <Route path="/customers" element={<Customers />} />
                <Route path="/customers/:id" element={<CustomerDetail />} />
                <Route path="/suppliers" element={<Suppliers />} />
                <Route path="/suppliers/new" element={<NewSupplier />} />  {/* Add this line! */}
                <Route path="/suppliers/:id" element={<SupplierDetail />} />
                <Route path="/purchases" element={<Purchases />} />
                <Route path="/purchases/new" element={<NewPurchase />} />
                <Route path="/karigar" element={<Karigar />} />
                <Route path="/karigar/:id" element={<KarigarDetail />} />
                <Route path="/oldgold" element={<OldGold />} />
                <Route path="/repairs" element={<Repairs />} />
                <Route path="/reports" element={<Reports />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </Layout>
          </RequireAuth>
        }
      />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <AppRoutes />
      </ToastProvider>
    </AuthProvider>
  );
}
