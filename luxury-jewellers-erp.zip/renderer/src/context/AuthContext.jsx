import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);

  const refreshSettings = useCallback(async () => {
    const s = await window.api.settings.getAll();
    setSettings(s);
    return s;
  }, []);

  useEffect(() => {
    const stored = sessionStorage.getItem('lj_user');
    if (stored) setUser(JSON.parse(stored));
    refreshSettings().finally(() => setLoading(false));
  }, [refreshSettings]);

  const login = async (username, password) => {
    const u = await window.api.auth.login(username, password);
    setUser(u);
    sessionStorage.setItem('lj_user', JSON.stringify(u));
    return u;
  };

  const logout = () => {
    setUser(null);
    sessionStorage.removeItem('lj_user');
  };

  return (
    <AuthContext.Provider value={{ user, settings, loading, login, logout, refreshSettings }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
