import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

const NAV_ITEMS = [
  { to: '/', label: 'Dashboard', icon: '◆' },
  { to: '/billing', label: 'Billing / POS', icon: '₹' },
  { to: '/billing/history', label: 'Invoice History', icon: '≡' },
  { to: '/inventory', label: 'Inventory', icon: '◈' },
  { to: '/inventory/barcodes', label: 'Barcode Labels', icon: '▦' },
  { to: '/rates', label: 'Rate Master', icon: '⚖' },
  { to: '/customers', label: 'Customers', icon: '☺' },
  { to: '/suppliers', label: 'Suppliers', icon: '⌂' },
  { to: '/purchases', label: 'Purchases', icon: '⇩' },
  { to: '/karigar', label: 'Artisans / Job Work', icon: '⚒' },
  { to: '/oldgold', label: 'Old Gold Exchange', icon: '⟲' },
  { to: '/repairs', label: 'Repairs', icon: '✎' },
  { to: '/reports', label: 'Reports', icon: '▤' },
  { to: '/settings', label: 'Settings', icon: '⚙' },
];

export default function Layout({ children }) {
  const { user, settings, logout } = useAuth();
  const navigate = useNavigate();

  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('theme') || 'dark';
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <h1>{settings?.shop_name || 'Luxury Jewellers'}</h1>
          <span>Billing & Inventory</span>
        </div>
        <nav className="nav-group">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>
      </aside>
      <div className="main-area">
        <header className="topbar">
          <div />
          <div className="topbar-right" style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <button
              className="theme-toggle-btn"
              onClick={toggleTheme}
              style={{
                background: 'var(--bg)',
                border: '1px solid var(--border)',
                borderRadius: '50%',
                width: '34px',
                height: '34px',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '16px',
                color: 'var(--text)',
                boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
                transition: 'all 0.2s ease',
              }}
              title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {theme === 'dark' ? '☀️' : '🌙'}
            </button>
            <div className="user-chip">
              <span>{user?.fullName} &middot; {user?.role}</span>
              <button className="ghost" onClick={handleLogout}>Log out</button>
            </div>
          </div>
        </header>
        <main className="content">{children}</main>
      </div>
    </div>
  );
}
