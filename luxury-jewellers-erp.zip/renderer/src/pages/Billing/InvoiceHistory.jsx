import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useToast } from '../../context/ToastContext.jsx';

export default function InvoiceHistory() {
  const { showError } = useToast();
  const [invoices, setInvoices] = useState([]);
  const [search, setSearch] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  const load = () => {
    window.api.billing.list({ search: search || undefined, fromDate: fromDate || undefined, toDate: toDate || undefined })
      .then(setInvoices).catch(showError);
  };

  useEffect(() => { load(); }, [search, fromDate, toDate]);

  return (
    <div>
      <h2 className="page-title">Invoice History</h2>
      <p className="page-subtitle">All sales invoices generated from Billing.</p>

      <div className="toolbar">
        <input className="search-box" placeholder="Search invoice number..." value={search} onChange={(e) => setSearch(e.target.value)} />
        <input type="date" style={{ maxWidth: 160 }} value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
        <input type="date" style={{ maxWidth: 160 }} value={toDate} onChange={(e) => setToDate(e.target.value)} />
      </div>

      <div className="card" style={{ padding: 0 }}>
        <table>
          <thead>
            <tr><th>Invoice No</th><th>Date</th><th>Customer</th><th>Taxable</th><th>Tax</th><th>Grand Total</th><th>Status</th></tr>
          </thead>
          <tbody>
            {invoices.map((inv) => (
              <tr key={inv.id} style={{ cursor: 'pointer' }}>
                <td><Link to={`/billing/history/${inv.id}`}>{inv.invoice_number}</Link></td>
                <td>{inv.invoice_date}</td>
                <td>{inv.customer_name || 'Walk-in'}</td>
                <td className="mono">₹{inv.taxable_amount.toLocaleString('en-IN')}</td>
                <td className="mono">₹{(inv.cgst_amount + inv.sgst_amount + inv.igst_amount).toLocaleString('en-IN')}</td>
                <td className="mono">₹{inv.grand_total.toLocaleString('en-IN')}</td>
                <td>
                  <span className={`badge ${inv.status === 'COMPLETED' ? 'green' : 'red'}`}>{inv.status}</span>
                </td>
              </tr>
            ))}
            {invoices.length === 0 && <tr><td colSpan={7} className="muted center">No invoices found</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
