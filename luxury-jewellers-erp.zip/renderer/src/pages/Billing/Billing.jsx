import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';

function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }

const PAYMENT_MODES = ['CASH', 'CARD', 'UPI', 'BANK_TRANSFER', 'CHEQUE'];

export default function Billing() {
  const { user, settings } = useAuth();
  const { showToast, showError } = useToast();
  const navigate = useNavigate();

  // Mandatory Customer States
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [customerPan, setCustomerPan] = useState('');

  const [itemSearch, setItemSearch] = useState('');
  const [itemResults, setItemResults] = useState([]);
  const [cart, setCart] = useState([]);
  const [categories, setCategories] = useState([]);
  const [hsnCodes, setHsnCodes] = useState([]);
  const [rates, setRates] = useState([]);

  const [customerSearch, setCustomerSearch] = useState('');
  const [customerResults, setCustomerResults] = useState([]);
  const [customer, setCustomer] = useState(null);
  const [placeOfSupply, setPlaceOfSupply] = useState(settings?.shop_state_code || '27');

  const [pendingExchanges, setPendingExchanges] = useState([]);
  const [selectedExchangeIds, setSelectedExchangeIds] = useState([]);

  

  const [discount, setDiscount] = useState(0);
  const [payments, setPayments] = useState([{ amount: '', paymentMode: 'CASH', referenceNumber: '' }]);
  const [submitting, setSubmitting] = useState(false);

  // Load exchanges when a customer is selected
  useEffect(() => {
    if (customer?.id) {
      window.api.oldGold.pendingForCustomer(customer.id)
        .then(setPendingExchanges)
        .catch(showError);
    } else {
      setPendingExchanges([]);
      setSelectedExchangeIds([]);
    }
  }, [customer]);

  useEffect(() => {
    window.api.settings.listCategories().then(setCategories).catch(showError);
    window.api.settings.listHsnCodes().then(setHsnCodes).catch(showError);
    window.api.rates.getCurrent().then(setRates).catch(showError);
  }, []);

  useEffect(() => {
    if (settings?.shop_state_code) setPlaceOfSupply(settings.shop_state_code);
  }, [settings]);

  useEffect(() => {
    if (itemSearch.length < 1) { setItemResults([]); return; }
    const t = setTimeout(() => {
      window.api.inventory.list({ search: itemSearch, status: 'IN_STOCK' }).then(setItemResults).catch(showError);
    }, 200);
    return () => clearTimeout(t);
  }, [itemSearch]);

  useEffect(() => {
    if (customerSearch.length < 1) { setCustomerResults([]); return; }
    const t = setTimeout(() => {
      window.api.customers.list(customerSearch).then(setCustomerResults).catch(showError);
    }, 200);
    return () => clearTimeout(t);
  }, [customerSearch]);

  useEffect(() => {
    if (!customer) { setPendingExchanges([]); return; }
    window.api.oldGold.pendingForCustomer(customer.id).then(setPendingExchanges).catch(showError);
  }, [customer]);

  const hsnFor = (categoryId) => {
    const cat = categories.find((c) => c.id === categoryId);
    if (!cat) return null;
    return hsnCodes.find((h) => h.hsn_code === cat.hsn_code) || null;
  };

  const rateFor = (purityId) => {
    const r = rates.find((x) => x.id === purityId);
    return r ? r.rate_per_gram : 0;
  };

  const addItemToCart = (item) => {
    if (cart.some((c) => c.itemId === item.id)) { showError(new Error('Item already added to the bill')); return; }
    const hsn = hsnFor(item.category_id);

    // 1. Bulletproof Number Conversion (Catches undefined, null, or missing weights)
    const rawGross = Number(item.gross_weight ?? item.grossWeight ?? 0);
    const rawStone = Number(item.stone_weight ?? item.stoneWeight ?? 0);
    const rawStoneCharge = Number(item.stone_charge ?? item.stoneCharge ?? 0);
    
    // 2. Prevent division by zero
    const stockPcs = Number(item.pcs) > 0 ? Number(item.pcs) : 1; 

    // 3. Calculate safe unit weights
    const unitGrossWeight = rawGross / stockPcs;
    const unitStoneWeight = rawStone / stockPcs;
    const unitStoneCharge = rawStoneCharge / stockPcs;

    const line = {
      itemId: item.id,
      description: `${item.name} (${item.item_code})`,
      metalType: item.metal_type,
      purityName: item.purity_name,
      purityId: item.purity_id,
      
      pcs: 1, // Default UI to 1 piece
      unitGrossWeight: unitGrossWeight,
      unitStoneWeight: unitStoneWeight,
      unitStoneCharge: unitStoneCharge,
      
      ratePerGram: Number(rateFor(item.purity_id) ?? item.cost_rate_per_gram ?? 0),
      makingChargeType: item.making_charge_type || 'PER_GRAM',
      makingChargeValue: Number(item.making_charge_value ?? 0),
      wastagePercent: Number(item.wastage_percent ?? 0),
      
      // FIXED TAX RATES FOR JEWELRY
      hsnCode: hsn?.hsn_code || '7113', 
      cgstRate: 1.5, 
      sgstRate: 1.5, 
      igstRate: 3.0, 
      
      huidNumber: item.huid_number,
    };
    
    setCart((c) => [...c, line]);
    setItemSearch('');
    setItemResults([]);
  };

  const handleItemSearchKeyDown = async (e) => {
    if (e.key !== 'Enter') return;
    const query = itemSearch.trim();
    if (!query) return;

    const exactFromResults = itemResults.find((item) => String(item.item_code).toLowerCase() === query.toLowerCase());
    if (exactFromResults) {
      addItemToCart(exactFromResults);
      return;
    }

    if (itemResults.length === 1) {
      addItemToCart(itemResults[0]);
      return;
    }

    try {
      const exact = await window.api.inventory.getByCode(query);
      if (exact) {
        addItemToCart(exact);
        return;
      }
    } catch (err) {
      // Fall back to the list search result below.
    }

    showError(new Error('No matching item found for the scanned barcode'));
  };

  const updateLine = (idx, patch) => {
    setCart((c) => c.map((line, i) => (i === idx ? { ...line, ...patch } : line)));
  };

  const removeLine = (idx) => setCart((c) => c.filter((_, i) => i !== idx));

  const isInterstate = customer ? String(placeOfSupply) !== String(settings?.shop_state_code) : false;

  const computedLines = useMemo(() => cart.map((line) => {
    const pcs = Number(line.pcs) > 0 ? Number(line.pcs) : 1;
    
    // Multiply unit weights by the current number of pieces
    const currentGrossWeight = (Number(line.unitGrossWeight) || 0) * pcs;
    const currentStoneWeight = (Number(line.unitStoneWeight) || 0) * pcs;
    const currentStoneCharge = (Number(line.unitStoneCharge) || 0) * pcs;

    const netWeight = round2(currentGrossWeight - currentStoneWeight);
    const metalValue = round2(netWeight * (Number(line.ratePerGram) || 0));
    
    let makingCharge = 0;
    const rawMakingVal = Number(line.makingChargeValue) || 0;

    if (line.makingChargeType === 'PER_GRAM') makingCharge = round2(netWeight * rawMakingVal);
    else if (line.makingChargeType === 'FIXED') makingCharge = round2(rawMakingVal * pcs); // Multiply fixed charge by pcs
    else if (line.makingChargeType === 'PERCENTAGE') makingCharge = round2((metalValue * rawMakingVal) / 100);
    
    const wastageWeight = round2((netWeight * (Number(line.wastagePercent) || 0)) / 100);
    const wastageAmount = round2(wastageWeight * (Number(line.ratePerGram) || 0));
    const taxableValue = round2(metalValue + makingCharge + wastageAmount + currentStoneCharge);
    
    const cgstAmount = isInterstate ? 0 : round2((taxableValue * line.cgstRate) / 100);
    const sgstAmount = isInterstate ? 0 : round2((taxableValue * line.sgstRate) / 100);
    const igstAmount = isInterstate ? round2((taxableValue * line.igstRate) / 100) : 0;
    const lineTotal = round2(taxableValue + cgstAmount + sgstAmount + igstAmount);
    
    return { 
      ...line, 
      grossWeight: currentGrossWeight, // Update so the backend receives the scaled weight
      stoneWeight: currentStoneWeight,
      stoneCharge: currentStoneCharge,
      netWeight, 
      metalValue, 
      makingCharge: makingCharge + wastageAmount, 
      taxableValue, 
      cgstAmount, 
      sgstAmount, 
      igstAmount, 
      lineTotal 
    };
  }), [cart, isInterstate]);

  const subtotal = computedLines.reduce((s, l) => s + l.metalValue, 0);
  const totalMaking = computedLines.reduce((s, l) => s + l.makingCharge, 0);
  const totalStone = computedLines.reduce((s, l) => s + (l.stoneCharge || 0), 0);
  const taxableAmount = computedLines.reduce((s, l) => s + l.taxableValue, 0);
  const cgstTotal = computedLines.reduce((s, l) => s + l.cgstAmount, 0);
  const sgstTotal = computedLines.reduce((s, l) => s + l.sgstAmount, 0);
  const igstTotal = computedLines.reduce((s, l) => s + l.igstAmount, 0);

  const oldGoldValue = pendingExchanges.filter((e) => selectedExchangeIds.includes(e.id)).reduce((s, e) => s + e.total_value, 0);

  const beforeRound = round2(taxableAmount + cgstTotal + sgstTotal + igstTotal - (parseFloat(discount) || 0) - oldGoldValue);
  const grandTotal = Math.round(beforeRound);
  const roundOff = round2(grandTotal - beforeRound);
  const totalPaid = payments.reduce((s, p) => s + (parseFloat(p.amount) || 0), 0);
  const balanceDue = round2(grandTotal - totalPaid);

  const addPaymentRow = () => setPayments((p) => [...p, { amount: '', paymentMode: 'CASH', referenceNumber: '' }]);
  const updatePayment = (idx, patch) => setPayments((p) => p.map((row, i) => (i === idx ? { ...row, ...patch } : row)));
  const removePayment = (idx) => setPayments((p) => p.filter((_, i) => i !== idx));

  const resetForm = () => {
    setCart([]); setCustomer(null); setCustomerSearch(''); setSelectedExchangeIds([]); setDiscount(0); setPayments([{ amount: '', paymentMode: 'CASH', referenceNumber: '' }]);
    setCustomerName(''); setCustomerPhone(''); setCustomerAddress(''); setCustomerPan('');
  };

  const handleSubmit = async () => {
    if (cart.length === 0) { showError(new Error('Add at least one item to the bill')); return; }

    // STRICT CUSTOMER VALIDATION
    if (!customerName.trim() || !customerPhone.trim() || !customerAddress.trim() || !customerPan.trim()) {
      showError(new Error('Customer Name, Phone, Address, and PAN are strictly required to generate an invoice.'));
      return;
    }

    const paymentsPayload = payments.filter((p) => parseFloat(p.amount) > 0).map((p) => ({
      amount: parseFloat(p.amount), paymentMode: p.paymentMode, referenceNumber: p.referenceNumber || null,
    }));
    setSubmitting(true);
    
    try {
      // Validate server-side computed totals before creating invoice
      const payloadForCompute = {
        invoiceDate: new Date().toISOString().slice(0, 10),
        customerId: customer?.id || null,
        placeOfSupplyStateCode: placeOfSupply,
        shopStateCode: settings?.shop_state_code || '27',
        lineItems: computedLines.map((l) => ({
          itemId: l.itemId, description: l.description, hsnCode: l.hsnCode, metalType: l.metalType,
          purityName: l.purityName, grossWeight: l.grossWeight, stoneWeight: l.stoneWeight,
          pcs: l.pcs, // Ensure pieces scale properly
          ratePerGram: l.ratePerGram, makingChargeType: l.makingChargeType, makingChargeValue: l.makingChargeValue,
          wastagePercent: l.wastagePercent, stoneCharge: l.stoneCharge, cgstRate: l.cgstRate, sgstRate: l.sgstRate,
          igstRate: l.igstRate, huidNumber: l.huidNumber,
        })),
        oldGoldExchangeIds: selectedExchangeIds,
        discountAmount: parseFloat(discount) || 0,
        payments: paymentsPayload,
      };
      
      const serverCalc = await window.api.billing.compute(payloadForCompute);
      if (Math.round(serverCalc.grandTotal) !== Math.round(grandTotal) || Math.abs(serverCalc.roundOff - roundOff) > 0.01) {
        showError(new Error('Server-side computed totals differ from client preview. Please review line items or re-open billing.'));
        setSubmitting(false);
        return;
      }

      // Create the Invoice
      const invoice = await window.api.billing.create({
        invoiceDate: new Date().toISOString().slice(0, 10),
        customerId: customer?.id || null,
        
        // Pass strictly validated customer fields to backend
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        customerAddress: customerAddress.trim(),
        customerPan: customerPan.trim(),

        placeOfSupplyStateCode: placeOfSupply,
        shopStateCode: settings?.shop_state_code || '27',
        lineItems: computedLines.map((l) => ({
          itemId: l.itemId, description: l.description, hsnCode: l.hsnCode, metalType: l.metalType,
          purityName: l.purityName, grossWeight: l.grossWeight, stoneWeight: l.stoneWeight,
          pcs: l.pcs, // Passed properly to backend
          ratePerGram: l.ratePerGram, makingChargeType: l.makingChargeType, makingChargeValue: l.makingChargeValue,
          wastagePercent: l.wastagePercent, stoneCharge: l.stoneCharge, cgstRate: l.cgstRate, sgstRate: l.sgstRate,
          igstRate: l.igstRate, huidNumber: l.huidNumber,
        })),
        oldGoldExchangeIds: selectedExchangeIds,
        discountAmount: parseFloat(discount) || 0,
        payments: paymentsPayload,
        createdBy: user?.id,
      });
      
      showToast(`Invoice ${invoice.invoice_number} created successfully`);
      resetForm();
      navigate(`/billing/history/${invoice.id}`);
    } catch (err) { 
      showError(err); 
    } finally { 
      setSubmitting(false); 
    }
  };

  return (
    <div>
      <h2 className="page-title">Billing / Point of Sale</h2>
      <p className="page-subtitle">Create a new GST tax invoice.</p>

      <div className="grid" style={{ gridTemplateColumns: '1fr 360px', alignItems: 'start' }}>
        <div>
          
          {/* CUSTOMER CARD */}
          <div className="card">
            <div className="card-title">Customer Details (Mandatory)</div>
            
            <input 
              placeholder="Search existing customer by phone to auto-fill..." 
              value={customerSearch} 
              onChange={(e) => setCustomerSearch(e.target.value)} 
              style={{ marginBottom: 12 }}
            />
            
            {customerResults.length > 0 && (
              <div style={{ marginBottom: 12, border: '1px solid var(--border)', borderRadius: 6, maxHeight: 150, overflowY: 'auto' }}>
                {customerResults.map((c) => (
                  <div key={c.id} style={{ padding: 8, cursor: 'pointer', borderBottom: '1px solid var(--border)' }}
                    onClick={() => { 
                      setCustomer(c);
                      setCustomerName(c.name || '');
                      setCustomerPhone(c.phone || '');
                      setCustomerAddress(c.address || '');
                      setCustomerPan(c.pan_number || ''); 
                      setPlaceOfSupply(c.state_code || placeOfSupply);
                      setCustomerSearch('');
                      setCustomerResults([]);
                    }}>
                    {c.name} &middot; {c.phone}
                  </div>
                ))}
              </div>
            )}

            <div className="inline-fields">
              <div className="field">
                <label>Name *</label>
                <input value={customerName} onChange={(e) => setCustomerName(e.target.value)} required />
              </div>
              <div className="field">
                <label>Phone *</label>
                <input value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} required />
              </div>
            </div>

            <div className="inline-fields" style={{ marginTop: 10 }}>
              <div className="field">
                <label>Address *</label>
                <input value={customerAddress} onChange={(e) => setCustomerAddress(e.target.value)} required />
              </div>
              <div className="field">
                <label>PAN Number *</label>
                <input value={customerPan} onChange={(e) => setCustomerPan(e.target.value)} style={{ textTransform: 'uppercase' }} required />
              </div>
            </div>

            <div className="inline-fields" style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--border)' }}>
              <div className="field">
                <label>Place of Supply (State Code)</label>
                <input value={placeOfSupply} onChange={(e) => setPlaceOfSupply(e.target.value)} />
              </div>
              <div className="field">
                <label>Supply Type</label>
                <input value={isInterstate ? 'Inter-state (IGST)' : 'Intra-state (CGST+SGST)'} disabled />
              </div>
            </div>
          </div>

          {/* ITEMS CARD */}
          <div className="card">
            <div className="card-title">Items</div>
            <input
              placeholder="Scan barcode or search item by name / code..."
              value={itemSearch}
              onChange={(e) => setItemSearch(e.target.value)}
              onKeyDown={handleItemSearchKeyDown}
              autoFocus
            />
            {itemResults.length > 0 && (
              <div style={{ marginTop: 8, border: '1px solid var(--border)', borderRadius: 6, maxHeight: 220, overflowY: 'auto' }}>
                {itemResults.map((it) => (
                  <div key={it.id} style={{ padding: 8, cursor: 'pointer', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between' }}
                    onClick={() => addItemToCart(it)}>
                    <span>{it.name} <span className="muted">({it.item_code})</span></span>
                    <span className="muted">{it.net_weight.toFixed(3)}g &middot; {it.purity_name}</span>
                  </div>
                ))}
              </div>
            )}

            {/* 4-COLUMN STACKED TABLE UI */}
            <table className="cart-table" style={{ marginTop: 14, width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border)', textAlign: 'left' }}>
                  <th style={{ paddingBottom: 10, paddingLeft: 8 }}>ITEM DETAILS</th>
                  <th style={{ paddingBottom: 10, width: '80px', textAlign: 'center' }}>QTY</th>
                  <th style={{ paddingBottom: 10, width: '200px' }}>MAKING & WASTAGE</th>
                  <th style={{ paddingBottom: 10, width: '50px' }}></th>
                </tr>
              </thead>
              <tbody>
                {computedLines.map((line, idx) => (
                  <tr key={idx} style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.05)' }}>
                    
                    <td style={{ padding: '16px 8px', verticalAlign: 'top' }}>
                      <div style={{ fontWeight: '600', fontSize: 14, color: 'var(--text)', marginBottom: 2 }}>{line.description}</div>
                      <div className="muted" style={{ fontSize: 12, marginBottom: 12 }}>
                        {line.metalType} {line.purityName}
                      </div>
                      
                      <div style={{ display: 'flex', alignItems: 'center', gap: 12, background: 'rgba(255,255,255,0.03)', padding: '6px 12px', borderRadius: 6, width: 'fit-content', border: '1px solid rgba(255,255,255,0.05)' }}>
                        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                          <span className="muted" style={{ fontSize: 11 }}>Net Wt:</span>
                          <span className="mono" style={{ fontSize: 12, fontWeight: '500' }}>{Number(line.netWeight || 0).toFixed(3)} g</span>
                        </div>
                        <div style={{ width: 1, height: 12, background: 'var(--border)' }}></div>
                        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                          <span className="muted" style={{ fontSize: 11 }}>Rate/g: ₹</span>
                          <input 
                            type="number" step="0.01" 
                            style={{ width: 80, padding: '4px 8px', fontSize: 12 }} 
                            value={line.ratePerGram}
                            onChange={(e) => updateLine(idx, { ratePerGram: parseFloat(e.target.value) || 0 })} 
                          />
                        </div>
                      </div>
                    </td>

                    <td style={{ padding: '16px 8px', verticalAlign: 'top', textAlign: 'center' }}>
                      <input 
                        type="number" min="1" step="1" 
                        style={{ width: 50, textAlign: 'center', padding: '6px', marginTop: 2 }} 
                        value={line.pcs}
                        onChange={(e) => updateLine(idx, { pcs: parseInt(e.target.value) || 1 })} 
                      />
                    </td>
                    
                    <td style={{ padding: '16px 8px', verticalAlign: 'top' }}>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 2 }}>
                        
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <span className="muted" style={{ fontSize: 11, width: 45 }}>Making:</span>
                          <select
                            style={{ fontSize: 12, padding: '5px', width: 60 }}
                            value={line.makingChargeType}
                            onChange={(e) => updateLine(idx, { makingChargeType: e.target.value })}
                          >
                            <option value="PER_GRAM">/ g</option>
                            <option value="FIXED">Fix</option>
                            <option value="PERCENTAGE">%</option>
                          </select>
                          <input
                            type="number" step="0.01" 
                            style={{ width: 75, padding: '5px 8px' }}
                            value={line.makingChargeValue}
                            onChange={(e) => updateLine(idx, { makingChargeValue: parseFloat(e.target.value) || 0 })}
                          />
                        </div>

                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <span className="muted" style={{ fontSize: 11, width: 45 }}>Wstg %:</span>
                          <input 
                            type="number" step="0.01" 
                            style={{ width: 60, padding: '5px 8px' }} 
                            value={line.wastagePercent}
                            onChange={(e) => updateLine(idx, { wastagePercent: parseFloat(e.target.value) || 0 })} 
                          />
                        </div>

                      </div>
                    </td>
                    
                    <td style={{ padding: '16px 8px', verticalAlign: 'top', textAlign: 'right' }}>
                      <button 
                        className="ghost" 
                        onClick={() => removeLine(idx)} 
                        style={{ padding: '6px 10px', marginTop: 2, color: 'var(--text)' }}
                      >
                        ✕
                      </button>
                    </td>

                  </tr>
                ))}
                
                {cart.length === 0 && (
                  <tr>
                    <td colSpan={4} className="muted center" style={{ padding: '40px 10px' }}>
                      No items added yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {customer && pendingExchanges.length > 0 && (
            <div className="card">
              <div className="card-title">Old Gold Exchange Credit</div>
              {pendingExchanges.map((ex) => (
                <label key={ex.id} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6, cursor: 'pointer' }}>
                  <input type="checkbox" style={{ width: 'auto' }} checked={selectedExchangeIds.includes(ex.id)}
                    onChange={(e) => setSelectedExchangeIds((ids) => e.target.checked ? [...ids, ex.id] : ids.filter((i) => i !== ex.id))} />
                  {ex.exchange_number} — {ex.metal_type}, {ex.net_weight}g @ {ex.purity_tested_percent}% purity — <b>₹{ex.total_value.toLocaleString('en-IN')}</b>
                </label>
              ))}
            </div>
          )}

        </div>

        {/* RIGHT SIDEBAR: SUMMARY & PAYMENTS */}
        <div>
          <div className="card">
            <div className="card-title">Bill Summary</div>
            <SummaryRow label="Subtotal (Metal)" value={subtotal} />
            <SummaryRow label="Making + Wastage" value={totalMaking} />
            <SummaryRow label="Stone Charges" value={totalStone} />
            <SummaryRow label="Taxable Amount" value={taxableAmount} bold />
            {isInterstate ? <SummaryRow label="IGST" value={igstTotal} /> : (
              <>
                <SummaryRow label="CGST" value={cgstTotal} />
                <SummaryRow label="SGST" value={sgstTotal} />
              </>
            )}
            <div className="field" style={{ marginTop: 10 }}>
              <label>Discount (₹)</label>
              <input type="number" step="0.01" value={discount} onChange={(e) => setDiscount(e.target.value)} />
            </div>
            {oldGoldValue > 0 && <SummaryRow label="Old Gold Credit" value={-oldGoldValue} />}
            <SummaryRow label="Round Off" value={roundOff} />
            <hr className="section-divider" />
            <SummaryRow label="Grand Total" value={grandTotal} bold big />

            <div className="section-divider" />
            <div className="card-title" style={{ marginTop: 0 }}>Payment</div>
            {payments.map((p, idx) => (
              <div key={idx} className="inline-fields" style={{ marginBottom: 6 }}>
                <div className="field">
                  <input type="number" step="0.01" placeholder="Amount" value={p.amount} onChange={(e) => updatePayment(idx, { amount: e.target.value })} />
                </div>
                <div className="field" style={{ maxWidth: 120 }}>
                  <select value={p.paymentMode} onChange={(e) => updatePayment(idx, { paymentMode: e.target.value })}>
                    {PAYMENT_MODES.map((m) => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
                {payments.length > 1 && <button className="ghost" onClick={() => removePayment(idx)}>✕</button>}
              </div>
            ))}
            <button className="ghost" onClick={addPaymentRow} type="button">+ Add payment split</button>

            <SummaryRow label="Total Paid" value={totalPaid} />
            <SummaryRow label="Balance Due" value={balanceDue} bold={balanceDue > 0} />

            <button className="primary" style={{ width: '100%', marginTop: 14, padding: 12 }} onClick={handleSubmit} disabled={submitting}>
              {submitting ? 'Processing...' : 'Complete Sale & Generate Invoice'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function SummaryRow({ label, value, bold, big }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontWeight: bold ? 700 : 400, fontSize: big ? 17 : 13.5, color: bold ? 'var(--gold-bright)' : 'var(--text)' }}>
      <span className={bold ? '' : 'muted'}>{label}</span>
      <span className="mono">₹{Number(value || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
    </div>
  );
}