import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useToast } from '../../context/ToastContext.jsx';
import { useAuth } from '../../context/AuthContext.jsx';

export default function InvoiceView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { showToast, showError } = useToast();
  const { settings } = useAuth(); // Needed to get the shop name for WhatsApp
  
  const [invoice, setInvoice] = useState(null);

  // Security Modal States
  const [showAdminPrompt, setShowAdminPrompt] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [cancelReason, setCancelReason] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  // WhatsApp Modal States
  const [showWhatsappPrompt, setShowWhatsappPrompt] = useState(false);
  const [whatsappPhone, setWhatsappPhone] = useState('');

  const load = () => window.api.billing.getById(Number(id)).then(setInvoice).catch(showError);
  useEffect(() => { load(); }, [id]);

  if (!invoice) return <div className="muted">Loading...</div>;

  const handlePrint = async () => {
    try {
      const res = await window.api.billing.printPdf(invoice.id);
      showToast(`Invoice PDF opened (${res.path})`);
    } catch (err) { showError(err); }
  };

  // 1. Opens the custom React modal for WhatsApp instead of window.prompt()
  const handleWhatsappClick = () => {
    setWhatsappPhone(invoice?.customer_phone || '');
    setShowWhatsappPrompt(true);
  };

  // 2. Processes the WhatsApp Web link after the user submits the modal
  const handleWhatsappSubmit = (e) => {
    e.preventDefault();
    if (!whatsappPhone) return;

    // Clean phone number & default to India (+91) if 10 digits
    let phone = String(whatsappPhone).replace(/\D/g, '');
    if (phone.length === 10) phone = `91${phone}`;

    // Professional receipt text
    const message = `Hello ${invoice.customer_name || 'Customer'},\n\nThank you for shopping at ${settings?.shop_name || 'Luxury Jewellers'}!\n\n📄 *Invoice Summary*\nInvoice No: ${invoice.invoice_number}\nDate: ${invoice.invoice_date}\nGrand Total: ₹${Number(invoice.grand_total).toLocaleString('en-IN')}\n\nWe appreciate your business!`;

    const whatsappUrl = `https://web.whatsapp.com/send?phone=${phone}&text=${encodeURIComponent(message)}`;

    // Open WhatsApp Web
    window.api.system.openExternal(whatsappUrl);
    setShowWhatsappPrompt(false); // Close the modal
  };

  // 3. Opens the Security Modal instead of immediately cancelling
  const handleCancelClick = () => {
    setAdminPassword('');
    setCancelReason('');
    setShowAdminPrompt(true);
  };

  // 4. Verifies password and processes cancellation
  const handleAdminSubmit = async (e) => {
    e.preventDefault();
    if (!adminPassword) return;

    setIsVerifying(true);
    try {
      const res = await window.api.auth.verifyAdmin(adminPassword);
      
      if (res.success) {
        await window.api.billing.cancel(invoice.id, cancelReason);
        showToast('Invoice cancelled and items restored to stock');
        setShowAdminPrompt(false);
        setAdminPassword('');
        load(); // Refresh the page to show CANCELLED status
      } else {
        showError(new Error("Incorrect Admin Password. Cancellation denied."));
      }
    } catch (err) {
      showError(err);
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div>
      <div className="toolbar">
        <button className="ghost" onClick={() => navigate('/billing/history')}>← Back</button>
        <div className="spacer" />
        <button className="ghost" onClick={handlePrint}>Print / Save PDF</button>
        <button className="primary" onClick={handleWhatsappClick}>Send via WhatsApp</button>
        
        {invoice.status === 'COMPLETED' && (
          <button className="danger" onClick={handleCancelClick}>Cancel Invoice</button>
        )}
      </div>

      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <h2 className="page-title" style={{ marginBottom: 0 }}>{invoice.invoice_number}</h2>
            <span className="muted">{invoice.invoice_date}</span>
            <span className={`badge ${invoice.status === 'COMPLETED' ? 'green' : 'red'}`} style={{ marginLeft: 10 }}>{invoice.status}</span>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div><b>{invoice.customer_name || 'Walk-in Customer'}</b></div>
            {invoice.customer_phone && <div className="muted">{invoice.customer_phone}</div>}
            {invoice.customer_gstin && <div className="muted">GSTIN: {invoice.customer_gstin}</div>}
          </div>
        </div>

        <hr className="section-divider" />

        <table>
          <thead>
            <tr><th>Description</th><th>HSN</th><th>Purity</th><th>G.Wt</th><th>N.Wt</th><th>Rate/g</th><th>Making</th><th>Taxable</th><th>Tax</th><th>Total</th></tr>
          </thead>
          <tbody>
            {invoice.items.map((it) => (
              <tr key={it.id}>
                <td>{it.description}{it.huid_number && <div className="muted" style={{ fontSize: 11 }}>HUID: {it.huid_number}</div>}</td>
                <td>{it.hsn_code || '-'}</td>
                <td>{it.purity_name}</td>
                <td className="mono">{it.gross_weight.toFixed(3)}</td>
                <td className="mono">{it.net_weight.toFixed(3)}</td>
                <td className="mono">₹{it.rate_per_gram.toFixed(2)}</td>
                <td className="mono">₹{it.making_charge.toFixed(2)}</td>
                <td className="mono">₹{it.taxable_value.toFixed(2)}</td>
                <td className="mono">₹{(it.cgst_amount + it.sgst_amount + it.igst_amount).toFixed(2)}</td>
                <td className="mono">₹{it.line_total.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 16 }}>
          <div style={{ width: 320 }}>
            <Row label="Subtotal (Metal)" value={invoice.subtotal} />
            <Row label="Making + Wastage" value={invoice.total_making_charges} />
            <Row label="Stone Charges" value={invoice.total_stone_charges} />
            <Row label="Taxable Amount" value={invoice.taxable_amount} />
            {invoice.is_interstate ? <Row label="IGST" value={invoice.igst_amount} /> : (
              <>
                <Row label="CGST" value={invoice.cgst_amount} />
                <Row label="SGST" value={invoice.sgst_amount} />
              </>
            )}
            {invoice.discount_amount > 0 && <Row label="Discount" value={-invoice.discount_amount} />}
            {invoice.old_gold_exchange_value > 0 && <Row label="Old Gold Credit" value={-invoice.old_gold_exchange_value} />}
            {invoice.scheme_redemption_value > 0 && <Row label="Scheme Redemption" value={-invoice.scheme_redemption_value} />}
            <Row label="Round Off" value={invoice.round_off} />
            <hr className="section-divider" />
            <Row label="Grand Total" value={invoice.grand_total} bold big />
            <Row label="Amount Paid" value={invoice.amount_paid} />
            {invoice.balance_due > 0 && <Row label="Balance Due" value={invoice.balance_due} bold />}
          </div>
        </div>

        {invoice.payments.length > 0 && (
          <>
            <hr className="section-divider" />
            <div className="card-title">Payments</div>
            <table>
              <thead><tr><th>Mode</th><th>Amount</th><th>Reference</th><th>Date</th></tr></thead>
              <tbody>
                {invoice.payments.map((p) => (
                  <tr key={p.id}><td>{p.payment_mode}</td><td className="mono">₹{p.amount.toFixed(2)}</td><td>{p.reference_number || '-'}</td><td>{p.payment_date}</td></tr>
                ))}
              </tbody>
            </table>
          </>
        )}
      </div>

      {/* Security Password Modal */}
      {showAdminPrompt && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          background: 'rgba(0, 0, 0, 0.75)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000
        }}>
          <div className="card" style={{ width: 400, border: '1px solid var(--border)' }}>
            <h3 style={{ marginTop: 0, color: '#ff4d4f' }}>🔒 Admin Authorization Required</h3>
            <p className="muted" style={{ fontSize: 13, lineHeight: 1.4 }}>
              Enter the Owner/Admin password to confirm cancellation of invoice <b>{invoice.invoice_number}</b>.
            </p>

            <form onSubmit={handleAdminSubmit}>
              <div className="field" style={{ marginTop: 16 }}>
                <label>Reason for Cancellation</label>
                <input 
                  type="text" 
                  placeholder="e.g., Customer changed mind"
                  value={cancelReason} 
                  onChange={(e) => setCancelReason(e.target.value)} 
                  required
                />
              </div>

              <div className="field" style={{ marginTop: 16 }}>
                <label>Admin Password</label>
                <input 
                  type="password" 
                  autoFocus
                  placeholder="Enter admin password"
                  value={adminPassword} 
                  onChange={(e) => setAdminPassword(e.target.value)} 
                  required
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 24 }}>
                <button type="button" className="ghost" onClick={() => setShowAdminPrompt(false)}>
                  Go Back
                </button>
                <button type="submit" className="danger" disabled={isVerifying}>
                  {isVerifying ? 'Verifying...' : 'Confirm Cancellation'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* WhatsApp Modal */}
      {showWhatsappPrompt && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          background: 'rgba(0, 0, 0, 0.75)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000
        }}>
          <div className="card" style={{ width: 400, border: '1px solid var(--border)' }}>
            <h3 style={{ marginTop: 0, color: 'var(--gold-bright)' }}>📱 Send WhatsApp</h3>
            <p className="muted" style={{ fontSize: 13, lineHeight: 1.4 }}>
              Confirm or enter the customer's WhatsApp number.
            </p>

            <form onSubmit={handleWhatsappSubmit}>
              <div className="field" style={{ marginTop: 16 }}>
                <label>WhatsApp Number</label>
                <input 
                  type="text" 
                  autoFocus
                  placeholder="Enter 10-digit mobile number"
                  value={whatsappPhone} 
                  onChange={(e) => setWhatsappPhone(e.target.value)} 
                  required
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 24 }}>
                <button type="button" className="ghost" onClick={() => setShowWhatsappPrompt(false)}>
                  Cancel
                </button>
                <button type="submit" className="primary">
                  Open WhatsApp Web
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}

function Row({ label, value, bold, big }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontWeight: bold ? 700 : 400, fontSize: big ? 17 : 13.5, color: bold ? 'var(--gold-bright)' : 'var(--text)' }}>
      <span className={bold ? '' : 'muted'}>{label}</span>
      <span className="mono">₹{Number(value || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
    </div>
  );
}