import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';

export default function RateMaster() {
  const { user } = useAuth();
  const { showToast, showError } = useToast();
  const [rates, setRates] = useState([]);
  const [editValues, setEditValues] = useState({});
  const [history, setHistory] = useState(null);
  const [historyFor, setHistoryFor] = useState(null);
  const [loading, setLoading] = useState(false);

  const load = () => window.api.rates.getCurrent().then(setRates).catch(showError);

  useEffect(() => { load(); }, []);

const fetchLiveRates = async () => {
    setLoading(true);
    try {
      // 1. Fetch live rates from the backend
      const response = await window.api.rates.fetchIBJA();
      
      // Handle response wrapping if present
      const data = response?.data || response;
      const rateDate = data?.date || 'Today';

      console.log('Raw Data received from scraper:', data);
      console.log('Database rates list:', rates);

      // Helper function to safely extract clean numbers from text (e.g., "131,289" -> 131289)
      const parseValue = (val) => {
        if (!val) return null;
        const cleaned = String(val).replace(/[^0-9.]/g, '');
        const num = parseFloat(cleaned);
        return isNaN(num) ? null : num;
      };

      const newEditValues = { ...editValues };

      // 2. Loop through database rows with flexible matching
      rates.forEach((r) => {
        const metal = (r.metal_type || '').toUpperCase();
        const purityName = (r.purity_name || '').toUpperCase();
        const fineness = parseFloat(r.fineness_percent) || 0;

        let fetchedRatePerGram = null;

        if (metal === 'GOLD') {
          if (fineness >= 99.8 || purityName.includes('999') || purityName.includes('24K')) {
            const raw = parseValue(data?.gold_999);
            if (raw) fetchedRatePerGram = raw / 10;
          } else if ((fineness >= 99.4 && fineness < 99.8) || purityName.includes('995')) {
            const raw = parseValue(data?.gold_995);
            if (raw) fetchedRatePerGram = raw / 10;
          } else if ((fineness >= 91.0 && fineness < 95.0) || purityName.includes('916') || purityName.includes('22K')) {
            const raw = parseValue(data?.gold_916);
            if (raw) fetchedRatePerGram = raw / 10;
          } else if ((fineness >= 74.0 && fineness < 80.0) || purityName.includes('750') || purityName.includes('18K')) {
            const raw = parseValue(data?.gold_750);
            if (raw) fetchedRatePerGram = raw / 10;
          } else if ((fineness >= 57.0 && fineness < 65.0) || purityName.includes('585') || purityName.includes('14K')) {
            const raw = parseValue(data?.gold_585);
            if (raw) fetchedRatePerGram = raw / 10;
          }
        } else if (metal === 'SILVER') {
          if (fineness >= 99.0 || purityName.includes('999') || purityName.includes('SILVER')) {
            const raw = parseValue(data?.silver_999);
            if (raw) fetchedRatePerGram = raw / 1000;
          }
        }

        // 3. Drop calculated rate into the input box
        if (fetchedRatePerGram !== null) {
          newEditValues[r.id] = fetchedRatePerGram.toFixed(2);
        }
      });

      setEditValues(newEditValues);
      showToast(`Rates fetched successfully for ${rateDate}! Review and click Save.`);
    } catch (err) {
      showError(new Error('Failed to fetch or map IBJA rates. Check console for details.'));
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (purityId) => {
    const value = parseFloat(editValues[purityId]);
    if (!value || value <= 0) { showError(new Error('Enter a valid rate greater than 0')); return; }
    try {
      await window.api.rates.set({ purityId, ratePerGram: value, createdBy: user?.id });
      showToast('Rate updated successfully');
      setEditValues((v) => ({ ...v, [purityId]: '' }));
      load();
    } catch (err) { showError(err); }
  };

  const viewHistory = async (purity) => {
    setHistoryFor(purity);
    const h = await window.api.rates.history(purity.id, 30).catch(showError);
    setHistory(h);
  };

  return (
    <div>
      <h2 className="page-title">Rate Master</h2>
      <p className="page-subtitle">Set today's per-gram rate for each metal purity. Billing always uses the latest rate as of the invoice date.</p>

      {/* USING NATIVE TOOLBAR CSS CLASS TO GUARANTEE VISIBILITY */}
      <div className="toolbar" style={{ marginBottom: 16 }}>
        <div className="spacer" />
        <button 
          className="primary" 
          onClick={fetchLiveRates} 
          disabled={loading}
        >
          {loading ? 'Fetching...' : 'Fetch IBJA Rates'}
        </button>
      </div>

      <div className="card">
        <table>
          <thead>
            <tr>
              <th>Metal</th><th>Purity</th><th>Fineness</th><th>Current Rate (₹/g)</th><th>As Of</th><th>Update Rate</th><th></th>
            </tr>
          </thead>
          <tbody>
            {rates.map((r) => (
              <tr key={r.id}>
                <td><span className={`badge ${r.metal_type === 'GOLD' ? 'gold' : 'gray'}`}>{r.metal_type}</span></td>
                <td>{r.purity_name}</td>
                <td>{r.fineness_percent}%</td>
                <td className="mono">{r.rate_per_gram ? `₹${r.rate_per_gram.toFixed(2)}` : <span className="muted">Not set</span>}</td>
                <td className="muted">{r.rate_effective_date || '-'}</td>
                <td>
                  <input
                    type="number" step="0.01" placeholder="New rate"
                    style={{ width: 120, display: 'inline-block' }}
                    value={editValues[r.id] || ''}
                    onChange={(e) => setEditValues((v) => ({ ...v, [r.id]: e.target.value }))}
                  />
                </td>
                <td style={{ display: 'flex', gap: 6 }}>
                  <button className="primary" onClick={() => handleSave(r.id)}>Save</button>
                  <button className="ghost" onClick={() => viewHistory(r)}>History</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {historyFor && (
        <div className="card">
          <div className="card-title">Rate History — {historyFor.metal_type} {historyFor.purity_name}</div>
          <table>
            <thead><tr><th>Date</th><th>Rate (₹/g)</th><th>Set At</th></tr></thead>
            <tbody>
              {(history || []).map((h) => (
                <tr key={h.id}>
                  <td>{h.effective_date}</td>
                  <td className="mono">₹{h.rate_per_gram.toFixed(2)}</td>
                  <td className="muted">{h.effective_datetime}</td>
                </tr>
              ))}
              {history && history.length === 0 && <tr><td colSpan={3} className="muted">No history yet</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}