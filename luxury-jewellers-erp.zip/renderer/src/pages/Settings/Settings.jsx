import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';

const TABS = ['Shop Profile', 'Categories & HSN', 'Users', 'Backup & Restore'];

function ShopProfileTab() {
  const { settings, refreshSettings } = useAuth();
  const { showToast, showError } = useToast();
  const [form, setForm] = useState(settings || {});
  const [saving, setSaving] = useState(false);
  useEffect(() => { setForm(settings || {}); }, [settings]);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const handleSave = async () => {
    setSaving(true);
    try {
      await window.api.settings.update(form);
      await refreshSettings();
      showToast('Shop profile updated');
    } catch (err) { showError(err); } finally { setSaving(false); }
  };

  return (
    <div className="card">
      <div className="inline-fields">
        <div className="field"><label>Shop Name</label><input value={form.shop_name || ''} onChange={set('shop_name')} /></div>
        <div className="field"><label>GSTIN</label><input value={form.shop_gstin || ''} onChange={set('shop_gstin')} /></div>
      </div>
      <div className="field"><label>Address</label><textarea rows={2} value={form.shop_address || ''} onChange={set('shop_address')} /></div>
      <div className="inline-fields">
        <div className="field"><label>Phone</label><input value={form.shop_phone || ''} onChange={set('shop_phone')} /></div>
        <div className="field"><label>Email</label><input value={form.shop_email || ''} onChange={set('shop_email')} /></div>
        <div className="field"><label>State Code</label><input value={form.shop_state_code || ''} onChange={set('shop_state_code')} /></div>
        <div className="field"><label>PAN</label><input value={form.shop_pan || ''} onChange={set('shop_pan')} /></div>
      </div>
      <div className="field"><label>Invoice Terms &amp; Conditions</label><textarea rows={3} value={form.invoice_terms || ''} onChange={set('invoice_terms')} /></div>
      <button className="primary" onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : 'Save Shop Profile'}</button>
    </div>
  );
}

function CategoriesHsnTab() {
  const { showToast, showError } = useToast();
  const [categories, setCategories] = useState([]);
  const [hsnCodes, setHsnCodes] = useState([]);
  const [newCategory, setNewCategory] = useState('');
  const [newCategoryHsn, setNewCategoryHsn] = useState('');
  const [editRates, setEditRates] = useState({});

  const load = () => {
    window.api.settings.listCategories().then(setCategories).catch(showError);
    window.api.settings.listHsnCodes().then(setHsnCodes).catch(showError);
  };
  useEffect(() => { load(); }, []);

  const addCategory = async () => {
    if (!newCategory) return;
    try {
      await window.api.settings.createCategory({ name: newCategory, hsnId: newCategoryHsn ? Number(newCategoryHsn) : null });
      setNewCategory(''); setNewCategoryHsn('');
      showToast('Category added');
      load();
    } catch (err) { showError(err); }
  };

  const saveHsnRate = async (h) => {
    const vals = editRates[h.id] || {};
    try {
      await window.api.settings.updateHsnRate(h.id, {
        cgstRate: parseFloat(vals.cgst ?? h.cgst_rate),
        sgstRate: parseFloat(vals.sgst ?? h.sgst_rate),
        igstRate: parseFloat(vals.igst ?? h.igst_rate),
      });
      showToast('HSN rate updated');
      load();
    } catch (err) { showError(err); }
  };

  return (
    <div>
      <div className="card">
        <div className="card-title">HSN / GST Rate Master</div>
        <table>
          <thead><tr><th>HSN Code</th><th>Description</th><th>CGST%</th><th>SGST%</th><th>IGST%</th><th></th></tr></thead>
          <tbody>
            {hsnCodes.map((h) => (
              <tr key={h.id}>
                <td className="mono">{h.hsn_code}</td>
                <td>{h.description}</td>
                <td><input type="number" step="0.01" style={{ width: 70 }} defaultValue={h.cgst_rate} onChange={(e) => setEditRates((r) => ({ ...r, [h.id]: { ...r[h.id], cgst: e.target.value } }))} /></td>
                <td><input type="number" step="0.01" style={{ width: 70 }} defaultValue={h.sgst_rate} onChange={(e) => setEditRates((r) => ({ ...r, [h.id]: { ...r[h.id], sgst: e.target.value } }))} /></td>
                <td><input type="number" step="0.01" style={{ width: 70 }} defaultValue={h.igst_rate} onChange={(e) => setEditRates((r) => ({ ...r, [h.id]: { ...r[h.id], igst: e.target.value } }))} /></td>
                <td><button className="ghost" onClick={() => saveHsnRate(h)}>Save</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card">
        <div className="card-title">Item Categories</div>
        <table>
          <thead><tr><th>Category</th><th>HSN</th></tr></thead>
          <tbody>
            {categories.map((c) => <tr key={c.id}><td>{c.name}</td><td className="mono">{c.hsn_code || '-'}</td></tr>)}
          </tbody>
        </table>
        <div className="inline-fields" style={{ marginTop: 12 }}>
          <div className="field"><label>New Category Name</label><input value={newCategory} onChange={(e) => setNewCategory(e.target.value)} /></div>
          <div className="field"><label>HSN Code</label>
            <select value={newCategoryHsn} onChange={(e) => setNewCategoryHsn(e.target.value)}>
              <option value="">Select</option>
              {hsnCodes.map((h) => <option key={h.id} value={h.id}>{h.hsn_code} - {h.description}</option>)}
            </select>
          </div>
          <div className="field" style={{ display: 'flex', alignItems: 'flex-end' }}><button className="primary" onClick={addCategory}>Add Category</button></div>
        </div>
      </div>
    </div>
  );
}

function UsersTab() {
  const { user: currentUser } = useAuth();
  const { showToast, showError } = useToast();
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ username: '', password: '', fullName: '', role: 'CASHIER' });
  const [pwForm, setPwForm] = useState({ oldPassword: '', newPassword: '' });
  const [resetPasswords, setResetPasswords] = useState({});

  const load = () => window.api.auth.listUsers().then(setUsers).catch(showError);
  useEffect(() => { load(); }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await window.api.auth.createUser(form);
      showToast('User created');
      setForm({ username: '', password: '', fullName: '', role: 'CASHIER' });
      load();
    } catch (err) { showError(err); }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    try {
      await window.api.auth.changePassword(currentUser.id, pwForm.oldPassword, pwForm.newPassword);
      showToast('Password changed');
      setPwForm({ oldPassword: '', newPassword: '' });
    } catch (err) { showError(err); }
  };

  const toggleActive = async (u) => {
    try { await window.api.auth.setUserActive(u.id, !u.is_active); load(); } catch (err) { showError(err); }
  };

  const resetPassword = async (u) => {
    const newPassword = (resetPasswords[u.id] || '').trim();
    if (!newPassword) {
      showError(new Error('Enter a new password before resetting')); return;
    }
    try {
      await window.api.auth.resetPassword(currentUser.id, u.id, newPassword);
      showToast(`Password reset for ${u.username}`);
      setResetPasswords((p) => ({ ...p, [u.id]: '' }));
    } catch (err) { showError(err); }
  };

  return (
    <div>
      <div className="card">
        <div className="card-title">Change My Password</div>
        <form onSubmit={handleChangePassword} className="inline-fields">
          <div className="field"><label>Current Password</label><input type="password" value={pwForm.oldPassword} onChange={(e) => setPwForm((f) => ({ ...f, oldPassword: e.target.value }))} /></div>
          <div className="field"><label>New Password</label><input type="password" value={pwForm.newPassword} onChange={(e) => setPwForm((f) => ({ ...f, newPassword: e.target.value }))} /></div>
          <div className="field" style={{ display: 'flex', alignItems: 'flex-end' }}><button className="primary" type="submit">Change</button></div>
        </form>
      </div>

      {currentUser?.role === 'ADMIN' && (
        <div className="card">
          <div className="card-title">Staff Users</div>
          <table>
            <thead><tr><th>Username</th><th>Full Name</th><th>Role</th><th>Status</th><th>Reset Password</th><th></th></tr></thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td>{u.username}</td><td>{u.full_name}</td><td>{u.role}</td>
                  <td><span className={`badge ${u.is_active ? 'green' : 'red'}`}>{u.is_active ? 'Active' : 'Disabled'}</span></td>
                  <td>
                    {u.id !== currentUser.id ? (
                      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                        <input
                          type="password"
                          placeholder="New password"
                          value={resetPasswords[u.id] || ''}
                          onChange={(e) => setResetPasswords((p) => ({ ...p, [u.id]: e.target.value }))}
                          style={{ maxWidth: 150 }}
                        />
                        <button className="ghost" onClick={() => resetPassword(u)}>Reset</button>
                      </div>
                    ) : <span className="muted">Current user</span>}
                  </td>
                  <td>{u.id !== currentUser.id && <button className="ghost" onClick={() => toggleActive(u)}>{u.is_active ? 'Disable' : 'Enable'}</button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <hr className="section-divider" />
          <div className="card-title">Add New User</div>
          <form onSubmit={handleCreate} className="inline-fields">
            <div className="field"><label>Username</label><input value={form.username} onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))} /></div>
            <div className="field"><label>Full Name</label><input value={form.fullName} onChange={(e) => setForm((f) => ({ ...f, fullName: e.target.value }))} /></div>
            <div className="field"><label>Password</label><input type="password" value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} /></div>
            <div className="field"><label>Role</label>
              <select value={form.role} onChange={(e) => setForm((f) => ({ ...f, role: e.target.value }))}>
                <option value="ADMIN">Admin</option><option value="MANAGER">Manager</option><option value="CASHIER">Cashier</option>
              </select>
            </div>
            <div className="field" style={{ display: 'flex', alignItems: 'flex-end' }}><button className="primary" type="submit">Add User</button></div>
          </form>
        </div>
      )}
    </div>
  );
}

function BackupTab() {
  const { showToast, showError } = useToast();
  const { settings, refreshSettings } = useAuth();
  const [busy, setBusy] = useState(false);

  const handleBackup = async () => {
    setBusy(true);
    try {
      const res = await window.api.backup.saveAs();
      if (!res.canceled) { showToast(`Backup saved to ${res.path}`); refreshSettings(); }
    } catch (err) { showError(err); } finally { setBusy(false); }
  };

  const handleRestore = async () => {
    if (!window.confirm('Restoring will replace ALL current data with the selected backup file. A safety copy will be kept automatically. Continue?')) return;
    setBusy(true);
    try {
      const res = await window.api.backup.restore();
      if (!res.canceled) {
        window.alert('Restore complete. Please restart the application now.');
      }
    } catch (err) { showError(err); } finally { setBusy(false); }
  };

  return (
    <div className="card">
      <div className="card-title">Backup &amp; Restore</div>
      <p className="muted">Last backup: {settings?.last_backup_at ? new Date(settings.last_backup_at).toLocaleString() : 'Never'}</p>
      <p className="muted">All business data lives in a single local database file. Take regular backups to an external drive or cloud-synced folder (e.g. Google Drive desktop folder) for safety.</p>
      <div style={{ display: 'flex', gap: 10 }}>
        <button className="primary" onClick={handleBackup} disabled={busy}>Backup Now (Save As...)</button>
        <button className="danger" onClick={handleRestore} disabled={busy}>Restore From Backup...</button>
      </div>
    </div>
  );
}

export default function Settings() {
  const [tab, setTab] = useState(TABS[0]);
  return (
    <div>
      <h2 className="page-title">Settings</h2>
      <p className="page-subtitle">Shop profile, tax configuration, staff accounts, and data backup.</p>
      <div className="toolbar">
        {TABS.map((t) => <button key={t} className={tab === t ? 'primary' : 'ghost'} onClick={() => setTab(t)}>{t}</button>)}
      </div>
      {tab === 'Shop Profile' && <ShopProfileTab />}
      {tab === 'Categories & HSN' && <CategoriesHsnTab />}
      {tab === 'Users' && <UsersTab />}
      {tab === 'Backup & Restore' && <BackupTab />}
    </div>
  );
}
