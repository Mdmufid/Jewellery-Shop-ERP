import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../../context/ToastContext.jsx';

export default function Purchases() {
  const [purchases, setPurchases] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const navigate = useNavigate();
  const { showError } = useToast();

  const fetchPurchases = async () => {
    setLoading(true);
    try {
      // Pass an empty object to get all purchases
      const data = await window.api.purchases.list({});
      setPurchases(data || []);
    } catch (error) {
      showError(new Error('Failed to load purchases.'));
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPurchases();
  }, []);

  if (loading) {
    return <div className="muted" style={{ padding: 20 }}>Loading Purchases...</div>;
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <h2>Purchase Invoices</h2>
        <button className="primary" onClick={() => navigate('/purchases/new')}>
          + New Purchase Bill
        </button>
      </div>

      <div className="card">
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Bill Number</th>
              <th>Supplier</th>
              <th>Invoice No.</th>
              <th>Total Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {purchases.map(p => (
              <tr key={p.id}>
                <td className="muted">{new Date(p.purchase_date).toLocaleDateString('en-IN')}</td>
                <td className="mono" style={{ fontWeight: '500' }}>{p.purchase_number}</td>
                <td>{p.supplier_name}</td>
                <td className="mono">{p.invoice_number || '-'}</td>
                <td className="mono" style={{ fontWeight: 'bold' }}>
                  ₹{Number(p.total_amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </td>
                <td>
                  <span style={{
                    padding: '4px 8px',
                    borderRadius: '4px',
                    fontSize: '12px',
                    fontWeight: 'bold',
                    backgroundColor: p.payment_status === 'PAID' ? 'rgba(92, 184, 92, 0.2)' : 
                                     p.payment_status === 'PARTIAL' ? 'rgba(240, 173, 78, 0.2)' : 'rgba(217, 83, 79, 0.2)',
                    color: p.payment_status === 'PAID' ? '#5cb85c' : 
                           p.payment_status === 'PARTIAL' ? '#f0ad4e' : '#d9534f'
                  }}>
                    {p.payment_status}
                  </span>
                </td>
              </tr>
            ))}
            {purchases.length === 0 && (
              <tr>
                <td colSpan="6" className="center muted" style={{ padding: '30px 0' }}>
                  No purchase bills found. Click "+ New Purchase Bill" to record one.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}