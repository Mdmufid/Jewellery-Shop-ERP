import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../../context/ToastContext.jsx';

export default function NewPurchase() {
  const navigate = useNavigate();
  const { showError, showToast } = useToast();
  
  const [suppliers, setSuppliers] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Master Bill Details
  const [billDetails, setBillDetails] = useState({
    supplierId: '',
    purchaseDate: new Date().toISOString().split('T')[0],
    invoiceNumber: '',
    isInterstate: false,
    amountPaid: '',
    notes: ''
  });

  // Dynamic Array for Line Items
  const [items, setItems] = useState([
    {
      description: '',
      metalType: 'GOLD',
      quantity: 1, // 👉 HERE IS YOUR QUANTITY FIELD! Default is 1.
      grossWeight: '',
      stoneWeight: '',
      ratePerGram: '',
      makingCharge: '',
      huidNumber: ''
    }
  ]);

  // Load suppliers for the dropdown when page loads
  useEffect(() => {
    window.api.suppliers.list()
      .then(setSuppliers)
      .catch(showError);
  }, []);

  const handleBillChange = (e) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setBillDetails({ ...billDetails, [e.target.name]: value });
  };

  const handleItemChange = (index, field, value) => {
    const newItems = [...items];
    newItems[index][field] = value;
    setItems(newItems);
  };

  const addLineItem = () => {
    setItems([...items, {
      description: '', metalType: 'GOLD', quantity: 1, grossWeight: '', stoneWeight: '', ratePerGram: '', makingCharge: '', huidNumber: ''
    }]);
  };

  const removeLineItem = (index) => {
    if (items.length === 1) return; // Keep at least one row
    const newItems = items.filter((_, i) => i !== index);
    setItems(newItems);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!billDetails.supplierId) return showError(new Error('Please select a supplier.'));
    
    setIsSubmitting(true);
    try {
      // Format payload for your backend
      const payload = {
        ...billDetails,
        supplierId: Number(billDetails.supplierId),
        amountPaid: Number(billDetails.amountPaid) || 0,
        items: items.map(item => ({
          ...item,
          quantity: Number(item.quantity) || 1, // Ensure it's a number
          grossWeight: Number(item.grossWeight) || 0,
          stoneWeight: Number(item.stoneWeight) || 0,
          ratePerGram: Number(item.ratePerGram) || 0,
          makingCharge: Number(item.makingCharge) || 0
        }))
      };

      const response = await window.api.purchases.create(payload);
      if (response && response.id) {
        showToast('Purchase invoice recorded successfully!');
        navigate('/purchases');
      }
    } catch (error) {
      const cleanMessage = error.message.replace(/^Error invoking remote method '.*?': Error: /, '');
      showError(new Error(cleanMessage));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      <button className="ghost" onClick={() => navigate('/purchases')}>← Back to Purchases</button>

      <div className="card" style={{ marginTop: 14 }}>
        <h2>Record Purchase Bill</h2>
        <hr className="section-divider" />

        <form onSubmit={handleSubmit}>
          {/* Section 1: Master Bill Details */}
          <div className="grid grid-4" style={{ gap: 16, marginBottom: 24 }}>
            <div>
              <label>Supplier *</label>
              <select name="supplierId" value={billDetails.supplierId} onChange={handleBillChange} required>
                <option value="">-- Select Supplier --</option>
                {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
            <div>
              <label>Purchase Date *</label>
              <input type="date" name="purchaseDate" value={billDetails.purchaseDate} onChange={handleBillChange} required />
            </div>
            <div>
              <label>Supplier Invoice No.</label>
              <input type="text" name="invoiceNumber" value={billDetails.invoiceNumber} onChange={handleBillChange} placeholder="E.g. INV-1004" />
            </div>
            <div>
              <label>Amount Paid Now (₹)</label>
              <input type="number" name="amountPaid" value={billDetails.amountPaid} onChange={handleBillChange} placeholder="Leave 0 for full credit" />
            </div>
          </div>

          {/* Section 2: Line Items (Inventory) */}
          <h4 style={{ marginBottom: 12 }}>Items Purchased</h4>
          
          {items.map((item, index) => (
            <div key={index} style={{ 
              backgroundColor: 'rgba(0,0,0,0.2)', padding: '16px', borderRadius: '8px', marginBottom: '12px', border: '1px solid rgba(255,255,255,0.05)' 
            }}>
              <div className="grid" style={{ gridTemplateColumns: '2fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 0.5fr', gap: '12px', alignItems: 'end' }}>
                
                <div><label>Description</label><input type="text" value={item.description} onChange={(e) => handleItemChange(index, 'description', e.target.value)} required placeholder="e.g. Gold Ring" /></div>
                
                <div><label>Metal</label>
                  <select value={item.metalType} onChange={(e) => handleItemChange(index, 'metalType', e.target.value)}>
                    <option value="GOLD">Gold</option><option value="SILVER">Silver</option>
                  </select>
                </div>
                
                {/* 👉 The Quantity Field! */}
                <div><label>Qty</label><input type="number" value={item.quantity} onChange={(e) => handleItemChange(index, 'quantity', e.target.value)} min="1" required /></div>
                
                <div><label>Gross Wt (g)</label><input type="number" step="0.001" value={item.grossWeight} onChange={(e) => handleItemChange(index, 'grossWeight', e.target.value)} required /></div>
                
                <div><label>Stone Wt (g)</label><input type="number" step="0.001" value={item.stoneWeight} onChange={(e) => handleItemChange(index, 'stoneWeight', e.target.value)} /></div>
                
                <div><label>Rate /g (₹)</label><input type="number" value={item.ratePerGram} onChange={(e) => handleItemChange(index, 'ratePerGram', e.target.value)} required /></div>
                
                <div><label>Making (₹)</label><input type="number" value={item.makingCharge} onChange={(e) => handleItemChange(index, 'makingCharge', e.target.value)} /></div>
                
                <div><label>HUID (Opt)</label><input type="text" value={item.huidNumber} onChange={(e) => handleItemChange(index, 'huidNumber', e.target.value)} placeholder="6-digit" /></div>
                
                <div>
                  <button type="button" className="ghost" style={{ color: '#d9534f', padding: '8px' }} onClick={() => removeLineItem(index)} title="Remove Item">✖</button>
                </div>
              </div>
            </div>
          ))}

          <button type="button" className="ghost" onClick={addLineItem} style={{ marginBottom: '24px' }}>
            + Add Another Item
          </button>

          <hr className="section-divider" />
          
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 12 }}>
            <button type="button" className="ghost" onClick={() => navigate('/purchases')}>Cancel</button>
            <button type="submit" className="primary" disabled={isSubmitting}>
              {isSubmitting ? 'Saving Invoice...' : 'Save Purchase Bill'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}