import React, { useEffect, useState } from 'react';
import { useToast } from '../../context/ToastContext.jsx';

const TABS = ['Sales Register', 'GST Summary', 'Stock Valuation', 'Outstanding Dues', 'Trend & Categories'];

export default function Reports() {
  const { showError } = useToast();
  const [tab, setTab] = useState(TABS[0]);
  const [fromDate, setFromDate] = useState(new Date().toISOString().slice(0, 8) + '01');
  const [toDate, setToDate] = useState(new Date().toISOString().slice(0, 10));

  const [sales, setSales] = useState([]);
  const [summary, setSummary] = useState(null);
  const [gst, setGst] = useState([]);
  const [stock, setStock] = useState([]);
  const [dues, setDues] = useState({ customers: [], suppliers: [], karigars: [] });
  const [trend, setTrend] = useState([]);
  const [topCategories, setTopCategories] = useState([]);

  useEffect(() => {
    if (tab === 'Sales Register') {
      window.api.reports.salesRegister(fromDate, toDate).then(setSales).catch(showError);
      window.api.reports.salesSummary(fromDate, toDate).then(setSummary).catch(showError);
    } else if (tab === 'GST Summary') {
      window.api.reports.gstSummary(fromDate, toDate).then(setGst).catch(showError);
    } else if (tab === 'Stock Valuation') {
      window.api.reports.stockSummary().then(setStock).catch(showError);
    } else if (tab === 'Outstanding Dues') {
      Promise.all([
        window.api.reports.outstandingCustomers(),
        window.api.reports.outstandingSuppliers(),
        window.api.reports.outstandingKarigars(),
      ]).then(([customers, suppliers, karigars]) => setDues({ customers, suppliers, karigars })).catch(showError);
    } else if (tab === 'Trend & Categories') {
      Promise.all([
        window.api.reports.dailyTrend(fromDate, toDate),
        window.api.reports.topCategories(fromDate, toDate),
      ]).then(([dailyTrend, categories]) => {
        setTrend(dailyTrend);
        setTopCategories(categories);
      }).catch(showError);
    }
  }, [tab, fromDate, toDate]);

  return (
    <div>
      <h2 className="page-title">Reports</h2>
      <p className="page-subtitle">Sales, GST, stock and outstanding balance reports for your business.</p>

      <div className="toolbar">
        {TABS.map((t) => (
          <button key={t} className={tab === t ? 'primary' : 'ghost'} onClick={() => setTab(t)}>{t}</button>
        ))}
        {(tab === 'Sales Register' || tab === 'GST Summary') && (
          <>
            <div className="spacer" />
            <div style={{ display: 'flex', gap: '10px' }}>
              <input type="date" style={{ maxWidth: 160 }} value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
              <input type="date" style={{ maxWidth: 160 }} value={toDate} onChange={(e) => setToDate(e.target.value)} />
            </div>
          </>
        )}
      </div>

      {tab === 'Sales Register' && (
        <>
          {summary && (
            <div className="grid grid-4">
              <div className="card stat-card"><div className="label">Invoices</div><div className="value">{summary.invoice_count}</div></div>
              <div className="card stat-card"><div className="label">Taxable Amount</div><div className="value">₹{summary.taxable_amount.toLocaleString('en-IN')}</div></div>
              <div className="card stat-card"><div className="label">GST Collected</div><div className="value">₹{(summary.cgst_amount + summary.sgst_amount + summary.igst_amount).toLocaleString('en-IN')}</div></div>
              <div className="card stat-card"><div className="label">Grand Total</div><div className="value">₹{summary.grand_total.toLocaleString('en-IN')}</div></div>
            </div>
          )}
          <div className="card" style={{ padding: 0 }}>
            <table>
              <thead><tr><th>Invoice</th><th>Date</th><th>Customer</th><th>Taxable</th><th>CGST</th><th>SGST</th><th>IGST</th><th>Total</th><th>Status</th></tr></thead>
              <tbody>
                {sales.map((s, i) => (
                  <tr key={i}>
                    <td className="mono">{s.invoice_number}</td><td>{s.invoice_date}</td><td>{s.customer_name || 'Walk-in'}</td>
                    <td className="mono">₹{s.taxable_amount.toFixed(2)}</td><td className="mono">₹{s.cgst_amount.toFixed(2)}</td>
                    <td className="mono">₹{s.sgst_amount.toFixed(2)}</td><td className="mono">₹{s.igst_amount.toFixed(2)}</td>
                    <td className="mono">₹{s.grand_total.toFixed(2)}</td><td>{s.status}</td>
                  </tr>
                ))}
                {sales.length === 0 && <tr><td colSpan={9} className="muted center">No invoices in this period</td></tr>}
              </tbody>
            </table>
          </div>
        </>
      )}

      {tab === 'GST Summary' && (
        <div className="card" style={{ padding: 0 }}>
          <table>
            <thead><tr><th>HSN</th><th>CGST%</th><th>SGST%</th><th>IGST%</th><th>Lines</th><th>Taxable Value</th><th>CGST</th><th>SGST</th><th>IGST</th></tr></thead>
            <tbody>
              {gst.map((g, i) => (
                <tr key={i}>
                  <td>{g.hsn_code || '-'}</td><td>{g.cgst_rate}%</td><td>{g.sgst_rate}%</td><td>{g.igst_rate}%</td>
                  <td>{g.line_count}</td><td className="mono">₹{g.taxable_value.toFixed(2)}</td>
                  <td className="mono">₹{g.cgst_amount.toFixed(2)}</td><td className="mono">₹{g.sgst_amount.toFixed(2)}</td><td className="mono">₹{g.igst_amount.toFixed(2)}</td>
                </tr>
              ))}
              {gst.length === 0 && <tr><td colSpan={9} className="muted center">No data for this period</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'Stock Valuation' && (
        <div className="card" style={{ padding: 0 }}>
          <table>
            <thead><tr><th>Metal</th><th>Purity</th><th>Items</th><th>Net Wt</th><th>Rate/g</th><th>Est. Value</th></tr></thead>
            <tbody>
              {stock.map((v, i) => (
                <tr key={i}>
                  <td>{v.metal_type}</td><td>{v.purity_name}</td><td>{v.item_count}</td>
                  <td className="mono">{v.total_net_weight.toFixed(3)}</td><td className="mono">₹{v.current_rate_per_gram.toFixed(2)}</td>
                  <td className="mono">₹{v.estimated_value.toLocaleString('en-IN')}</td>
                </tr>
              ))}
              {stock.length === 0 && <tr><td colSpan={6} className="muted center">No stock in hand</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'Outstanding Dues' && (
        <div className="grid grid-3">
          <div className="card">
            <div className="card-title">Customers Owe Us</div>
            {dues.customers.map((c) => <div key={c.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0' }}><span>{c.name}</span><span className="mono">₹{c.current_balance.toLocaleString('en-IN')}</span></div>)}
            {dues.customers.length === 0 && <div className="muted">None</div>}
          </div>
          <div className="card">
            <div className="card-title">We Owe Suppliers</div>
            {dues.suppliers.map((s) => <div key={s.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0' }}><span>{s.name}</span><span className="mono">₹{s.current_balance.toLocaleString('en-IN')}</span></div>)}
            {dues.suppliers.length === 0 && <div className="muted">None</div>}
          </div>
          <div className="card">
            <div className="card-title">We Owe Karigars</div>
            {dues.karigars.map((k) => <div key={k.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0' }}><span>{k.name}</span><span className="mono">₹{k.current_balance.toLocaleString('en-IN')}</span></div>)}
            {dues.karigars.length === 0 && <div className="muted">None</div>}
          </div>
        </div>
      )}

      {tab === 'Trend & Categories' && (
        <div className="grid" style={{ gridTemplateColumns: '1.2fr 0.8fr' }}>
          <div className="card" style={{ padding: 0 }}>
            <div style={{ padding: 16, borderBottom: '1px solid var(--border)' }}>
              <div className="card-title" style={{ margin: 0 }}>Daily Sales Trend</div>
              <div className="muted">Invoice count and sales by day for the selected period.</div>
            </div>
            <table>
              <thead><tr><th>Date</th><th>Invoices</th><th>Total Sales</th></tr></thead>
              <tbody>
                {trend.map((row) => (
                  <tr key={row.invoice_date}>
                    <td>{row.invoice_date}</td>
                    <td>{row.invoice_count}</td>
                    <td className="mono">₹{Number(row.total_sales || 0).toLocaleString('en-IN')}</td>
                  </tr>
                ))}
                {trend.length === 0 && <tr><td colSpan={3} className="muted center">No trend data for this period</td></tr>}
              </tbody>
            </table>
          </div>

          <div className="card" style={{ padding: 0 }}>
            <div style={{ padding: 16, borderBottom: '1px solid var(--border)' }}>
              <div className="card-title" style={{ margin: 0 }}>Top Selling Categories</div>
              <div className="muted">Best-performing categories by billed value.</div>
            </div>
            <table>
              <thead><tr><th>Category</th><th>Pieces</th><th>Value</th></tr></thead>
              <tbody>
                {topCategories.map((row) => (
                  <tr key={row.category_name || '-' }>
                    <td>{row.category_name || 'Uncategorized'}</td>
                    <td>{row.pieces_sold}</td>
                    <td className="mono">₹{Number(row.total_value || 0).toLocaleString('en-IN')}</td>
                  </tr>
                ))}
                {topCategories.length === 0 && <tr><td colSpan={3} className="muted center">No category data for this period</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
