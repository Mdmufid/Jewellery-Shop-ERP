import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Modal from '../../components/Modal.jsx';
import { useToast } from '../../context/ToastContext.jsx';

function ArtisanForm({ onClose, onSaved }) {
  const { showToast, showError } = useToast();
  const [form, setForm] = useState({ name: '', phone: '', address: '', specialty: '', makingChargeType: 'PER_GRAM', defaultRate: '' });
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name) { showError(new Error('Artisan name is required')); return; }
    setSaving(true);
    try {
      await window.api.artisans.create({ ...form, defaultRate: parseFloat(form.defaultRate) || 0 });
      showToast('Artisan added');
      onSaved();
    } catch (err) { showError(err); } finally { setSaving(false); }
  };

  return (
    <Modal title="Add Artisan" onClose={onClose}>
      <form onSubmit={handleSubmit}>
        <div className="inline-fields">
          <div className="field"><label>Name *</label><input value={form.name} onChange={set('name')} /></div>
          <div className="field"><label>Phone</label><input value={form.phone} onChange={set('phone')} /></div>
        </div>
        <div className="field"><label>Address</label><input value={form.address} onChange={set('address')} /></div>
        <div className="inline-fields">
          <div className="field"><label>Specialty</label><input value={form.specialty} onChange={set('specialty')} placeholder="e.g. Rings, Kundan work" /></div>
          <div className="field"><label>Default Making Charge Type</label>
            <select value={form.makingChargeType} onChange={set('makingChargeType')}>
              <option value="PER_GRAM">Per Gram</option><option value="FIXED">Fixed</option><option value="PERCENTAGE">% of Metal Value</option>
            </select>
          </div>
          <div className="field"><label>Default Rate</label><input type="number" step="0.01" value={form.defaultRate} onChange={set('defaultRate')} /></div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <button type="button" className="ghost" onClick={onClose}>Cancel</button>
          <button type="submit" className="primary" disabled={saving}>{saving ? 'Saving...' : 'Save'}</button>
        </div>
      </form>
    </Modal>
  );
}

function IssueJobForm({ artisans, onClose, onSaved }) {
  const { showToast, showError } = useToast();
  const [purities, setPurities] = useState([]);
  const [form, setForm] = useState({
    artisanId: '', issueDate: new Date().toISOString().slice(0, 10), metalType: 'GOLD',
    purityId: '', metalIssuedWeight: '', expectedItemDescription: '', notes: '',
  });
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  useEffect(() => { window.api.rates.listPurities().then(setPurities).catch(showError); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.artisanId || !form.purityId || !form.metalIssuedWeight) { showError(new Error('Fill in artisan, purity and weight issued')); return; }
    setSaving(true);
    try {
      const job = await window.api.artisans.issueJob({
        ...form, artisanId: Number(form.artisanId), purityId: Number(form.purityId),
        metalIssuedWeight: parseFloat(form.metalIssuedWeight),
      });
      showToast(`Job ${job.job_number} issued`);
      onSaved();
    } catch (err) { showError(err); } finally { setSaving(false); }
  };

  return (
    <Modal title="Issue Metal for Job Work" onClose={onClose}>
      <form onSubmit={handleSubmit}>
        <div className="field">
          <label>Artisan *</label>
          <select value={form.artisanId} onChange={set('artisanId')}>
            <option value="">Select artisan</option>
            {artisans.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
          </select>
        </div>
        <div className="inline-fields">
          <div className="field"><label>Issue Date</label><input type="date" value={form.issueDate} onChange={set('issueDate')} /></div>
          <div className="field">
            <label>Metal *</label>
            <select value={form.metalType} onChange={(e) => setForm((f) => ({ ...f, metalType: e.target.value, purityId: '' }))}>
              <option value="GOLD">Gold</option><option value="SILVER">Silver</option><option value="PLATINUM">Platinum</option>
            </select>
          </div>
          <div className="field">
            <label>Purity *</label>
            <select value={form.purityId} onChange={set('purityId')}>
              <option value="">Select</option>
              {purities.filter((p) => p.metal_type === form.metalType).map((p) => <option key={p.id} value={p.id}>{p.purity_name}</option>)}
            </select>
          </div>
        </div>
        <div className="field"><label>Metal Weight Issued (g) *</label><input type="number" step="0.001" value={form.metalIssuedWeight} onChange={set('metalIssuedWeight')} /></div>
        <div className="field"><label>Expected Item</label><input value={form.expectedItemDescription} onChange={set('expectedItemDescription')} placeholder="e.g. 22K Gold Bangle Pair" /></div>
        <div className="field"><label>Notes</label><textarea rows={2} value={form.notes} onChange={set('notes')} /></div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <button type="button" className="ghost" onClick={onClose}>Cancel</button>
          <button type="submit" className="primary" disabled={saving}>{saving ? 'Issuing...' : 'Issue Job'}</button>
        </div>
      </form>
    </Modal>
  );
}

export default function Artisans() {
  const { showError } = useToast();
  const [artisans, setArtisans] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [showArtisanForm, setShowArtisanForm] = useState(false);
  const [showJobForm, setShowJobForm] = useState(false);
  const [showLossReport, setShowLossReport] = useState(false);
  const [lossReportResult, setLossReportResult] = useState(null);

  const load = () => {
    window.api.artisans.list().then(setArtisans).catch(showError);
    window.api.artisans.listJobs().then(setJobs).catch(showError);
  };
  useEffect(() => { load(); }, []);

  const fetchLossReport = async (filters) => {
    try {
      const res = await window.api.artisans.lossReport(filters);
      setLossReportResult(res);
    } catch (err) { showError(err); }
  };

  function LossReportForm({ onClose }) {
    const [from, setFrom] = useState('');
    const [to, setTo] = useState('');
    const [artisanId, setArtisanId] = useState('');
    const { showError: showErr } = useToast();
    const run = async (e) => {
      e && e.preventDefault();
      try {
        await fetchLossReport({ from: from || undefined, to: to || undefined, artisanId: artisanId ? Number(artisanId) : undefined });
      } catch (err) { showErr(err); }
    };
    return (
      <Modal title="Artisan Loss Report" onClose={onClose} width={700}>
        <form onSubmit={run}>
          <div className="inline-fields">
            <div className="field"><label>From</label><input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></div>
            <div className="field"><label>To</label><input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></div>
            <div className="field"><label>Artisan</label>
              <select value={artisanId} onChange={(e) => setArtisanId(e.target.value)}>
                <option value="">All</option>
                {artisans.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
            <button type="button" className="ghost" onClick={onClose}>Close</button>
            <button type="submit" className="primary">Run Report</button>
          </div>
        </form>
        {lossReportResult && (
          <div style={{ marginTop: 12 }}>
            <div><b>Jobs:</b> {lossReportResult.totalJobs} — <b>Issued:</b> {lossReportResult.totalIssued}g — <b>Wastage:</b> {lossReportResult.totalWastage}g ({lossReportResult.avgWastagePercent}%)</div>
            <div><b>Total Making:</b> ₹{lossReportResult.totalMaking} — <b>Exceeded:</b> {lossReportResult.exceedCount} jobs — Allowed: {lossReportResult.allowedPercent}%</div>
            <table style={{ marginTop: 8, width: '100%' }}>
              <thead><tr><th>Job</th><th>Artisan</th><th>Issued</th><th>Wastage</th><th>%</th><th>Making</th></tr></thead>
              <tbody>
                {lossReportResult.excessiveJobs.map((r) => (
                  <tr key={r.id}><td className="mono">{r.job_number}</td><td>{r.artisan_name}</td><td className="mono">{r.issued}g</td><td className="mono">{r.wastage}g</td><td className="mono">{r.wastagePercent}%</td><td className="mono">₹{r.making_charge_amount || 0}</td></tr>
                ))}
                {lossReportResult.excessiveJobs.length === 0 && <tr><td colSpan={6} className="muted center">No excessive jobs in this range</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </Modal>
    );
  }

  return (
    <div>
      <h2 className="page-title">Artisans / Job Work</h2>
      <p className="page-subtitle">Track metal issued to goldsmiths, wastage, and making charges owed.</p>

      <div className="toolbar">
        <div className="spacer" />
        <button className="ghost" onClick={() => setShowArtisanForm(true)}>+ Add Artisan</button>
        <button className="primary" onClick={() => setShowJobForm(true)} disabled={artisans.length === 0}>+ Issue Job</button>
        <button className="ghost" onClick={() => setShowLossReport(true)} style={{ marginLeft: 8 }}>Loss Report</button>
      </div>

      <div className="card">
        <div className="card-title">Artisans</div>
        <table>
          <thead><tr><th>Name</th><th>Phone</th><th>Specialty</th><th>Balance Payable</th></tr></thead>
          <tbody>
            {artisans.map((a) => (
              <tr key={a.id}>
                <td><Link to={`/artisans/${a.id}`}>{a.name}</Link></td>
                <td>{a.phone || '-'}</td>
                <td>{a.specialty || '-'}</td>
                {/* Note: Updated this column to match the dual-ledger schema we built earlier */}
                <td className="mono">₹{Number(a.cash_balance || 0).toLocaleString('en-IN')}</td>
              </tr>
            ))}
            {artisans.length === 0 && <tr><td colSpan={4} className="muted center">No artisans added yet</td></tr>}
          </tbody>
        </table>
      </div>

      <div className="card">
        <div className="card-title">Job Work Orders</div>
        <table>
          <thead><tr><th>Job No</th><th>Artisan</th><th>Issue Date</th><th>Metal Issued</th><th>Status</th></tr></thead>
          <tbody>
            {jobs.map((j) => (
              <tr key={j.id}>
                <td className="mono">{j.job_number}</td>
                <td>{j.artisan_name}</td>
                <td>{j.issue_date}</td>
                <td className="mono">{j.metal_issued_weight}g {j.metal_type} ({j.purity_name})</td>
                <td><span className={`badge ${j.status === 'RECEIVED' ? 'green' : 'gold'}`}>{j.status}</span></td>
              </tr>
            ))}
            {jobs.length === 0 && <tr><td colSpan={5} className="muted center">No job work orders yet</td></tr>}
          </tbody>
        </table>
      </div>

      {showArtisanForm && <ArtisanForm onClose={() => setShowArtisanForm(false)} onSaved={() => { setShowArtisanForm(false); load(); }} />}
      {showJobForm && <IssueJobForm artisans={artisans} onClose={() => setShowJobForm(false)} onSaved={() => { setShowJobForm(false); load(); }} />}
      {showLossReport && <LossReportForm onClose={() => { setShowLossReport(false); setLossReportResult(null); }} />}
    </div>
  );
}