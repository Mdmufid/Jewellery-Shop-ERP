import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useToast } from '../../context/ToastContext.jsx';
import Modal from '../../components/Modal.jsx';

export default function ArtisanDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { showError, showToast } = useToast();

  const [artisan, setArtisan] = useState(null);
  const [metalLedger, setMetalLedger] = useState([]);
  const [cashLedger, setCashLedger] = useState([]);
  const [loading, setLoading] = useState(true);

  // Modal states
  const [showIssueMetal, setShowIssueMetal] = useState(false);
  const [showReceiveGoods, setShowReceiveGoods] = useState(false);
  const [showPayArtisan, setShowPayArtisan] = useState(false);

  const loadData = async () => {
    try {
      const artData = await window.api.artisans.getById(Number(id));
      if (!artData) throw new Error('Artisan not found');
      setArtisan(artData);

      const mData = await window.api.artisans.metalLedger(Number(id));
      setMetalLedger(mData || []);

      const cData = await window.api.artisans.cashLedger(Number(id));
      setCashLedger(cData || []);
    } catch (error) {
      showError(error);
      navigate('/artisans');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [id]);

  // --- MODAL COMPONENTS ---

  const IssueMetalModal = () => {
    const [weight, setWeight] = useState('');
    const [notes, setNotes] = useState('');
    const [saving, setSaving] = useState(false);

    const submit = async (e) => {
      e.preventDefault();
      setSaving(true);
      try {
        await window.api.artisans.issueMetal({ artisanId: artisan.id, weight, notes });
        showToast('Metal issued successfully');
        setShowIssueMetal(false);
        loadData();
      } catch (err) { showError(err); } finally { setSaving(false); }
    };

    return (
      <Modal title="Issue Raw Metal" onClose={() => setShowIssueMetal(false)}>
        <form onSubmit={submit}>
          <div className="field"><label>Fine Weight (Grams) *</label><input type="number" step="0.001" required value={weight} onChange={e => setWeight(e.target.value)} /></div>
          <div className="field"><label>Notes</label><input type="text" value={notes} onChange={e => setNotes(e.target.value)} placeholder="e.g. 24K Pure Gold piece" /></div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 20 }}>
            <button type="button" className="ghost" onClick={() => setShowIssueMetal(false)}>Cancel</button>
            <button type="submit" className="primary" disabled={saving}>{saving ? 'Saving...' : 'Issue Metal'}</button>
          </div>
        </form>
      </Modal>
    );
  };

  const PayArtisanModal = () => {
    const [amount, setAmount] = useState('');
    const [paymentMode, setPaymentMode] = useState('CASH');
    const [notes, setNotes] = useState('');
    const [saving, setSaving] = useState(false);

    const submit = async (e) => {
      e.preventDefault();
      setSaving(true);
      try {
        await window.api.artisans.pay({ artisanId: artisan.id, amount, paymentMode, notes });
        showToast('Payment recorded successfully');
        setShowPayArtisan(false);
        loadData();
      } catch (err) { showError(err); } finally { setSaving(false); }
    };

    return (
      <Modal title="Pay Artisan (Making Charges)" onClose={() => setShowPayArtisan(false)}>
        <form onSubmit={submit}>
          <div className="field"><label>Amount (₹) *</label><input type="number" required value={amount} onChange={e => setAmount(e.target.value)} /></div>
          <div className="field"><label>Payment Mode</label>
            <select value={paymentMode} onChange={e => setPaymentMode(e.target.value)}>
              <option value="CASH">Cash</option><option value="BANK_TRANSFER">Bank Transfer</option><option value="UPI">UPI</option>
            </select>
          </div>
          <div className="field"><label>Notes</label><input type="text" value={notes} onChange={e => setNotes(e.target.value)} /></div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 20 }}>
            <button type="button" className="ghost" onClick={() => setShowPayArtisan(false)}>Cancel</button>
            <button type="submit" className="primary" disabled={saving}>{saving ? 'Processing...' : 'Record Payment'}</button>
          </div>
        </form>
      </Modal>
    );
  };

  const ReceiveGoodsModal = () => {
    const [form, setForm] = useState({
      description: '', grossWeight: '', stoneWeight: '', fineWeightUsed: '', 
      wastagePercent: '0', makingChargeTotal: '', quantity: '1', metalType: 'GOLD', purityId: '2' // 2 = 22K generally
    });
    const [saving, setSaving] = useState(false);
    const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

    const submit = async (e) => {
      e.preventDefault();
      setSaving(true);
      try {
        await window.api.artisans.receiveGoods({ 
          ...form, artisanId: artisan.id, 
          grossWeight: Number(form.grossWeight), stoneWeight: Number(form.stoneWeight || 0),
          fineWeightUsed: Number(form.fineWeightUsed), wastagePercent: Number(form.wastagePercent),
          makingChargeTotal: Number(form.makingChargeTotal), quantity: Number(form.quantity), purityId: Number(form.purityId)
        });
        showToast('Item received and added to inventory!');
        setShowReceiveGoods(false);
        loadData();
      } catch (err) { showError(err); } finally { setSaving(false); }
    };

    return (
      <Modal title="Receive Finished Jewelry" onClose={() => setShowReceiveGoods(false)}>
        <form onSubmit={submit}>
          <div className="grid grid-2" style={{ gap: 12 }}>
            <div className="field"><label>Item Name *</label><input required value={form.description} onChange={set('description')} placeholder="e.g. Gold Ring" /></div>
            <div className="field"><label>Quantity</label><input type="number" required min="1" value={form.quantity} onChange={set('quantity')} /></div>
            <div className="field"><label>Gross Wt (g) *</label><input type="number" step="0.001" required value={form.grossWeight} onChange={set('grossWeight')} /></div>
            <div className="field"><label>Stone Wt (g)</label><input type="number" step="0.001" value={form.stoneWeight} onChange={set('stoneWeight')} /></div>
            
            {/* The Metal Ledger Deduction */}
            <div className="field" style={{ backgroundColor: 'rgba(240, 173, 78, 0.1)', padding: 10, borderRadius: 4 }}>
              <label style={{ color: '#f0ad4e' }}>Total Fine Metal Deducted (g) *</label>
              <input type="number" step="0.001" required value={form.fineWeightUsed} onChange={set('fineWeightUsed')} placeholder="Includes wastage/ghat" />
            </div>
            
            {/* The Cash Ledger Addition */}
            <div className="field" style={{ backgroundColor: 'rgba(217, 83, 79, 0.1)', padding: 10, borderRadius: 4 }}>
              <label style={{ color: '#d9534f' }}>Total Making Charge (₹) *</label>
              <input type="number" required value={form.makingChargeTotal} onChange={set('makingChargeTotal')} />
            </div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 20 }}>
            <button type="button" className="ghost" onClick={() => setShowReceiveGoods(false)}>Cancel</button>
            <button type="submit" className="primary" disabled={saving}>{saving ? 'Processing...' : 'Receive to Inventory'}</button>
          </div>
        </form>
      </Modal>
    );
  };

  if (loading || !artisan) return <div style={{ padding: 20 }}>Loading...</div>;

  return (
    <div>
      <button className="ghost" onClick={() => navigate('/artisans')}>← Back to Artisans</button>
      
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 14 }}>
        <div>
          <h2>{artisan.name}</h2>
          <span className="muted">{artisan.phone} | {artisan.address || 'No Address'}</span>
        </div>
        <div style={{ display: 'flex', gap: 12 }}>
          <button className="ghost" style={{ border: '1px solid #f0ad4e', color: '#f0ad4e' }} onClick={() => setShowIssueMetal(true)}>
            + Issue Metal
          </button>
          <button className="primary" onClick={() => setShowReceiveGoods(true)}>
            ↓ Receive Finished Item
          </button>
          <button className="ghost" style={{ border: '1px solid #d9534f', color: '#d9534f' }} onClick={() => setShowPayArtisan(true)}>
            ₹ Pay Artisan
          </button>
        </div>
      </div>

      <div className="grid grid-2" style={{ gap: 20, marginTop: 24 }}>
        
        {/* METAL LEDGER VIEW */}
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
            <h3>Metal Ledger</h3>
            <h3 style={{ color: artisan.metal_balance > 0 ? '#f0ad4e' : 'inherit' }}>
              Balance: {Number(artisan.metal_balance).toFixed(3)} g
            </h3>
          </div>
          <table style={{ fontSize: '13px' }}>
            <thead><tr><th>Date</th><th>Type</th><th>In (Received)</th><th>Out (Issued)</th><th>Balance</th></tr></thead>
            <tbody>
              {metalLedger.map(m => (
                <tr key={m.id}>
                  <td className="muted">{new Date(m.created_at).toLocaleDateString()}</td>
                  <td>{m.transaction_type.replace('_', ' ')}</td>
                  <td className="mono">{m.weight_in > 0 ? `${m.weight_in}g` : '-'}</td>
                  <td className="mono">{m.weight_out > 0 ? `${m.weight_out}g` : '-'}</td>
                  <td className="mono" style={{ fontWeight: 'bold' }}>{m.balance}g</td>
                </tr>
              ))}
              {metalLedger.length === 0 && <tr><td colSpan="5" className="center muted">No metal transactions</td></tr>}
            </tbody>
          </table>
        </div>

        {/* CASH LEDGER VIEW */}
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
            <h3>Cash Ledger</h3>
            <h3 style={{ color: artisan.cash_balance > 0 ? '#d9534f' : 'inherit' }}>
              Balance: ₹{Number(artisan.cash_balance).toLocaleString('en-IN')}
            </h3>
          </div>
          <table style={{ fontSize: '13px' }}>
            <thead><tr><th>Date</th><th>Type</th><th>Debit (Paid)</th><th>Credit (Earned)</th><th>Balance</th></tr></thead>
            <tbody>
              {cashLedger.map(c => (
                <tr key={c.id}>
                  <td className="muted">{new Date(c.created_at).toLocaleDateString()}</td>
                  <td>{c.transaction_type.replace('_', ' ')}</td>
                  <td className="mono">{c.debit > 0 ? `₹${c.debit}` : '-'}</td>
                  <td className="mono">{c.credit > 0 ? `₹${c.credit}` : '-'}</td>
                  <td className="mono" style={{ fontWeight: 'bold' }}>₹{c.balance}</td>
                </tr>
              ))}
              {cashLedger.length === 0 && <tr><td colSpan="5" className="center muted">No cash transactions</td></tr>}
            </tbody>
          </table>
        </div>

      </div>

      {showIssueMetal && <IssueMetalModal />}
      {showPayArtisan && <PayArtisanModal />}
      {showReceiveGoods && <ReceiveGoodsModal />}
    </div>
  );
}