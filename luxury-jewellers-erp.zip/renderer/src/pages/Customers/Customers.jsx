import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Modal from '../../components/Modal.jsx';
import { useToast } from '../../context/ToastContext.jsx';

function CustomerForm({ customer, onClose, onSaved }) {
  const { showToast, showError } = useToast();
  const [form, setForm] = useState({
    name: customer?.name || '', phone: customer?.phone || '', email: customer?.email || '',
    gstin: customer?.gstin || '', address: customer?.address || '', city: customer?.city || '',
    stateCode: customer?.state_code || '27', panNumber: customer?.pan_number || '',
    openingBalance: customer?.opening_balance ?? 0,
    dateOfBirth: customer?.date_of_birth || '', anniversaryDate: customer?.anniversary_date || '',
    photoPath: customer?.photo_path || '', secondaryPhone: customer?.secondary_phone || '', address2: customer?.address2 || '', zipCode: customer?.zip_code || '',
    preferredContact: customer?.preferred_contact || '', communicationSms: customer?.communication_sms ? true : false, communicationWhatsapp: customer?.communication_whatsapp ? true : false,
  });
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const toFileUrl = (filePath) => {
    if (!filePath) return '';
    return `file:///${String(filePath).replace(/\\/g, '/')}`;
  };

  const pickPath = (key) => (e) => {
    const file = e.target.files && e.target.files[0];
    if (file?.path) setForm((f) => ({ ...f, [key]: file.path }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name) { showError(new Error('Customer name is required')); return; }
    setSaving(true);
    try {
      if (customer) {
        await window.api.customers.update(customer.id, form);
        showToast('Customer updated');
      } else {
        await window.api.customers.create({ ...form, openingBalance: parseFloat(form.openingBalance) || 0 });
        showToast('Customer added');
      }
      onSaved();
    } catch (err) { showError(err); } finally { setSaving(false); }
  };

  return (
    <Modal title={customer ? 'Edit Customer' : 'Add Customer'} onClose={onClose}>
      <form onSubmit={handleSubmit}>
        <div className="inline-fields">
          <div className="field"><label>Name *</label><input value={form.name} onChange={set('name')} /></div>
          <div className="field"><label>Phone</label><input value={form.phone} onChange={set('phone')} /></div>
        </div>
        <div className="inline-fields">
          <div className="field"><label>Email</label><input value={form.email} onChange={set('email')} /></div>
          <div className="field"><label>GSTIN (if business)</label><input value={form.gstin} onChange={set('gstin')} /></div>
        </div>
        <div className="field"><label>Address</label><textarea rows={2} value={form.address} onChange={set('address')} /></div>
        <div className="inline-fields">
          <div className="field"><label>City</label><input value={form.city} onChange={set('city')} /></div>
          <div className="field"><label>State Code</label><input value={form.stateCode} onChange={set('stateCode')} /></div>
          <div className="field"><label>PAN</label><input value={form.panNumber} onChange={set('panNumber')} /></div>
        </div>
        <div className="inline-fields">
          <div className="field"><label>Date of Birth</label><input type="date" value={form.dateOfBirth} onChange={set('dateOfBirth')} /></div>
          <div className="field"><label>Anniversary</label><input type="date" value={form.anniversaryDate} onChange={set('anniversaryDate')} /></div>
          {!customer && <div className="field"><label>Opening Balance (₹)</label><input type="number" value={form.openingBalance} onChange={set('openingBalance')} /></div>}
        </div>
        <div className="inline-fields">
          <div className="field">
            <label>Secondary Phone</label>
            <input value={form.secondaryPhone} onChange={set('secondaryPhone')} />
          </div>
          <div className="field">
            <label>Address Line 2</label>
            <input value={form.address2} onChange={set('address2')} />
          </div>
          <div className="field">
            <label>ZIP / PIN</label>
            <input value={form.zipCode} onChange={set('zipCode')} />
          </div>
        </div>
        <div className="inline-fields">
          <div className="field">
            <label>Preferred Contact</label>
            <select value={form.preferredContact} onChange={set('preferredContact')}>
              <option value="">No preference</option>
              <option value="PHONE">Phone</option>
              <option value="WHATSAPP">WhatsApp</option>
              <option value="SMS">SMS</option>
              <option value="EMAIL">Email</option>
            </select>
          </div>
          <div className="field">
            <label>Communication - SMS</label>
            <input type="checkbox" checked={!!form.communicationSms} onChange={() => setForm((f) => ({ ...f, communicationSms: !f.communicationSms }))} />
          </div>
          <div className="field">
            <label>Communication - WhatsApp</label>
            <input type="checkbox" checked={!!form.communicationWhatsapp} onChange={() => setForm((f) => ({ ...f, communicationWhatsapp: !f.communicationWhatsapp }))} />
          </div>
        </div>
        <div className="inline-fields">
          <div className="field">
            <label>Profile Photo</label>
            <input type="file" accept="image/*" onChange={pickPath('photoPath')} />
            {form.photoPath && (
              <div style={{ marginTop: 8 }}>
                <img src={toFileUrl(form.photoPath)} alt="Profile" style={{ width: 120, height: 120, objectFit: 'cover', borderRadius: 8 }} />
              </div>
            )}
          </div>
          <div className="field">
            <label>KYC Document</label>
            <input type="file" accept=".pdf,image/*" onChange={pickPath('kycDocPath')} />
            {form.kycDocPath && <div className="muted" style={{ fontSize: 11, marginTop: 8 }}>{form.kycDocPath.split(/[\\/]/).pop()}</div>}
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <button type="button" className="ghost" onClick={onClose}>Cancel</button>
          <button type="submit" className="primary" disabled={saving}>{saving ? 'Saving...' : 'Save'}</button>
        </div>
      </form>
    </Modal>
  );
}

export default function Customers() {
  const { showError } = useToast();
  const [customers, setCustomers] = useState([]);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);

  const load = () => window.api.customers.list(search || undefined).then(setCustomers).catch(showError);
  useEffect(() => { load(); }, [search]);

  return (
    <div>
      <h2 className="page-title">Customers</h2>
      <p className="page-subtitle">Customer database and running account balance.</p>

      <div className="toolbar">
        <input className="search-box" placeholder="Search by name or phone..." value={search} onChange={(e) => setSearch(e.target.value)} />
        <div className="spacer" />
        <button className="primary" onClick={() => setShowForm(true)}>+ Add Customer</button>
      </div>

      <div className="card" style={{ padding: 0 }}>
        <table>
          <thead><tr><th>Name</th><th>Phone</th><th>City</th><th>Balance</th></tr></thead>
          <tbody>
            {customers.map((c) => (
              <tr key={c.id}>
                <td><Link to={`/customers/${c.id}`}>{c.name}</Link></td>
                <td>{c.phone || '-'}</td>
                <td>{c.city || '-'}</td>
                <td className="mono">₹{c.current_balance.toLocaleString('en-IN')}</td>
              </tr>
            ))}
            {customers.length === 0 && <tr><td colSpan={4} className="muted center">No customers yet</td></tr>}
          </tbody>
        </table>
      </div>

      {showForm && <CustomerForm onClose={() => setShowForm(false)} onSaved={() => { setShowForm(false); load(); }} />}
    </div>
  );
}
