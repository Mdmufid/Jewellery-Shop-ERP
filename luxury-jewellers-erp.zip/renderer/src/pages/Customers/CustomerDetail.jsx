import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useToast } from '../../context/ToastContext.jsx';

export default function CustomerDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  // Extract showToast alongside showError
  const { showError, showToast } = useToast(); 
  
  const [customer, setCustomer] = useState(null);
  const [ledger, setLedger] = useState([]);

  // Payment Form State
  const [isSettling, setIsSettling] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentMode, setPaymentMode] = useState('CASH');
  const [referenceNumber, setReferenceNumber] = useState('');
  const [paymentNotes, setPaymentNotes] = useState('');

  // Function to load/reload customer data
  const loadData = () => {
    window.api.customers.getById(Number(id)).then(setCustomer).catch(showError);
    window.api.customers.ledger(Number(id)).then(setLedger).catch(showError);
  };

  useEffect(() => {
    loadData();
  }, [id]);

  // The Payment Handler
  const handleSettleDue = async () => {
    if (!paymentAmount || isNaN(paymentAmount) || Number(paymentAmount) <= 0) {
      showError(new Error('Please enter a valid payment amount.'));
      return;
    }

    try {
      const payload = {
        customerId: Number(id),
        invoiceId: null, // Paying against the general account balance
        amount: parseFloat(paymentAmount),
        paymentMode: paymentMode,
        referenceNumber: referenceNumber,
        notes: paymentNotes || 'Settlement of due amount'
      };

      const response = await window.api.customers.receivePayment(payload);
      
      if (response.success) {
        showToast('Payment recorded and balances updated successfully!');
        
        // Reset the form
        setIsSettling(false);
        setPaymentAmount('');
        setReferenceNumber('');
        setPaymentNotes('');
        
        // Refresh the UI to show the new balance and ledger entry
        loadData(); 
      }
    } catch (error) {
      showError(new Error('Failed to process payment.'));
      console.error(error);
    }
  };

  const handlePrintReceipt = async (entry) => {
    try {
      await window.api.customers.printReceipt({
        customerName: customer.name,
        customerPhone: customer.phone || 'N/A',
        date: entry.created_at,
        amount: entry.credit,
        balance: entry.balance,
        notes: entry.notes
      });
    } catch (error) {
      showError(new Error('Failed to generate receipt.'));
      console.error(error);
    }
  };

  if (!customer) return <div className="muted">Loading...</div>;

  return (
    <div>
      <button className="ghost" onClick={() => navigate('/customers')}>← Back to Customers</button>

      <div className="card" style={{ marginTop: 14 }}>
        <div className="grid grid-3">
          <div>
            <label>Name</label>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              {customer.photo_path ? <img src={`file:///${String(customer.photo_path).replace(/\\/g, '/')}`} alt="Profile" style={{ width: 72, height: 72, objectFit: 'cover', borderRadius: 8 }} /> : null}
              <div>{customer.name}</div>
            </div>
          </div>
          <div><label>Phone</label><div>{customer.phone || '-'}</div></div>
          <div><label>Email</label><div>{customer.email || '-'}</div></div>
          <div><label>GSTIN</label><div>{customer.gstin || '-'}</div></div>
          <div><label>City / State</label><div>{customer.city || '-'} ({customer.state_code})</div></div>
          <div><label>Preferred Contact</label><div>{customer.preferred_contact || '-'}</div></div>
        </div>
        
        <hr className="section-divider" />
        
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div className="stat-card" style={{ padding: 0, border: 'none', background: 'transparent' }}>
            <div className="label">Current Balance</div>
            <div className="value" style={{ color: customer.current_balance > 0 ? '#d9534f' : 'inherit' }}>
              ₹{customer.current_balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
          </div>
          
          {customer.current_balance > 0 && !isSettling && (
            <button className="primary" onClick={() => setIsSettling(true)}>
              Receive Payment
            </button>
          )}
        </div>

        {/* Payment Form Section */}
        {isSettling && (
          <div style={{ 
            marginTop: 20, 
            padding: 20, 
            backgroundColor: 'rgba(0, 0, 0, 0.2)', /* Subtle dark inset */
            borderRadius: 8, 
            border: '1px solid rgba(255, 255, 255, 0.05)' /* Subtle border */
          }}>
            <h4 style={{ marginTop: 0, marginBottom: 16, color: 'var(--text-color, inherit)' }}>Record Payment</h4>
            <div className="grid grid-4" style={{ alignItems: 'end', gap: 16 }}>
              <div>
                <label>Amount (₹)</label>
                <input 
                  type="number" 
                  value={paymentAmount} 
                  onChange={(e) => setPaymentAmount(e.target.value)} 
                  placeholder="0.00" 
                />
              </div>
              <div>
                <label>Mode</label>
                <select value={paymentMode} onChange={(e) => setPaymentMode(e.target.value)}>
                  <option value="CASH">Cash</option>
                  <option value="UPI">UPI</option>
                  <option value="CARD">Card</option>
                  <option value="BANK_TRANSFER">Bank Transfer</option>
                  <option value="CHEQUE">Cheque</option>
                </select>
              </div>
              <div>
                <label>Ref Number (Optional)</label>
                <input 
                  type="text" 
                  value={referenceNumber} 
                  onChange={(e) => setReferenceNumber(e.target.value)} 
                  placeholder="UPI / Cheque No." 
                />
              </div>
              <div>
                <label>Notes</label>
                <input 
                  type="text" 
                  value={paymentNotes} 
                  onChange={(e) => setPaymentNotes(e.target.value)} 
                  placeholder="E.g., Cleared Diwali due" 
                />
              </div>
            </div>
            <div style={{ marginTop: 20, display: 'flex', gap: 12 }}>
              <button className="primary" onClick={handleSettleDue}>Save Payment</button>
              <button className="ghost" onClick={() => setIsSettling(false)}>Cancel</button>
            </div>
          </div>
        )}
      </div>

      <div className="card">
        <div className="card-title">Account Ledger</div>
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Type</th>
              <th>Debit</th>
              <th>Credit</th>
              <th>Balance</th>
              <th>Notes</th>
              <th style={{ textAlign: 'center' }}>Action</th> {/* 👉 New Column Header */}
            </tr>
          </thead>
          <tbody>
            {ledger.map((l) => (
              <tr key={l.id}>
                <td className="muted">{new Date(l.created_at).toLocaleDateString('en-IN')}</td>
                <td>{l.transaction_type}</td>
                <td className="mono" style={{ color: '#d9534f' }}>{l.debit ? `₹${l.debit.toFixed(2)}` : '-'}</td>
                <td className="mono" style={{ color: '#5cb85c' }}>{l.credit ? `₹${l.credit.toFixed(2)}` : '-'}</td>
                <td className="mono">₹{l.balance.toFixed(2)}</td>
                <td className="muted">{l.notes}</td>
                <td style={{ textAlign: 'center' }}>
                  {/* 👉 Show Print Button ONLY if it's a payment */}
                  {l.transaction_type === 'PAYMENT_RECEIVED' && (
                    <button 
                      className="ghost small" 
                      onClick={() => handlePrintReceipt(l)}
                      style={{ padding: '4px 8px', fontSize: '12px' }}
                    >
                      🖨️ Print
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {ledger.length === 0 && <tr><td colSpan={7} className="muted center">No transactions yet</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}