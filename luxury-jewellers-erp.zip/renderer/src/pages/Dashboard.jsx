import React, { useEffect, useState } from 'react';
import { useToast } from '../context/ToastContext.jsx';

function inr(n) {
  return `₹${Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

export default function Dashboard() {
  const { showError } = useToast();
  const [data, setData] = useState(null);

  useEffect(() => {
    window.api.reports.dashboard().then(setData).catch(showError);
  }, []);

  if (!data) return <div className="muted">Loading dashboard...</div>;

  const goldRates = (data.currentRates || []).filter((rate) => rate.metal_type === 'GOLD' && rate.rate_per_gram > 0).slice(0, 3);
  const silverRates = (data.currentRates || []).filter((rate) => rate.metal_type === 'SILVER' && rate.rate_per_gram > 0).slice(0, 1);
  const stockByMetal = data.stockByMetal || [];
  const topCategories = data.topCategories || [];

  return (
    <div>
      <h2 className="page-title">Dashboard</h2>
      <p className="page-subtitle">Snapshot of today's business at a glance.</p>

      <div className="grid grid-4">
        <div className="card stat-card">
          <div className="label">Today's Sales</div>
          <div className="value">{inr(data.todaySales.total)}</div>
          <div className="sub">{data.todaySales.cnt} invoice(s)</div>
        </div>
        <div className="card stat-card">
          <div className="label">This Month's Sales</div>
          <div className="value">{inr(data.monthSales.total)}</div>
          <div className="sub">{data.monthSales.cnt} invoice(s)</div>
        </div>
        <div className="card stat-card">
          <div className="label">Stock in Hand</div>
          <div className="value">{data.stockCount.cnt}</div>
          <div className="sub">{Number(data.stockCount.weight).toFixed(2)} g total net weight</div>
        </div>
        <div className="card stat-card">
          <div className="label">Customer Dues</div>
          <div className="value">{inr(data.custDue.total)}</div>
          <div className="sub">Outstanding receivable</div>
        </div>
      </div>

      <div className="grid grid-2" style={{ marginTop: 4 }}>
        <div className="card stat-card">
          <div className="label">Pending Old Gold Exchanges</div>
          <div className="value">{data.pendingOldGold.cnt}</div>
          <div className="sub">{inr(data.pendingOldGold.total)} awaiting adjustment</div>
        </div>
        <div className="card stat-card">
          <div className="label">Open Repairs</div>
          <div className="value">{data.pendingRepairs.cnt}</div>
          <div className="sub">{inr(data.pendingRepairs.total)} balance due</div>
        </div>
      </div>

      <div className="grid grid-2" style={{ marginTop: 4 }}>
        <div className="card" style={{ padding: 0 }}>
          <div style={{ padding: 16, borderBottom: '1px solid var(--border)' }}>
            <div className="card-title" style={{ margin: 0 }}>Today's Rate Board</div>
            <div className="muted">Live rates currently applied in billing.</div>
          </div>
          <table>
            <thead><tr><th>Metal</th><th>Purity</th><th>Rate / g</th></tr></thead>
            <tbody>
              {[...goldRates, ...silverRates].map((rate) => (
                <tr key={rate.id}>
                  <td>{rate.metal_type}</td>
                  <td>{rate.purity_name}</td>
                  <td className="mono">₹{Number(rate.rate_per_gram || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                </tr>
              ))}
              {goldRates.length === 0 && silverRates.length === 0 && <tr><td colSpan={3} className="muted center">No current rates configured</td></tr>}
            </tbody>
          </table>
        </div>

        <div className="card" style={{ padding: 0 }}>
          <div style={{ padding: 16, borderBottom: '1px solid var(--border)' }}>
            <div className="card-title" style={{ margin: 0 }}>Stock Breakdown</div>
            <div className="muted">Items and net weight grouped by metal type.</div>
          </div>
          <table>
            <thead><tr><th>Metal</th><th>Items</th><th>Net Weight</th></tr></thead>
            <tbody>
              {stockByMetal.map((row) => (
                <tr key={row.metal_type}>
                  <td>{row.metal_type}</td>
                  <td>{row.item_count}</td>
                  <td className="mono">{Number(row.total_net_weight || 0).toFixed(3)} g</td>
                </tr>
              ))}
              {stockByMetal.length === 0 && <tr><td colSpan={3} className="muted center">No stock in hand</td></tr>}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card" style={{ padding: 0, marginTop: 16 }}>
        <div style={{ padding: 16, borderBottom: '1px solid var(--border)' }}>
          <div className="card-title" style={{ margin: 0 }}>Top Selling Categories</div>
          <div className="muted">Best-performing categories for the current month.</div>
        </div>
        <table>
          <thead><tr><th>Category</th><th>Pieces Sold</th><th>Value</th></tr></thead>
          <tbody>
            {topCategories.map((row) => (
              <tr key={row.category_name || '-'}>
                <td>{row.category_name || 'Uncategorized'}</td>
                <td>{row.pieces_sold}</td>
                <td className="mono">₹{Number(row.total_value || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}</td>
              </tr>
            ))}
            {topCategories.length === 0 && <tr><td colSpan={3} className="muted center">No category data yet</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
