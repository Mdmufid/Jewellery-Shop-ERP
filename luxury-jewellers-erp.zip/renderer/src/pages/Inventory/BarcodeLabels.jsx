import React, { useEffect, useMemo, useRef, useState } from 'react';
import JsBarcode from 'jsbarcode';
import { useToast } from '../../context/ToastContext.jsx';

function Label({ item }) {
  const svgRef = useRef(null);
  const code = String(item.item_code || '');

  useEffect(() => {
    if (!svgRef.current || !code) return;
    JsBarcode(svgRef.current, code, {
      format: 'CODE128',
      displayValue: false,
      height: 42,
      width: 1.6,
      margin: 0,
      background: '#ffffff',
      lineColor: '#111111',
    });
  }, [code, svgRef]);

  return (
    <div className="barcode-label">
      <div className="barcode-label__header">
        <div>
          <div className="barcode-label__name">{item.name}</div>
          <div className="barcode-label__meta">{item.metal_type} / {item.purity_name}</div>
        </div>
        <div className="barcode-label__code">{item.item_code}</div>
      </div>
      <svg ref={svgRef} className="barcode-label__svg" />
      <div className="barcode-label__footer">
        <span>Gross {Number(item.gross_weight || 0).toFixed(3)} g</span>
        <span>Net {Number(item.net_weight || 0).toFixed(3)} g</span>
        <span>{item.huid_number || 'NO HUID'}</span>
      </div>
    </div>
  );
}

export default function BarcodeLabels() {
  const { showError, showToast } = useToast();
  const [search, setSearch] = useState('');
  const [items, setItems] = useState([]);
  const [selectedIds, setSelectedIds] = useState([]);
  const [copies, setCopies] = useState(1);

  useEffect(() => {
    const t = setTimeout(() => {
      window.api.inventory.list({ search: search || undefined, status: 'IN_STOCK' }).then(setItems).catch(showError);
    }, 200);
    return () => clearTimeout(t);
  }, [search]);

  const selectedItems = useMemo(
    () => items.filter((item) => selectedIds.includes(item.id)),
    [items, selectedIds],
  );

  const labelItems = useMemo(() => {
    const count = Math.max(1, Number(copies) || 1);
    return selectedItems.flatMap((item) => Array.from({ length: count }, () => item));
  }, [selectedItems, copies]);

  const toggleSelected = (item) => {
    setSelectedIds((current) => (current.includes(item.id) ? current.filter((id) => id !== item.id) : [...current, item.id]));
  };

  const selectAll = () => setSelectedIds(items.map((item) => item.id));
  const clearSelection = () => setSelectedIds([]);

  const handlePrint = () => {
    if (labelItems.length === 0) {
      showError(new Error('Select at least one item to print labels'));
      return;
    }
    window.print();
  };

  return (
    <div>
      <style>{`
        .barcode-labels-page { display: block; }
        .barcode-toolbar { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-bottom: 16px; }
        .barcode-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(290px, 1fr)); gap: 12px; }
        .barcode-label {
          border: 1px solid var(--border);
          border-radius: 12px;
          padding: 12px;
          background: #fff;
          box-shadow: 0 10px 24px rgba(0,0,0,0.08);
          page-break-inside: avoid;
        }
        .barcode-label__header { display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; margin-bottom: 8px; }
        .barcode-label__name { font-weight: 700; font-size: 13px; line-height: 1.25; }
        .barcode-label__meta { color: var(--muted); font-size: 11px; margin-top: 2px; }
        .barcode-label__code { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size: 12px; font-weight: 700; }
        .barcode-label__svg { width: 100%; height: 64px; display: block; }
        .barcode-label__footer { display: flex; justify-content: space-between; gap: 8px; font-size: 11px; margin-top: 6px; color: var(--muted); }
        @media print {
          body { background: #fff !important; }
          .sidebar, .topbar, .no-print { display: none !important; }
          .content { padding: 0 !important; }
          .barcode-toolbar { display: none !important; }
          .barcode-grid { grid-template-columns: repeat(3, 1fr); gap: 6px; }
          .barcode-label { box-shadow: none; border-radius: 6px; padding: 8px; }
        }
      `}</style>

      <div className="no-print">
        <h2 className="page-title">Barcode Labels</h2>
        <p className="page-subtitle">Select items and print barcode labels for counters, trays, and packaging.</p>

        <div className="toolbar barcode-toolbar">
          <input className="search-box" placeholder="Search item name, code, or HUID..." value={search} onChange={(e) => setSearch(e.target.value)} />
          <div className="field" style={{ maxWidth: 140 }}>
            <label>Copies per item</label>
            <input type="number" min="1" step="1" value={copies} onChange={(e) => setCopies(e.target.value)} />
          </div>
          <div className="spacer" />
          <button className="ghost" onClick={selectAll}>Select All</button>
          <button className="ghost" onClick={clearSelection}>Clear</button>
          <button className="primary" onClick={handlePrint}>Print Labels</button>
        </div>

        <div className="card" style={{ padding: 0 }}>
          <table>
            <thead>
              <tr><th></th><th>Item Code</th><th>Name</th><th>Metal / Purity</th><th>Net Wt</th><th>HUID</th></tr>
            </thead>
            <tbody>
              {items.map((item) => (
                <tr key={item.id}>
                  <td><input type="checkbox" checked={selectedIds.includes(item.id)} onChange={() => toggleSelected(item)} /></td>
                  <td className="mono">{item.item_code}</td>
                  <td>{item.name}</td>
                  <td>{item.metal_type} / {item.purity_name}</td>
                  <td className="mono">{Number(item.net_weight || 0).toFixed(3)} g</td>
                  <td className="muted">{item.huid_number || '-'}</td>
                </tr>
              ))}
              {items.length === 0 && <tr><td colSpan={6} className="muted center">No stock items found</td></tr>}
            </tbody>
          </table>
        </div>
      </div>

      {labelItems.length > 0 && (
        <div className="barcode-grid" style={{ marginTop: 16 }}>
          {labelItems.map((item, index) => <Label key={`${item.id}-${index}`} item={item} />)}
        </div>
      )}
    </div>
  );
}
