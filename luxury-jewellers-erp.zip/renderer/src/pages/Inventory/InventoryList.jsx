import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../../context/ToastContext.jsx';
import ItemFormModal from './ItemFormModal.jsx';

// ============================================================================
// NEW COMPONENT: AUDIT HISTORY MODAL
// ============================================================================
function AuditHistoryModal({ onClose }) {
  const { showToast, showError } = useToast();
  const [audits, setAudits] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    window.api.inventory.listAudits()
      .then(setAudits)
      .catch(showError)
      .finally(() => setLoading(false));
  }, []);

  const handlePrint = async (auditId) => {
    try {
      const res = await window.api.inventory.printAudit(auditId);
      showToast(`Audit PDF opened (${res.path})`);
    } catch (err) {
      showError(err);
    }
  };

  return (
    <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal" style={{ width: 700, maxHeight: '80vh', overflow: 'auto' }}>
        <div className="modal-header">
          <h3>Audit History</h3>
          <button className="ghost" onClick={onClose}>✕</button>
        </div>
        {loading ? <div className="muted">Loading history...</div> : (
          <table>
            <thead>
              <tr><th>Audit ID</th><th>Date</th><th>Title</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {audits.map(a => (
                <tr key={a.id}>
                  <td className="mono">#{a.id}</td>
                  <td>{a.audit_date}</td>
                  <td>{a.title}</td>
                  <td>
                    <span className={`badge ${a.status === 'COMPLETED' ? 'green' : 'gold'}`}>{a.status}</span>
                  </td>
                  <td>
                    {a.status === 'COMPLETED' && (
                      <button className="ghost" onClick={() => handlePrint(a.id)}>Print PDF</button>
                    )}
                  </td>
                </tr>
              ))}
              {audits.length === 0 && <tr><td colSpan="5" className="muted center">No audits found</td></tr>}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// EXISTING COMPONENT: STOCK AUDIT MODAL
// ============================================================================
function StockAuditModal({ onClose, onSaved }) {
  const { showToast, showError } = useToast();
  const [title, setTitle] = useState('Cycle Count');
  const [description, setDescription] = useState('');
  const [auditDate, setAuditDate] = useState(new Date().toISOString().slice(0, 10));
  const [audit, setAudit] = useState(null);
  const [rows, setRows] = useState([]);
  const [saving, setSaving] = useState(false);

  const startAudit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const created = await window.api.inventory.createAudit({ auditDate, title, description });
      setAudit(created);
      setRows((created.items || []).map((row) => ({
        ...row,
        counted_quantity: Number(row.counted_quantity ?? row.expected_quantity ?? 1),
        counted_weight: Number(row.counted_weight ?? row.expected_weight ?? 0),
        expected_quantity: Number(row.expected_quantity ?? 1),
        expected_weight: Number(row.expected_weight ?? 0),
        notes: row.notes || '',
      })));
      showToast('Audit started');
    } catch (err) { showError(err); } finally { setSaving(false); }
  };

  const saveRows = async () => {
    if (!audit) return;
    setSaving(true);
    try {
      await window.api.inventory.saveAuditItems(audit.id, rows.map((row) => ({
        item_id: row.item_id,
        expected_quantity: Number(row.expected_quantity || 0),
        expected_weight: Number(row.expected_weight || 0),
        counted_quantity: Number(row.counted_quantity ?? row.expected_quantity ?? 0),
        counted_weight: Number(row.counted_weight ?? row.expected_weight ?? 0),
        notes: row.notes || '',
      })));
      showToast('Audit counts saved');
    } catch (err) { showError(err); } finally { setSaving(false); }
  };

  const completeAudit = async () => {
    if (!audit) return;
    if (!window.confirm('Complete this audit and post stock adjustments?')) return;
    setSaving(true);
    try {
      await window.api.inventory.completeAudit(audit.id);
      showToast('Audit completed');
      onSaved();
    } catch (err) { showError(err); } finally { setSaving(false); }
  };

  const updateRow = (itemId, field, value) => {
    setRows((current) => current.map((row) => row.item_id === itemId ? { ...row, [field]: value } : row));
  };

  return (
    <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal" style={{ width: 920, maxHeight: '88vh', overflow: 'auto' }}>
        <div className="modal-header">
          <h3>Stock Audit / Cycle Count</h3>
          <button className="ghost" onClick={onClose}>✕</button>
        </div>

        {!audit ? (
          <form onSubmit={startAudit}>
            <div className="inline-fields">
              <div className="field"><label>Audit Date</label><input type="date" value={auditDate} onChange={(e) => setAuditDate(e.target.value)} /></div>
              <div className="field"><label>Title</label><input value={title} onChange={(e) => setTitle(e.target.value)} /></div>
            </div>
            <div className="field"><label>Description</label><textarea rows={3} value={description} onChange={(e) => setDescription(e.target.value)} /></div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
              <button type="button" className="ghost" onClick={onClose}>Cancel</button>
              <button type="submit" className="primary" disabled={saving}>{saving ? 'Starting...' : 'Start Audit'}</button>
            </div>
          </form>
        ) : (
          <>
            <div className="muted" style={{ marginBottom: 8 }}>Audit #{audit.id} • {audit.status === 'COMPLETED' ? 'Completed' : 'In progress'}</div>
            <table>
              <thead>
                <tr><th>Item</th><th>Expected Qty</th><th>Counted Qty</th><th>Expected Wt</th><th>Counted Wt</th><th>Notes</th></tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.item_id}>
                    <td>{row.name}</td>
                    <td className="mono">{Number(row.expected_quantity || 0)}</td>
                    <td><input type="number" min="0" step="1" value={row.counted_quantity} onChange={(e) => updateRow(row.item_id, 'counted_quantity', e.target.value)} /></td>
                    <td className="mono">{Number(row.expected_weight || 0).toFixed(3)}g</td>
                    <td><input type="number" min="0" step="0.001" value={row.counted_weight} onChange={(e) => updateRow(row.item_id, 'counted_weight', e.target.value)} /></td>
                    <td><input value={row.notes || ''} onChange={(e) => updateRow(row.item_id, 'notes', e.target.value)} /></td>
                  </tr>
                ))}
                {rows.length === 0 && <tr><td colSpan={6} className="muted center">No items available for audit</td></tr>}
              </tbody>
            </table>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 12 }}>
              <button type="button" className="ghost" onClick={onClose}>Close</button>
              <button type="button" className="ghost" onClick={saveRows} disabled={saving}>{saving ? 'Saving...' : 'Save Counts'}</button>
              <button type="button" className="primary" onClick={completeAudit} disabled={saving}>{saving ? 'Completing...' : 'Complete Audit'}</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// MAIN COMPONENT: INVENTORY LIST
// ============================================================================
export default function InventoryList() {
  const { showToast, showError } = useToast();
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  const [metalType, setMetalType] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [valuation, setValuation] = useState([]);
  const [showValuation, setShowValuation] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [selectedLedger, setSelectedLedger] = useState([]);
  
  // Modal States
  const [showAuditModal, setShowAuditModal] = useState(false);
  const [showAuditHistory, setShowAuditHistory] = useState(false); // NEW STATE ADDED

  const load = () => {
    window.api.inventory.list({ search: search || undefined, metalType: metalType || undefined })
      .then(setItems).catch(showError);
  };

  useEffect(() => { load(); }, [search, metalType]);

  const openAdd = () => { setEditingItem(null); setShowForm(true); };
  const openEdit = (item) => { setEditingItem(item); setShowForm(true); };

  const openDetails = async (item) => {
    try {
      const [details, ledger] = await Promise.all([
        window.api.inventory.getById(item.id),
        window.api.inventory.ledger(item.id),
      ]);
      setSelectedItem(details || item);
      setSelectedLedger(ledger || []);
    } catch (err) { showError(err); }
  };

  const handleSaved = () => { setShowForm(false); load(); };

  const handleDelete = async (item) => {
    if (!window.confirm(`Delete item ${item.item_code} — ${item.name}? This cannot be undone.`)) return;
    try {
      await window.api.inventory.delete(item.id);
      showToast('Item deleted');
      load();
    } catch (err) { showError(err); }
  };

  const openValuation = async () => {
    const v = await window.api.inventory.valuation().catch(showError);
    setValuation(v || []);
    setShowValuation(true);
  };

  const toFileUrl = (filePath) => {
    if (!filePath) return '';
    return `file:///${String(filePath).replace(/\\/g, '/')}`;
  };

  return (
    <div>
      <h2 className="page-title">Inventory</h2>
      <p className="page-subtitle">Manage stock items, weights, making charges and hallmark details.</p>

      <div className="toolbar">
        <input className="search-box" placeholder="Search by name, item code, or HUID..." value={search} onChange={(e) => setSearch(e.target.value)} />
        <select style={{ maxWidth: 160 }} value={metalType} onChange={(e) => setMetalType(e.target.value)}>
          <option value="">All Metals</option>
          <option value="GOLD">Gold</option>
          <option value="SILVER">Silver</option>
          <option value="PLATINUM">Platinum</option>
        </select>
        <div className="spacer" />
        
        <button className="ghost" onClick={() => setShowAuditHistory(true)}>Audit History</button>
        <button className="ghost" onClick={() => setShowAuditModal(true)}>New Stock Audit</button>
        <button className="ghost" onClick={openValuation}>Stock Valuation</button>
        <button className="primary" onClick={openAdd}>+ Add Item</button>
      </div>
      <div className="card" style={{ padding: 0 }}>
        <table>
          <thead>
            <tr>
              <th>Item Code</th><th>Name</th><th>Category</th><th>Metal / Purity</th>
              <th>Gross Wt</th><th>Net Wt</th><th>HUID</th><th>Status</th><th></th>
            </tr>
          </thead>
          <tbody>
            {items.map((it) => (
              <tr key={it.id}>
                <td className="mono">{it.item_code}</td>
                <td>{it.name}</td>
                <td>{it.category_name || '-'}</td>
                <td>{it.metal_type} / {it.purity_name}</td>
                <td className="mono">{it.gross_weight.toFixed(3)} g</td>
                <td className="mono">{it.net_weight.toFixed(3)} g</td>
                <td className="muted">{it.huid_number || '-'}</td>
                <td>
                  <span className={`badge ${it.status === 'IN_STOCK' ? 'green' : it.status === 'SOLD' ? 'gray' : 'gold'}`}>
                    {it.status.replace('_', ' ')}
                  </span>
                </td>
                <td style={{ display: 'flex', gap: 6 }}>
                  <button className="ghost" onClick={() => openDetails(it)}>View</button>
                  <button className="ghost" onClick={() => openEdit(it)}>Edit</button>
                  {it.status === 'IN_STOCK' && <button className="ghost" onClick={() => handleDelete(it)}>Delete</button>}
                </td>
              </tr>
            ))}
            {items.length === 0 && <tr><td colSpan={9} className="muted center">No items found</td></tr>}
          </tbody>
        </table>
      </div>

      {showForm && <ItemFormModal item={editingItem} onClose={() => setShowForm(false)} onSaved={handleSaved} />}
      {showAuditModal && <StockAuditModal onClose={() => setShowAuditModal(false)} onSaved={() => { setShowAuditModal(false); load(); }} />}
      
      {/* NEW MODAL RENDERED HERE */}
      {showAuditHistory && <AuditHistoryModal onClose={() => setShowAuditHistory(false)} />}

      {showValuation && (
        <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) setShowValuation(false); }}>
          <div className="modal" style={{ width: 620 }}>
            <div className="modal-header">
              <h3>Current Stock Valuation</h3>
              <button className="ghost" onClick={() => setShowValuation(false)}>✕</button>
            </div>
            <table>
              <thead><tr><th>Metal</th><th>Purity</th><th>Items</th><th>Net Wt (g)</th><th>Rate/g</th><th>Est. Value</th></tr></thead>
              <tbody>
                {valuation.map((v, idx) => (
                  <tr key={idx}>
                    <td>{v.metal_type}</td><td>{v.purity_name}</td><td>{v.item_count}</td>
                    <td className="mono">{v.total_net_weight.toFixed(3)}</td>
                    <td className="mono">₹{v.current_rate_per_gram.toFixed(2)}</td>
                    <td className="mono">₹{v.estimated_value.toLocaleString('en-IN')}</td>
                  </tr>
                ))}
                {valuation.length === 0 && <tr><td colSpan={6} className="muted center">No stock in hand</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {selectedItem && (
        <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) { setSelectedItem(null); setSelectedLedger([]); } }}>
          <div className="modal" style={{ width: 760 }}>
            <div className="modal-header">
              <h3>Item Details</h3>
              <button className="ghost" onClick={() => { setSelectedItem(null); setSelectedLedger([]); }}>✕</button>
            </div>
            <div className="grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
              <div>
                <div><b>{selectedItem.name}</b></div>
                <div className="muted">{selectedItem.item_code}</div>
                <div className="muted">{selectedItem.category_name || '-'}</div>
                <div className="muted">{selectedItem.metal_type} / {selectedItem.purity_name}</div>
              </div>
              <div>
                <div className="muted">Gross: {Number(selectedItem.gross_weight || 0).toFixed(3)} g</div>
                <div className="muted">Net: {Number(selectedItem.net_weight || 0).toFixed(3)} g</div>
                <div className="muted">HUID: {selectedItem.huid_number || '-'}</div>
                <div className="muted">Status: {selectedItem.status}</div>
              </div>
            </div>

            <div className="grid" style={{ gridTemplateColumns: '1fr 1fr', marginTop: 14 }}>
              <div className="card" style={{ margin: 0 }}>
                <div className="card-title">Photo</div>
                {selectedItem.image_path ? (
                  <img
                    src={toFileUrl(selectedItem.image_path)}
                    alt={selectedItem.name}
                    style={{ width: '100%', maxHeight: 220, objectFit: 'cover', borderRadius: 8, border: '1px solid var(--border)' }}
                  />
                ) : (
                  <div className="muted">No photo uploaded</div>
                )}
              </div>
              <div className="card" style={{ margin: 0 }}>
                <div className="card-title">Certificate</div>
                {selectedItem.certificate_path ? (
                  <iframe
                    title="Certificate viewer"
                    src={toFileUrl(selectedItem.certificate_path)}
                    style={{ width: '100%', height: 220, border: '1px solid var(--border)', borderRadius: 8, background: '#fff' }}
                  />
                ) : (
                  <div className="muted">No certificate uploaded</div>
                )}
              </div>
            </div>

            <div className="card-title" style={{ marginTop: 16 }}>Stock Ledger</div>
            <table>
              <thead><tr><th>Date</th><th>Type</th><th>Reference</th><th>Qty</th><th>Notes</th></tr></thead>
              <tbody>
                {selectedLedger.map((row, idx) => (
                  <tr key={idx}>
                    <td>{row.created_at || row.entry_date || '-'}</td>
                    <td>{row.transaction_type || row.entry_type || '-'}</td>
                    <td>{row.reference_number || row.reference_table || '-'}</td>
                    <td className="mono">
                      {Number(row.quantity_change || 0) > 0 ? '+' : ''}{Number(row.quantity_change || 0)}
                    </td>
                    <td>{row.notes || '-'}</td>
                  </tr>
                ))}
                {selectedLedger.length === 0 && <tr><td colSpan={5} className="muted center">No ledger entries</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}