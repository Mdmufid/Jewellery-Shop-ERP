import React, { useEffect, useState } from 'react';
import Modal from '../../components/Modal.jsx';
import { useToast } from '../../context/ToastContext.jsx';

export default function ItemFormModal({ item, onClose, onSaved }) {
  const { showToast, showError } = useToast();
  const [categories, setCategories] = useState([]);
  const [purities, setPurities] = useState([]);
  const [form, setForm] = useState({
    name: item?.name || '',
    categoryId: item?.category_id || '',
    metalType: item?.metal_type || 'GOLD',
    purityId: item?.purity_id || '',
    grossWeight: item?.gross_weight ?? '',
    stoneWeight: item?.stone_weight ?? 0,
    stoneDetails: item?.stone_details || '',
    stoneCharge: item?.stone_charge ?? 0,
    huidNumber: item?.huid_number || '',
    hallmarkCertificateNo: item?.hallmark_certificate_no || '',
    quantity: item?.quantity ?? 1,
    location: item?.location || '',
    imagePath: item?.image_path || '',
    certificatePath: item?.certificate_path || '',
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    window.api.settings.listCategories().then(setCategories).catch(showError);
    window.api.rates.listPurities().then(setPurities).catch(showError);
  }, []);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const filteredPurities = purities.filter((p) => p.metal_type === form.metalType);

  const netWeight = (parseFloat(form.grossWeight) || 0) - (parseFloat(form.stoneWeight) || 0);

  const toFileUrl = (filePath) => {
    if (!filePath) return '';
    return `file:///${String(filePath).replace(/\\/g, '/')}`;
  };

  const pickPath = (key) => (e) => {
    const file = e.target.files && e.target.files[0];
    if (file?.path) {
      setForm((f) => ({ ...f, [key]: file.path }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.purityId || !form.grossWeight) {
      showError(new Error('Please fill in item name, purity and gross weight'));
      return;
    }
    setSaving(true);
    try {
      const payload = {
        name: form.name,
        categoryId: form.categoryId ? Number(form.categoryId) : null,
        metalType: form.metalType,
        purityId: Number(form.purityId),
        grossWeight: parseFloat(form.grossWeight),
        stoneWeight: parseFloat(form.stoneWeight) || 0,
        stoneDetails: form.stoneDetails,
        stoneCharge: parseFloat(form.stoneCharge) || 0,
        makingChargeType: 'PER_GRAM', // Hardcoded default
        makingChargeValue: 0,         // Hardcoded default
        wastagePercent: 0,            // Hardcoded default
        huidNumber: form.huidNumber || null,
        hallmarkCertificateNo: form.hallmarkCertificateNo || null,
        quantity: parseInt(form.quantity, 10) || 1,
        location: form.location,
        imagePath: form.imagePath || null,
        certificatePath: form.certificatePath || null,
        sourceType: item ? undefined : 'OPENING_STOCK',
      };
      if (item) {
        await window.api.inventory.update(item.id, payload);
        showToast('Item updated');
      } else {
        await window.api.inventory.create(payload);
        showToast('Item added to inventory');
      }
      onSaved();
    } catch (err) { showError(err); } finally { setSaving(false); }
  };

  return (
    <Modal title={item ? `Edit Item — ${item.item_code}` : 'Add New Inventory Item'} onClose={onClose} width={640}>
      <form onSubmit={handleSubmit}>
        <div className="field">
          <label>Item Name / Description *</label>
          <input value={form.name} onChange={set('name')} placeholder="e.g. Gold Ring - Floral Design" />
        </div>
        <div className="inline-fields">
          <div className="field">
            <label>Category</label>
            <select value={form.categoryId} onChange={set('categoryId')}>
              <option value="">Select category</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div className="field">
            <label>Metal Type *</label>
            <select value={form.metalType} onChange={(e) => setForm((f) => ({ ...f, metalType: e.target.value, purityId: '' }))}>
              <option value="GOLD">Gold</option>
              <option value="SILVER">Silver</option>
              <option value="PLATINUM">Platinum</option>
            </select>
          </div>
          <div className="field">
            <label>Purity *</label>
            <select value={form.purityId} onChange={set('purityId')}>
              <option value="">Select purity</option>
              {filteredPurities.map((p) => <option key={p.id} value={p.id}>{p.purity_name}</option>)}
            </select>
          </div>
        </div>
        <div className="inline-fields">
          <div className="field">
            <label>Gross Weight (g) *</label>
            <input type="number" step="0.001" value={form.grossWeight} onChange={set('grossWeight')} />
          </div>
          <div className="field">
            <label>Stone Weight (g)</label>
            <input type="number" step="0.001" value={form.stoneWeight} onChange={set('stoneWeight')} />
          </div>
          <div className="field">
            <label>Net (Metal) Weight</label>
            <input value={netWeight.toFixed(3)} disabled />
          </div>
        </div>
        <div className="inline-fields">
          <div className="field">
            <label>Stone Details</label>
            <input value={form.stoneDetails} onChange={set('stoneDetails')} placeholder="e.g. 4 diamonds, 0.2ct" />
          </div>
          <div className="field">
            <label>Stone Charge (₹)</label>
            <input type="number" step="0.01" value={form.stoneCharge} onChange={set('stoneCharge')} />
          </div>
        </div>
        <div className="inline-fields">
          <div className="field">
            <label>HUID Number (BIS Hallmark)</label>
            <input value={form.huidNumber} onChange={set('huidNumber')} maxLength={6} placeholder="6-char alphanumeric" />
          </div>
          <div className="field">
            <label>Hallmark Certificate No.</label>
            <input value={form.hallmarkCertificateNo} onChange={set('hallmarkCertificateNo')} />
          </div>
        </div>
        <div className="inline-fields">
          <div className="field">
            <label>Quantity</label>
            <input type="number" min="1" value={form.quantity} onChange={set('quantity')} disabled={!!item} />
          </div>
          <div className="field">
            <label>Showcase / Location</label>
            <input value={form.location} onChange={set('location')} placeholder="e.g. Counter 2, Box A" />
          </div>
        </div>
        <div className="inline-fields">
          <div className="field">
            <label>Item Photo</label>
            <input type="file" accept="image/*" onChange={pickPath('imagePath')} />
            {form.imagePath && (
              <div style={{ marginTop: 8 }}>
                <img
                  src={toFileUrl(form.imagePath)}
                  alt="Item preview"
                  style={{ width: '100%', maxHeight: 180, objectFit: 'cover', borderRadius: 8, border: '1px solid var(--border)' }}
                />
                <div className="muted" style={{ fontSize: 11, marginTop: 4 }}>{form.imagePath.split(/[\\/]/).pop()}</div>
              </div>
            )}
          </div>
          <div className="field">
            <label>Certificate File</label>
            <input type="file" accept=".pdf,image/*" onChange={pickPath('certificatePath')} />
            {form.certificatePath && <div className="muted" style={{ fontSize: 11, marginTop: 8 }}>{form.certificatePath.split(/[\\/]/).pop()}</div>}
          </div>
        </div>
        {form.certificatePath && (
          <div className="field">
            <label>Certificate Preview</label>
            <iframe
              title="Certificate preview"
              src={toFileUrl(form.certificatePath)}
              style={{ width: '100%', height: 220, border: '1px solid var(--border)', borderRadius: 8, background: '#fff' }}
            />
          </div>
        )}
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 10 }}>
          <button type="button" className="ghost" onClick={onClose}>Cancel</button>
          <button type="submit" className="primary" disabled={saving}>{saving ? 'Saving...' : 'Save Item'}</button>
        </div>
      </form>
    </Modal>
  );
}