import React, { useEffect, useState } from 'react';
import Modal from '../../components/Modal.jsx';
import { useToast } from '../../context/ToastContext.jsx';

function ExchangeForm({ onClose, onSaved }) {
  const { showToast, showError } = useToast();
  const [customers, setCustomers] = useState([]);
  const [customerSearch, setCustomerSearch] = useState('');
  const [customer, setCustomer] = useState(null);
  const [rates, setRates] = useState([]);
  
  // --- New states for handling new customers ---
  const [isNew, setIsNew] = useState(false);
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newCustomerPhone, setNewCustomerPhone] = useState('');

  const [form, setForm] = useState({
    exchangeDate: new Date().toISOString().slice(0, 10), metalType: 'GOLD', grossWeight: '', stoneWeight: 0,
    purityTestedPercent: '', deductionPercent: 2, ratePerGram: '', notes: '',
  });
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  useEffect(() => { window.api.rates.getCurrent().then(setRates).catch(showError); }, []);
  useEffect(() => {
    if (customerSearch.length < 1) { setCustomers([]); return; }
    const t = setTimeout(() => window.api.customers.list(customerSearch).then(setCustomers).catch(showError), 200);
    return () => clearTimeout(t);
  }, [customerSearch]);

  const netWeight = (parseFloat(form.grossWeight) || 0) - (parseFloat(form.stoneWeight) || 0);
  const effectiveFineWeight = netWeight * ((parseFloat(form.purityTestedPercent) || 0) / 100) * (1 - (parseFloat(form.deductionPercent) || 0) / 100);
  const totalValue = effectiveFineWeight * (parseFloat(form.ratePerGram) || 0);
  const fineRateSuggestion = rates.find((r) => r.metal_type === form.metalType && r.fineness_percent === 99.9);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.grossWeight || !form.purityTestedPercent || !form.ratePerGram) {
      showError(new Error('Fill in gross weight, tested purity and rate per gram')); return;
    }
    setSaving(true);
    try {
      let customerId = customer?.id || null;

      // --- Logic to create new customer if selected ---
      if (isNew && newCustomerName) {
        const created = await window.api.customers.create({ 
            name: newCustomerName, 
            phone: newCustomerPhone,
            address: 'Walk-in/New',
            state_code: '27'
        });
        customerId = created.id;
      }

      const ex = await window.api.oldGold.create({
        ...form, customerId: customerId,
        grossWeight: parseFloat(form.grossWeight), stoneWeight: parseFloat(form.stoneWeight) || 0,
        purityTestedPercent: parseFloat(form.purityTestedPercent), deductionPercent: parseFloat(form.deductionPercent) || 0,
        ratePerGram: parseFloat(form.ratePerGram),
      });
      showToast(`Exchange ${ex.exchange_number} recorded — value ₹${ex.total_value.toLocaleString('en-IN')}`);
      onSaved();
    } catch (err) { showError(err); } finally { setSaving(false); }
  };

  return (
    <Modal title="Record Old Gold Exchange" onClose={onClose} width={600}>
      <form onSubmit={handleSubmit}>
        <div className="field">
          <label>Customer</label>
          {customer ? (
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: 8, border: '1px solid var(--border)', borderRadius: 4 }}>
              <span>{customer.name} &middot; {customer.phone}</span>
              <button type="button" className="ghost" onClick={() => { setCustomer(null); setIsNew(false); }}>Change</button>
            </div>
          ) : isNew ? (
            <div style={{ display: 'flex', gap: 10 }}>
              <input placeholder="Customer Name" value={newCustomerName} onChange={(e) => setNewCustomerName(e.target.value)} />
              <input placeholder="Phone" value={newCustomerPhone} onChange={(e) => setNewCustomerPhone(e.target.value)} />
              <button type="button" className="ghost" onClick={() => setIsNew(false)}>Cancel</button>
            </div>
          ) : (
            <>
              <input value={customerSearch} onChange={(e) => setCustomerSearch(e.target.value)} placeholder="Search customer..." />
              {customers.length > 0 && (
                <div style={{ border: '1px solid var(--border)', borderRadius: 6, marginTop: 6 }}>
                  {customers.map((c) => (
                    <div key={c.id} style={{ padding: 8, cursor: 'pointer' }} onClick={() => { setCustomer(c); setCustomerSearch(''); setCustomers([]); }}>
                      {c.name} &middot; {c.phone}
                    </div>
                  ))}
                </div>
              )}
              <button type="button" className="ghost" style={{ marginTop: 8 }} onClick={() => setIsNew(true)}>+ Add New Customer</button>
            </>
          )}
        </div>
        <div className="inline-fields">
          <div className="field"><label>Date</label><input type="date" value={form.exchangeDate} onChange={set('exchangeDate')} /></div>
          <div className="field"><label>Metal *</label>
            <select value={form.metalType} onChange={set('metalType')}>
              <option value="GOLD">Gold</option><option value="SILVER">Silver</option><option value="PLATINUM">Platinum</option>
            </select>
          </div>
        </div>
        <div className="inline-fields">
          <div className="field"><label>Gross Weight (g) *</label><input type="number" step="0.001" value={form.grossWeight} onChange={set('grossWeight')} /></div>
          <div className="field"><label>Stone Weight (g)</label><input type="number" step="0.001" value={form.stoneWeight} onChange={set('stoneWeight')} /></div>
          <div className="field"><label>Net Weight</label><input value={netWeight.toFixed(3)} disabled /></div>
        </div>
        <div className="inline-fields">
          <div className="field"><label>Tested Purity % *</label><input type="number" step="0.1" value={form.purityTestedPercent} onChange={set('purityTestedPercent')} placeholder="e.g. 91.6" /></div>
          <div className="field"><label>Melting Deduction %</label><input type="number" step="0.1" value={form.deductionPercent} onChange={set('deductionPercent')} /></div>
          <div className="field">
            <label>Fine Rate ₹/g * {fineRateSuggestion ? `(999: ₹${fineRateSuggestion.rate_per_gram})` : ''}</label>
            <input type="number" step="0.01" value={form.ratePerGram} onChange={set('ratePerGram')} />
          </div>
        </div>
        <div className="card" style={{ background: 'var(--bg-elevated)' }}>
          <div>Effective Fine Weight: <b className="mono">{effectiveFineWeight.toFixed(3)} g</b></div>
          <div>Total Exchange Value: <b className="mono">₹{totalValue.toLocaleString('en-IN', { maximumFractionDigits: 2 })}</b></div>
        </div>
        <div className="field"><label>Notes</label><textarea rows={2} value={form.notes} onChange={set('notes')} /></div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <button type="button" className="ghost" onClick={onClose}>Cancel</button>
          <button type="submit" className="primary" disabled={saving}>{saving ? 'Saving...' : 'Record Exchange'}</button>
        </div>
      </form>
    </Modal>
  );
}

function SettleModal({ ex, onClose, onSaved }) {
  const [paymentMode, setPaymentMode] = useState('CASH');
  const [saving, setSaving] = useState(false);
  const { showError, showToast } = useToast();
  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await window.api.oldGold.settleCash(ex.id, { paymentMode });
      showToast('Exchange settled');
      onSaved();
    } catch (err) { showError(err); } finally { setSaving(false); }
  };
  return (
    <Modal title="Settle for Cash" onClose={onClose} width={400}>
      <form onSubmit={submit}>
        <div className="field"><label>Mode</label><select value={paymentMode} onChange={(e) => setPaymentMode(e.target.value)}><option value="CASH">CASH</option><option value="UPI">UPI</option><option value="BANK_TRANSFER">BANK_TRANSFER</option></select></div>
        <button type="submit" className="primary" style={{ width: '100%', marginTop: 20 }}>Settle Exchange</button>
      </form>
    </Modal>
  );
}

export default function OldGold() {
  const { showError } = useToast();
  const [exchanges, setExchanges] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [settleEx, setSettleEx] = useState(null);

  const load = () => window.api.oldGold.list({}).then(setExchanges).catch(showError);
  useEffect(() => { load(); }, []);

  return (
    <div>
      <h2 className="page-title">Old Gold Exchange</h2>
      <div className="toolbar">
        <div className="spacer" />
        <button className="primary" onClick={() => setShowForm(true)}>+ Record Exchange</button>
      </div>
      <div className="card" style={{ padding: 0 }}>
        <table>
          <thead><tr><th>Exchange No</th><th>Date</th><th>Customer</th><th>Metal</th><th>Net Wt</th><th>Fine Wt</th><th>Value</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {exchanges.map((ex) => (
              <tr key={ex.id}>
                <td className="mono">{ex.exchange_number}</td>
                <td>{ex.exchange_date}</td>
                <td>{ex.customer_name || 'Walk-in'}</td>
                <td>{ex.metal_type}</td>
                <td className="mono">{ex.net_weight.toFixed(3)}g</td>
                <td className="mono">{ex.effective_fine_weight.toFixed(3)}g</td>
                <td className="mono">₹{ex.total_value.toLocaleString('en-IN')}</td>
                <td><span className={`badge ${ex.status === 'PENDING' ? 'gold' : 'green'}`}>{ex.status.replace(/_/g, ' ')}</span></td>
                <td>{ex.status === 'PENDING' && <button className="ghost" onClick={() => setSettleEx(ex)}>Settle Cash</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showForm && <ExchangeForm onClose={() => setShowForm(false)} onSaved={() => { setShowForm(false); load(); }} />}
      {settleEx && <SettleModal ex={settleEx} onClose={() => setSettleEx(null)} onSaved={() => { setSettleEx(null); load(); }} />}
    </div>
  );
}