import React, { useEffect, useState } from 'react';
import Modal from '../../components/Modal.jsx';
import { useToast } from '../../context/ToastContext.jsx';

// --- 1. REPAIR INTAKE FORM ---
function RepairForm({ onClose, onSaved }) {
  const { showToast, showError } = useToast();
  
  // Customer State
  const [customers, setCustomers] = useState([]);
  const [customerSearch, setCustomerSearch] = useState('');
  const [customer, setCustomer] = useState(null);
  const [isNew, setIsNew] = useState(false);
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newCustomerPhone, setNewCustomerPhone] = useState('');

  // Form State
  const [form, setForm] = useState({
    receivedDate: new Date().toISOString().slice(0, 10),
    itemDescription: '',
    issueDetails: '',
    photoPath: '',
    advancePaid: 0,
    expectedReadyDate: '',
    totalCharge: 0,
    notes: '',
  });
  const [saving, setSaving] = useState(false);
  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  useEffect(() => {
    if (customerSearch.length < 1) {
      setCustomers([]);
      return;
    }
    const timer = setTimeout(() => {
      window.api.customers.list(customerSearch).then(setCustomers).catch(showError);
    }, 200);
    return () => clearTimeout(timer);
  }, [customerSearch]);

  const balanceDue = Math.max((parseFloat(form.totalCharge) || 0) - (parseFloat(form.advancePaid) || 0), 0);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.itemDescription || !form.issueDetails) {
      showError(new Error('Item description and issue details are required'));
      return;
    }
    setSaving(true);
    try {
      let customerId = customer?.id || null;

      // Handle New Customer Creation
      if (isNew && newCustomerName) {
        const created = await window.api.customers.create({ 
            name: newCustomerName, 
            phone: newCustomerPhone,
            address: 'Walk-in/Repair',
            state_code: '27'
        });
        customerId = created.id;
      }

      const repair = await window.api.repairs.create({
        ...form,
        customerId: customerId,
        advancePaid: parseFloat(form.advancePaid) || 0,
        totalCharge: parseFloat(form.totalCharge) || 0,
      });
      showToast(`Repair ${repair.repair_number} recorded`);
      onSaved();
    } catch (err) {
      showError(err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal title="Record Repair Job" onClose={onClose} width={650}>
      <form onSubmit={handleSubmit}>
        <div className="field">
          <label>Customer (optional)</label>
          {customer ? (
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: 8, border: '1px solid var(--border)', borderRadius: 4 }}>
              <span>{customer.name} &middot; {customer.phone || '-'}</span>
              <button type="button" className="ghost" onClick={() => { setCustomer(null); setIsNew(false); }}>Change</button>
            </div>
          ) : isNew ? (
            <div style={{ display: 'flex', gap: 10 }}>
              <input placeholder="Customer Name" value={newCustomerName} onChange={(e) => setNewCustomerName(e.target.value)} required />
              <input placeholder="Phone" value={newCustomerPhone} onChange={(e) => setNewCustomerPhone(e.target.value)} />
              <button type="button" className="ghost" onClick={() => setIsNew(false)}>Cancel</button>
            </div>
          ) : (
            <>
              <input value={customerSearch} onChange={(e) => setCustomerSearch(e.target.value)} placeholder="Search customer..." />
              {customers.length > 0 && (
                <div style={{ border: '1px solid var(--border)', borderRadius: 6, marginTop: 6, maxHeight: 180, overflowY: 'auto' }}>
                  {customers.map((c) => (
                    <div key={c.id} style={{ padding: 8, cursor: 'pointer', borderBottom: '1px solid var(--border)' }} onClick={() => { setCustomer(c); setCustomerSearch(''); setCustomers([]); }}>
                      {c.name} &middot; {c.phone || '-'}
                    </div>
                  ))}
                </div>
              )}
              <button type="button" className="ghost" style={{ marginTop: 8 }} onClick={() => setIsNew(true)}>+ Add New Customer</button>
            </>
          )}
        </div>

        <div className="inline-fields">
          <div className="field"><label>Received Date</label><input type="date" value={form.receivedDate} onChange={set('receivedDate')} /></div>
          <div className="field"><label>Expected Ready Date</label><input type="date" value={form.expectedReadyDate} onChange={set('expectedReadyDate')} /></div>
        </div>

        <div className="field"><label>Item Description *</label><input value={form.itemDescription} onChange={set('itemDescription')} placeholder="e.g. 22K Gold Bangle" /></div>
        <div className="field"><label>Issue Details *</label><textarea rows={3} value={form.issueDetails} onChange={set('issueDetails')} placeholder="Loose stone, chain broken, resizing, polishing, etc." /></div>
        <div className="field"><label>Photo Path</label><input value={form.photoPath} onChange={set('photoPath')} placeholder="Optional image file path" /></div>

        <div className="inline-fields">
          <div className="field"><label>Advance Paid</label><input type="number" step="0.01" value={form.advancePaid} onChange={set('advancePaid')} /></div>
          <div className="field"><label>Total Charge</label><input type="number" step="0.01" value={form.totalCharge} onChange={set('totalCharge')} /></div>
        </div>

        <div className="card" style={{ background: 'var(--bg-elevated)' }}>
          <div>Balance Due: <b className="mono">₹{balanceDue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</b></div>
        </div>

        <div className="field"><label>Notes</label><textarea rows={2} value={form.notes} onChange={set('notes')} /></div>

        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <button type="button" className="ghost" onClick={onClose}>Cancel</button>
          <button type="submit" className="primary" disabled={saving}>{saving ? 'Saving...' : 'Save Repair'}</button>
        </div>
      </form>
    </Modal>
  );
}

// --- 2. ADD NOTE MODAL (CRASH FIX) ---
function NoteModal({ onClose, onSave }) {
  const [note, setNote] = useState('');
  return (
    <Modal title="Add Timeline Note" onClose={onClose} width={400}>
      <form onSubmit={(e) => { e.preventDefault(); onSave(note); }}>
        <div className="field">
          <label>Note Details</label>
          <input type="text" value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. Karigar called, waiting for stones" autoFocus required />
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 15 }}>
          <button type="button" className="ghost" onClick={onClose}>Cancel</button>
          <button type="submit" className="primary">Save Note</button>
        </div>
      </form>
    </Modal>
  );
}

// --- 3. MAIN PAGE ---
export default function Repairs() {
  const { showError, showToast } = useToast();
  const [repairs, setRepairs] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [showNoteModal, setShowNoteModal] = useState(false);

  const load = () => window.api.repairs.list().then(setRepairs).catch(showError);

  useEffect(() => { load(); }, []);

  const updateStatus = async (repair, status) => {
    try {
      await window.api.repairs.update(repair.id, { status, statusNote: `${status} via UI`, changedBy: null });
      showToast(`Repair marked ${status.toLowerCase()}`);
      load();
    } catch (err) {
      showError(err);
    }
  };

  const [activeRepair, setActiveRepair] = useState(null);
  const [photos, setPhotos] = useState([]);
  const [history, setHistory] = useState([]);

  const openDetail = async (repair) => {
    setActiveRepair(repair);
    try {
      const p = await window.api.repairs.listPhotos(repair.id);
      const h = await window.api.repairs.statusHistory(repair.id);
      setPhotos(p || []);
      setHistory(h || []);
    } catch (e) { showError(e); }
  };

  const closeDetail = () => { setActiveRepair(null); setPhotos([]); setHistory([]); };

  const uploadPhoto = async (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file || !activeRepair) return;
    try {
      const res = await window.api.repairs.addPhoto(activeRepair.id, file.path, file.name);
      setPhotos(res || []);
      showToast('Photo added');
    } catch (err) { showError(err); }
  };

  const handleSaveNote = async (note) => {
    if (!activeRepair) return;
    try {
      const res = await window.api.repairs.addStatus(activeRepair.id, activeRepair.status, note, null);
      setHistory(res || []);
      showToast('Status note added');
      setShowNoteModal(false);
    } catch (err) { 
      showError(err); 
    }
  };

  return (
    <div>
      <h2 className="page-title">Repairs</h2>
      <p className="page-subtitle">Track customer repair jobs, token numbers, expected dates, and balance due.</p>

      <div className="toolbar">
        <div className="spacer" />
        <button className="primary" onClick={() => setShowForm(true)}>+ New Repair</button>
      </div>

      <div className="card" style={{ padding: 0 }}>
        <table>
          <thead>
            <tr>
              <th>Token</th><th>Date</th><th>Customer</th><th>Item</th><th>Issue</th><th>Advance</th><th>Due</th><th>Status</th><th></th>
            </tr>
          </thead>
          <tbody>
            {repairs.map((repair) => (
              <tr key={repair.id}>
                <td className="mono">{repair.repair_number}</td>
                <td>{repair.received_date}</td>
                <td>{repair.customer_name || 'Walk-in'}</td>
                <td>{repair.item_description}</td>
                <td>{repair.issue_details}</td>
                <td className="mono">₹{Number(repair.advance_paid || 0).toLocaleString('en-IN')}</td>
                <td className="mono">₹{Number(repair.balance_due || 0).toLocaleString('en-IN')}</td>
                <td><span className={`badge ${repair.status === 'READY' ? 'green' : repair.status === 'DELIVERED' ? 'gray' : 'gold'}`}>{repair.status}</span></td>
                <td style={{ whiteSpace: 'nowrap' }}>
                  {repair.status === 'PENDING' && <button className="ghost" onClick={() => updateStatus(repair, 'READY')}>Mark Ready</button>}
                  {repair.status === 'READY' && <button className="ghost" onClick={() => updateStatus(repair, 'DELIVERED')}>Deliver</button>}
                  <button className="ghost" onClick={() => openDetail(repair)} style={{ marginLeft: 8 }}>View</button>
                </td>
              </tr>
            ))}
            {repairs.length === 0 && <tr><td colSpan={9} className="muted center">No repairs recorded yet</td></tr>}
          </tbody>
        </table>
      </div>

      {showForm && <RepairForm onClose={() => setShowForm(false)} onSaved={() => { setShowForm(false); load(); }} />}
      {showNoteModal && <NoteModal onClose={() => setShowNoteModal(false)} onSave={handleSaveNote} />}

      {activeRepair && (
        <Modal title={`Repair ${activeRepair.repair_number}`} onClose={closeDetail} width={700}>
          <div style={{ display: 'flex', gap: 12 }}>
            <div style={{ flex: 1 }}>
              <div className="card-title">Photos</div>
              <input type="file" accept="image/*" onChange={uploadPhoto} />
              <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
                {photos.map((p) => (
                  <div key={p.id} style={{ width: 120 }}>
                    <img src={`file:///${String(p.file_path).replace(/\\/g, '/')}`} alt={p.caption || ''} style={{ width: 120, height: 90, objectFit: 'cover', borderRadius: 6 }} />
                    <div className="muted" style={{ fontSize: 11 }}>{p.caption || ''}</div>
                  </div>
                ))}
                {photos.length === 0 && <div className="muted">No photos</div>}
              </div>
            </div>
            <div style={{ width: 320 }}>
              <div className="card-title">Timeline</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {history.map((h) => (
                  <div key={h.id} style={{ borderLeft: '2px solid var(--border)', paddingLeft: 8 }}>
                    <div style={{ fontWeight: 600 }}>{h.status} <span className="muted">{h.changed_at}</span></div>
                    {h.note && <div className="muted" style={{ fontSize: 13 }}>{h.note}</div>}
                  </div>
                ))}
                {history.length === 0 && <div className="muted">No history</div>}
              </div>
              <div style={{ marginTop: 12, display: 'flex', gap: 8 }}>
                <button className="ghost" onClick={() => setShowNoteModal(true)}>Add Note</button>
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}