import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../../context/ToastContext.jsx';

export default function NewSupplier() {
  const navigate = useNavigate();
  const { showError, showToast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initial state for our form
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    gstin: '',
    address: '',
    stateCode: '27', // Defaulting to 27 for Maharashtra
    openingBalance: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent page refresh
    
    if (!formData.name) {
      showError(new Error('Supplier Name is required.'));
      return;
    }

    setIsSubmitting(true);
    try {
      // Format the payload for the backend
      const payload = {
        ...formData,
        openingBalance: formData.openingBalance ? parseFloat(formData.openingBalance) : 0
      };
      
      const response = await window.api.suppliers.create(payload);
      
      // Look for the supplier's ID instead of a success message
      if (response && response.id) { 
        showToast('Supplier added successfully!');
        navigate('/suppliers');
      }
    } catch (error) {
      // Electron adds system text to backend errors. This cleans it up for the UI toast.
      const cleanMessage = error.message.replace(/^Error invoking remote method '.*?': Error: /, '');
      showError(new Error(cleanMessage));
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      <button className="ghost" onClick={() => navigate('/suppliers')}>← Back to Suppliers</button>
      
      <div className="card" style={{ marginTop: 14 }}>
        <h2 style={{ marginTop: 0 }}>Add New Supplier</h2>
        <hr className="section-divider" />
        
        <form onSubmit={handleSubmit} style={{ marginTop: '20px' }}>
          <div className="grid grid-2" style={{ gap: '16px' }}>
            <div>
              <label>Company / Supplier Name *</label>
              <input type="text" name="name" value={formData.name} onChange={handleChange} required placeholder="E.g. RK Bullion" />
            </div>
            
            <div>
              <label>GSTIN (Mandatory for ITC)</label>
              <input type="text" name="gstin" value={formData.gstin} onChange={handleChange} placeholder="27XXXXX1234X1ZX" />
            </div>

            <div>
              <label>Phone Number</label>
              <input type="text" name="phone" value={formData.phone} onChange={handleChange} placeholder="Supplier contact number" />
            </div>
            
            <div>
              <label>Email</label>
              <input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="supplier@example.com" />
            </div>

            <div>
              <label>State Code</label>
              <input type="text" name="stateCode" value={formData.stateCode} onChange={handleChange} />
            </div>
            
            <div>
              <label>Opening Balance (₹)</label>
              <input 
                type="number" 
                name="openingBalance" 
                value={formData.openingBalance} 
                onChange={handleChange} 
                placeholder="Amount you currently owe them" 
              />
            </div>
          </div>

          <div style={{ marginTop: '16px' }}>
            <label>Full Address</label>
            <textarea 
              name="address" 
              value={formData.address} 
              onChange={handleChange} 
              rows="3" 
              style={{ width: '100%', resize: 'vertical' }}
              placeholder="Supplier's billing address"
            ></textarea>
          </div>
          
          <div style={{ marginTop: 24, display: 'flex', gap: 12 }}>
            <button type="submit" className="primary" disabled={isSubmitting}>
              {isSubmitting ? 'Saving...' : 'Save Supplier'}
            </button>
            <button type="button" className="ghost" onClick={() => navigate('/suppliers')}>
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}