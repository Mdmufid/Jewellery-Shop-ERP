import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../../context/ToastContext.jsx';

export default function Suppliers() {
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  const navigate = useNavigate();
  const { showError } = useToast();

  const fetchSuppliers = async () => {
    setLoading(true);
    try {
      // Fetch the list of suppliers from the backend
      const data = await window.api.suppliers.list();
      setSuppliers(data || []);
    } catch (error) {
      showError(new Error('Failed to load suppliers.'));
      console.error(error);
    } finally {
      // This is the crucial line that removes the "Loading..." text!
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSuppliers();
  }, []);

  // Filter the table based on the search bar
  const filteredSuppliers = suppliers.filter(s =>
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (s.phone && s.phone.includes(searchTerm)) ||
    (s.gstin && s.gstin.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (loading) {
    return <div className="muted" style={{ padding: 20 }}>Loading Suppliers...</div>;
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <h2>Suppliers</h2>
        <button className="primary" onClick={() => navigate('/suppliers/new')}>
          + Add Supplier
        </button>
      </div>

      <div className="card">
        <input
          type="text"
          placeholder="Search by name, phone, or GSTIN..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{ marginBottom: 16, width: '100%', maxWidth: '400px' }}
        />
        
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Phone</th>
              <th>GSTIN</th>
              <th>Balance Payable</th>
              <th style={{ textAlign: 'center' }}>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredSuppliers.map(s => (
              <tr key={s.id}>
                <td style={{ fontWeight: '500' }}>{s.name}</td>
                <td>{s.phone || '-'}</td>
                <td className="mono">{s.gstin || '-'}</td>
                <td className="mono" style={{ color: s.current_balance > 0 ? '#d9534f' : 'inherit', fontWeight: 'bold' }}>
                  ₹{Number(s.current_balance).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </td>
                <td style={{ textAlign: 'center' }}>
                  <button className="ghost small" onClick={() => navigate(`/suppliers/${s.id}`)}>
                    View Ledger
                  </button>
                </td>
              </tr>
            ))}
            {filteredSuppliers.length === 0 && (
              <tr>
                <td colSpan="5" className="center muted" style={{ padding: '30px 0' }}>
                  No suppliers found. Click "+ Add Supplier" to create one.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}