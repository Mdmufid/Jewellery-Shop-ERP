import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useToast } from '../../context/ToastContext.jsx';

export default function SupplierDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { showToast, showError } = useToast();
  const [supplier, setSupplier] = useState(null);
  const [ledger, setLedger] = useState([]);
  const [payAmount, setPayAmount] = useState('');
  const [payMode, setPayMode] = useState('CASH');
  const [payRef, setPayRef] = useState('');

  const load = () => {
    window.api.suppliers.getById(Number(id)).then(setSupplier).catch(showError);
    window.api.suppliers.ledger(Number(id)).then(setLedger).catch(showError);
  };
  useEffect(() => { load(); }, [id]);

  const handlePayment = async (e) => {
    e.preventDefault();
    if (!parseFloat(payAmount) || parseFloat(payAmount) <= 0) { showError(new Error('Enter a valid payment amount')); return; }
    try {
      await window.api.suppliers.recordPayment({
        supplierId: Number(id), amount: parseFloat(payAmount), paymentMode: payMode, referenceNumber: payRef,
      });
      showToast('Payment recorded');
      setPayAmount(''); setPayRef('');
      load();
    } catch (err) { showError(err); }
  };
  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to remove this supplier?')) {
      try {
        await window.api.suppliers.delete(Number(id));
        showToast('Supplier deleted successfully!');
        navigate('/suppliers');
      } catch (error) {
        showError(new Error('Failed to delete supplier.'));
        console.error(error);
      }
    }
  };

  if (!supplier) return <div className="muted">Loading...</div>;

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <button className="ghost" onClick={() => navigate('/suppliers')}>← Back to Suppliers</button>
        <button className="ghost" style={{ color: '#d9534f' }} onClick={handleDelete}>
          🗑️ Delete Supplier
        </button>
      </div>

      <div className="card" style={{ marginTop: 14 }}>
        <div className="grid grid-3">
          <div><label>Name</label><div>{supplier.name}</div></div>
          <div><label>GSTIN</label><div>{supplier.gstin || '-'}</div></div>
          <div><label>Phone</label><div>{supplier.phone || '-'}</div></div>
        </div>
        <hr className="section-divider" />
        <div className="stat-card" style={{ padding: 0 }}>
          <div className="label">Balance Payable</div>
          <div className="value">₹{supplier.current_balance.toLocaleString('en-IN')}</div>
        </div>
      </div>

      <div className="card">
        <div className="card-title">Record Payment</div>
        <form onSubmit={handlePayment} className="inline-fields">
          <div className="field"><label>Amount (₹)</label><input type="number" value={payAmount} onChange={(e) => setPayAmount(e.target.value)} /></div>
          <div className="field"><label>Mode</label>
            <select value={payMode} onChange={(e) => setPayMode(e.target.value)}>
              <option>CASH</option><option>BANK_TRANSFER</option><option>CHEQUE</option><option>UPI</option>
            </select>
          </div>
          <div className="field"><label>Reference No.</label><input value={payRef} onChange={(e) => setPayRef(e.target.value)} /></div>
          <div className="field" style={{ display: 'flex', alignItems: 'flex-end' }}>
            <button className="primary" type="submit">Record</button>
          </div>
        </form>
      </div>

      <div className="card">
        <div className="card-title">Ledger</div>
        <table>
          <thead><tr><th>Date</th><th>Type</th><th>Debit (Paid)</th><th>Credit (Owed)</th><th>Balance</th><th>Notes</th></tr></thead>
          <tbody>
            {ledger.map((l) => (
              <tr key={l.id}>
                <td className="muted">{l.created_at}</td>
                <td>{l.transaction_type}</td>
                <td className="mono">{l.debit ? `₹${l.debit.toFixed(2)}` : '-'}</td>
                <td className="mono">{l.credit ? `₹${l.credit.toFixed(2)}` : '-'}</td>
                <td className="mono">₹{l.balance.toFixed(2)}</td>
                <td className="muted">{l.notes}</td>
              </tr>
            ))}
            {ledger.length === 0 && <tr><td colSpan={6} className="muted center">No transactions yet</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
