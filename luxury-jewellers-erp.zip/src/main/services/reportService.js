const { getDb } = require('../database/db');
const { round2 } = require('../utils/gst');
const rateService = require('./rateService');

function salesRegister(fromDate, toDate) {
  const db = getDb();
  return db.prepare(
    `SELECT i.invoice_number, i.invoice_date, c.name AS customer_name, c.gstin AS customer_gstin,
            i.taxable_amount, i.cgst_amount, i.sgst_amount, i.igst_amount, i.grand_total, i.status
     FROM invoices i LEFT JOIN customers c ON c.id = i.customer_id
     WHERE i.invoice_date BETWEEN ? AND ? ORDER BY i.invoice_date, i.id`
  ).all(fromDate, toDate);
}

function salesSummary(fromDate, toDate) {
  const db = getDb();
  const row = db.prepare(
    `SELECT COUNT(*) AS invoice_count, COALESCE(SUM(taxable_amount),0) AS taxable_amount,
            COALESCE(SUM(cgst_amount),0) AS cgst_amount, COALESCE(SUM(sgst_amount),0) AS sgst_amount,
            COALESCE(SUM(igst_amount),0) AS igst_amount, COALESCE(SUM(grand_total),0) AS grand_total,
            COALESCE(SUM(old_gold_exchange_value),0) AS old_gold_value,
            COALESCE(SUM(discount_amount),0) AS discount_value
     FROM invoices WHERE invoice_date BETWEEN ? AND ? AND status = 'COMPLETED'`
  ).get(fromDate, toDate);
  return row;
}

/** GST rate-wise summary, useful for filing GSTR-1 HSN summary / B2C-B2B split. */
function gstSummary(fromDate, toDate) {
  const db = getDb();
  return db.prepare(
    `SELECT ii.hsn_code, ii.cgst_rate, ii.sgst_rate, ii.igst_rate,
            COUNT(*) AS line_count, SUM(ii.taxable_value) AS taxable_value,
            SUM(ii.cgst_amount) AS cgst_amount, SUM(ii.sgst_amount) AS sgst_amount, SUM(ii.igst_amount) AS igst_amount
     FROM invoice_items ii
     JOIN invoices i ON i.id = ii.invoice_id
     WHERE i.invoice_date BETWEEN ? AND ? AND i.status = 'COMPLETED'
     GROUP BY ii.hsn_code, ii.cgst_rate, ii.sgst_rate, ii.igst_rate
     ORDER BY ii.hsn_code`
  ).all(fromDate, toDate);
}

function stockSummary() {
  const { getStockValuation } = require('./inventoryService');
  return getStockValuation();
}

function outstandingCustomerDues() {
  const db = getDb();
  return db.prepare(
    `SELECT id, name, phone, current_balance FROM customers WHERE current_balance > 0 ORDER BY current_balance DESC`
  ).all();
}

function outstandingSupplierDues() {
  const db = getDb();
  return db.prepare(
    `SELECT id, name, phone, current_balance FROM suppliers WHERE current_balance > 0 ORDER BY current_balance DESC`
  ).all();
}

function outstandingKarigarDues() {
  const db = getDb();
  // FIXED: Query the 'artisans' table and alias 'cash_balance' as 'current_balance'
  return db.prepare(
    `SELECT id, name, phone, cash_balance AS current_balance 
     FROM artisans 
     WHERE cash_balance > 0 
     ORDER BY cash_balance DESC`
  ).all();
}

function dailySalesTrend(fromDate, toDate) {
  const db = getDb();
  return db.prepare(
    `SELECT invoice_date, COUNT(*) AS invoice_count, SUM(grand_total) AS total_sales
     FROM invoices WHERE invoice_date BETWEEN ? AND ? AND status = 'COMPLETED'
     GROUP BY invoice_date ORDER BY invoice_date`
  ).all(fromDate, toDate);
}

function topSellingCategories(fromDate, toDate) {
  const db = getDb();
  return db.prepare(
    `SELECT c.name AS category_name, COUNT(*) AS pieces_sold, SUM(ii.line_total) AS total_value
     FROM invoice_items ii
     JOIN invoices i ON i.id = ii.invoice_id
     LEFT JOIN items it ON it.id = ii.item_id
     LEFT JOIN categories c ON c.id = it.category_id
     WHERE i.invoice_date BETWEEN ? AND ? AND i.status = 'COMPLETED'
     GROUP BY c.name ORDER BY total_value DESC`
  ).all(fromDate, toDate);
}

function dashboardSnapshot() {
  const db = getDb();
  const today = new Date().toISOString().slice(0, 10);
  const monthStart = today.slice(0, 8) + '01';
  const todaySales = db.prepare(
    "SELECT COALESCE(SUM(grand_total),0) AS total, COUNT(*) AS cnt FROM invoices WHERE invoice_date = ? AND status='COMPLETED'"
  ).get(today);
  const monthSales = db.prepare(
    "SELECT COALESCE(SUM(grand_total),0) AS total, COUNT(*) AS cnt FROM invoices WHERE invoice_date >= ? AND status='COMPLETED'"
  ).get(monthStart);
  const stockCount = db.prepare("SELECT COUNT(*) AS cnt, COALESCE(SUM(net_weight),0) AS weight FROM items WHERE status='IN_STOCK'").get();
  const custDue = db.prepare("SELECT COALESCE(SUM(current_balance),0) AS total FROM customers WHERE current_balance > 0").get();
  const pendingOldGold = db.prepare("SELECT COUNT(*) AS cnt, COALESCE(SUM(total_value),0) AS total FROM old_gold_exchanges WHERE status='PENDING'").get();
  const pendingRepairs = db.prepare("SELECT COUNT(*) AS cnt, COALESCE(SUM(balance_due),0) AS total FROM repairs WHERE status IN ('PENDING','READY')").get();
  const currentRates = rateService.getCurrentRates(today);
  const stockByMetal = db.prepare(
    `SELECT metal_type, COUNT(*) AS item_count, COALESCE(SUM(net_weight),0) AS total_net_weight
     FROM items WHERE status='IN_STOCK' GROUP BY metal_type ORDER BY metal_type`
  ).all();
  const topCategories = topSellingCategories(monthStart, today).slice(0, 3);
  return { todaySales, monthSales, stockCount, custDue, pendingOldGold, pendingRepairs, currentRates, stockByMetal, topCategories };
}

module.exports = {
  salesRegister, salesSummary, gstSummary, stockSummary, outstandingCustomerDues,
  outstandingSupplierDues, outstandingKarigarDues, dailySalesTrend, topSellingCategories, dashboardSnapshot,
};
