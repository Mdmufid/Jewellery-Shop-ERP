const fs = require('fs');
const path = require('path');
const { dialog, app } = require('electron');
const { getDb, getDbPath } = require('../database/db');
const settingsService = require('./settingsService');

function defaultBackupDir() {
  const dir = path.join(app.getPath('documents'), 'Luxury Jewellers Backups');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

/** Performs a WAL checkpoint (flush pending writes) then copies the db file to the backup location. */
async function backupNow(customDestination) {
  const db = getDb();
  db.pragma('wal_checkpoint(TRUNCATE)');

  const dbPath = getDbPath();
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const fileName = `luxury_jewellers_backup_${timestamp}.db`;
  const destDir = customDestination || defaultBackupDir();
  if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });
  const destPath = path.join(destDir, fileName);

  fs.copyFileSync(dbPath, destPath);
  settingsService.updateSettings({ last_backup_at: new Date().toISOString() });
  return { path: destPath };
}

async function backupNowWithDialog(browserWindow) {
  const result = await dialog.showSaveDialog(browserWindow, {
    title: 'Save Backup As',
    defaultPath: path.join(defaultBackupDir(), `luxury_jewellers_backup_${Date.now()}.db`),
    filters: [{ name: 'Database Backup', extensions: ['db'] }],
  });
  if (result.canceled) return { canceled: true };
  const db = getDb();
  db.pragma('wal_checkpoint(TRUNCATE)');
  fs.copyFileSync(getDbPath(), result.filePath);
  settingsService.updateSettings({ last_backup_at: new Date().toISOString() });
  return { canceled: false, path: result.filePath };
}

/**
 * Restores from a backup file. Requires an app restart afterward since the
 * live database handle must be closed and reopened.
 */
async function restoreFromDialog(browserWindow) {
  const result = await dialog.showOpenDialog(browserWindow, {
    title: 'Select Backup File to Restore',
    properties: ['openFile'],
    filters: [{ name: 'Database Backup', extensions: ['db'] }],
  });
  if (result.canceled || result.filePaths.length === 0) return { canceled: true };

  const chosenPath = result.filePaths[0];
  const currentDbPath = getDbPath();

  // Safety copy of current DB before overwrite
  const safetyDir = defaultBackupDir();
  fs.copyFileSync(currentDbPath, path.join(safetyDir, `pre_restore_safety_${Date.now()}.db`));

  fs.copyFileSync(chosenPath, currentDbPath);
  // Remove stale WAL/SHM files so SQLite doesn't try to replay old WAL against restored file
  for (const ext of ['-wal', '-shm']) {
    const p = currentDbPath + ext;
    if (fs.existsSync(p)) fs.unlinkSync(p);
  }
  return { canceled: false, restoredFrom: chosenPath, requiresRestart: true };
}

module.exports = { backupNow, backupNowWithDialog, restoreFromDialog, defaultBackupDir };
