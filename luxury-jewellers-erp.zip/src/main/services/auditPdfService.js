const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');
const { app } = require('electron');
const inventoryService = require('./inventoryService');
const settingsService = require('./settingsService');

function generateAuditPdf(auditId, destinationPath) {
  // 1. Fetch Audit Data (assumes inventoryService.getStockAuditById attaches the items)
  const audit = inventoryService.getStockAuditById(auditId);
  if (!audit) throw new Error('Audit not found');
  const settings = settingsService.getAllSettings();

  // 2. Create the save destination
  const outDir = destinationPath ? path.dirname(destinationPath) : path.join(app.getPath('documents'), 'Luxury Jewellers Audits');
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  const outPath = destinationPath || path.join(outDir, `Audit-${auditId}-${audit.audit_date}.pdf`);

  const doc = new PDFDocument({ size: 'A4', margin: 30 });
  const stream = fs.createWriteStream(outPath);
  doc.pipe(stream);

  // ==========================================
  // HEADER
  // ==========================================
  doc.fontSize(18).font('Helvetica-Bold').text(settings.shop_name || 'LUXURY JEWELLERS', { align: 'center' });
  doc.fontSize(10).font('Helvetica').text(settings.shop_address || '', { align: 'center' });
  doc.moveDown(1);
  doc.fontSize(14).font('Helvetica-Bold').text('PHYSICAL STOCK AUDIT REPORT', { align: 'center', underline: true });
  doc.moveDown(1.5);

  // ==========================================
  // AUDIT DETAILS
  // ==========================================
  doc.fontSize(10).font('Helvetica-Bold');
  doc.text(`Audit Title : `, 30, doc.y, { continued: true }).font('Helvetica').text(audit.title);
  doc.font('Helvetica-Bold').text(`Audit Date : `, 30, doc.y + 5, { continued: true }).font('Helvetica').text(audit.audit_date);
  doc.font('Helvetica-Bold').text(`Status : `, 30, doc.y + 5, { continued: true }).font('Helvetica').text(audit.status);
  doc.moveDown(2);

  // ==========================================
  // ITEMS TABLE
  // ==========================================
  // ==========================================
  // ITEMS TABLE
  // ==========================================
  let tableY = doc.y;
  
  // Table Header Background
  doc.rect(30, tableY, 535, 20).fillAndStroke('#f0f0f0', '#000');
  doc.fillColor('#000').fontSize(9).font('Helvetica-Bold');

  // Column Headers (Renamed and widened for the description)
  doc.text('Item Description & Code', 35, tableY + 5, { width: 160 });
  doc.text('Expected Qty', 200, tableY + 5, { align: 'right', width: 70 });
  doc.text('Counted Qty', 280, tableY + 5, { align: 'right', width: 70 });
  doc.text('Expected Wt', 360, tableY + 5, { align: 'right', width: 80 });
  doc.text('Counted Wt', 450, tableY + 5, { align: 'right', width: 80 });

  tableY += 20;
  doc.font('Helvetica');

  // Draw Items
  if (audit.items && audit.items.length > 0) {
    audit.items.forEach(item => {
      // Draw Row Borders
      doc.rect(30, tableY, 535, 20).stroke();

      // Combine Name and Item Code neatly! 
      // Example: "Gold Chain (GITM004)"
      const description = `${item.name || 'Item'} (${item.item_code || '#' + item.item_id})`;
      doc.text(description, 35, tableY + 5, { width: 160, height: 15, ellipsis: true });
      
      doc.text(item.expected_quantity.toString(), 200, tableY + 5, { align: 'right', width: 70 });
      doc.text(item.counted_quantity.toString(), 280, tableY + 5, { align: 'right', width: 70 });
      
      doc.text(`${item.expected_weight.toFixed(3)} g`, 360, tableY + 5, { align: 'right', width: 80 });
      
      // Highlight weight variance in red if it doesn't match
      if (item.variance_weight !== 0) doc.fillColor('#d93025').font('Helvetica-Bold');
      doc.text(`${item.counted_weight.toFixed(3)} g`, 450, tableY + 5, { align: 'right', width: 80 });
      doc.fillColor('#000').font('Helvetica');

      tableY += 20;
    });
  } else {
    doc.rect(30, tableY, 535, 20).stroke();
    doc.text('No items recorded in this audit.', 35, tableY + 5);
    tableY += 20;
  }

  // ==========================================
  // SIGNATURES
  // ==========================================
  doc.moveDown(5);
  const sigY = doc.y;
  
  doc.font('Helvetica-Bold').text('Checked By (Auditor)', 50, sigY);
  doc.text('Approved By (Manager)', 400, sigY, { width: 150, align: 'right' });
  
  doc.moveTo(35, sigY - 5).lineTo(180, sigY - 5).stroke();
  doc.moveTo(385, sigY - 5).lineTo(565, sigY - 5).stroke();

  doc.end();

  return new Promise((resolve, reject) => {
    stream.on('finish', () => resolve({ path: outPath }));
    stream.on('error', reject);
  });
}

module.exports = { generateAuditPdf };