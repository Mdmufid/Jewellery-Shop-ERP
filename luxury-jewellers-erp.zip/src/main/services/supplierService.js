const { getDb } = require('../database/db');
const { round2 } = require('../utils/gst');

function createSupplier(payload) {
  const db = getDb();

  // 1. Validation Check: Prevent duplicate Phone Number
  if (payload.phone && payload.phone.trim() !== '') {
    const existingPhone = db.prepare('SELECT name FROM suppliers WHERE phone = ? AND is_active = 1').get(payload.phone.trim());
    if (existingPhone) {
      throw new Error(`This phone number is already registered to ${existingPhone.name}.`);
    }
  }

  // 2. Validation Check: Prevent duplicate GSTIN
  if (payload.gstin && payload.gstin.trim() !== '') {
    const existingGstin = db.prepare('SELECT name FROM suppliers WHERE gstin = ? AND is_active = 1').get(payload.gstin.trim());
    if (existingGstin) {
      throw new Error(`This GSTIN is already registered to ${existingGstin.name}.`);
    }
  }

  // 3. Proceed with Insertion if validation passes
  const info = db.prepare(
    `INSERT INTO suppliers (name, gstin, phone, email, address, state_code, opening_balance, current_balance)
     VALUES (?,?,?,?,?,?,?,?)`
  ).run(
    payload.name, 
    payload.gstin || null, 
    payload.phone || null, 
    payload.email || null,
    payload.address || null, 
    payload.stateCode || '27', 
    payload.openingBalance || 0, 
    payload.openingBalance || 0
  );
  
  const id = info.lastInsertRowid;
  
  if (payload.openingBalance) {
    db.prepare(
      `INSERT INTO supplier_ledger (supplier_id, transaction_type, debit, credit, balance, notes)
       VALUES (?, 'OPENING_BALANCE', 0, ?, ?, 'Opening balance (amount owed to supplier)')`
    ).run(id, payload.openingBalance, payload.openingBalance);
  }
  
  return getSupplierById(id);
}

function updateSupplier(id, payload) {
  const db = getDb();
  const existing = getSupplierById(id);
  if (!existing) throw new Error('Supplier not found');
  db.prepare(
    `UPDATE suppliers SET name=?, gstin=?, phone=?, email=?, address=?, state_code=? WHERE id=?`
  ).run(
    payload.name ?? existing.name, payload.gstin ?? existing.gstin, payload.phone ?? existing.phone,
    payload.email ?? existing.email, payload.address ?? existing.address, payload.stateCode ?? existing.state_code, id
  );
  return getSupplierById(id);
}

function getSupplierById(id) {
  return getDb().prepare('SELECT * FROM suppliers WHERE id = ?').get(id);
}

function listSuppliers(search) {
  const db = getDb();
  if (search) {
    const like = `%${search}%`;
    return db.prepare('SELECT * FROM suppliers WHERE is_active = 1 AND name LIKE ? ORDER BY name').all(like);
  }
  return db.prepare('SELECT * FROM suppliers WHERE is_active = 1 ORDER BY name').all();
}

function getSupplierLedger(supplierId) {
  return getDb().prepare(
    'SELECT * FROM supplier_ledger WHERE supplier_id = ? ORDER BY created_at DESC, id DESC'
  ).all(supplierId);
}

/** credit = amount we owe the supplier (increases balance payable); debit = payment made to supplier. */
function postLedgerEntry(db, { supplierId, transactionType, referenceTable, referenceId, debit, credit, notes }) {
  const supplier = db.prepare('SELECT current_balance FROM suppliers WHERE id = ?').get(supplierId);
  const newBalance = round2(supplier.current_balance - (debit || 0) + (credit || 0));
  db.prepare(
    `INSERT INTO supplier_ledger (supplier_id, transaction_type, reference_table, reference_id, debit, credit, balance, notes)
     VALUES (?,?,?,?,?,?,?,?)`
  ).run(supplierId, transactionType, referenceTable || null, referenceId || null, debit || 0, credit || 0, newBalance, notes || null);
  db.prepare('UPDATE suppliers SET current_balance = ? WHERE id = ?').run(newBalance, supplierId);
  return newBalance;
}

function recordSupplierPayment({ supplierId, amount, paymentMode, referenceNumber, notes }) {
  const db = getDb();
  const tx = db.transaction(() => {
    postLedgerEntry(db, {
      supplierId, transactionType: 'PAYMENT_MADE', debit: amount,
      notes: `Payment via ${paymentMode}${referenceNumber ? ' Ref#' + referenceNumber : ''}${notes ? ' - ' + notes : ''}`,
    });
    return getSupplierById(supplierId);
  });
  return tx();
}

function deleteSupplier(id) {
  // Soft delete: sets is_active to 0 so it hides from the UI but keeps accounting intact
  getDb().prepare('UPDATE suppliers SET is_active = 0 WHERE id = ?').run(id);
  return { success: true };
}

module.exports = {
  createSupplier, updateSupplier, getSupplierById, listSuppliers,
  getSupplierLedger, postLedgerEntry, recordSupplierPayment, deleteSupplier
};
