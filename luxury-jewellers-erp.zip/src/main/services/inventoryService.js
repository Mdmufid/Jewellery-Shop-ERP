const { getDb } = require('../database/db');
const { round2 } = require('../utils/gst');

function generateItemCode(db, categoryId, metalType) {
  const prefix = metalType === 'GOLD' ? 'G' : metalType === 'SILVER' ? 'S' : 'P';
  const catRow = categoryId ? db.prepare('SELECT name FROM categories WHERE id = ?').get(categoryId) : null;
  const catCode = catRow ? catRow.name.slice(0, 3).toUpperCase() : 'ITM';
  const row = db.prepare(
    "SELECT COUNT(*) AS c FROM items WHERE item_code LIKE ?"
  ).get(`${prefix}${catCode}%`);
  const seq = String(row.c + 1).padStart(4, '0');
  return `${prefix}${catCode}${seq}`;
}

function addStockLedgerEntry(db, { itemId, transactionType, referenceTable, referenceId, weightChange, quantityChange, notes }) {
  db.prepare(
    `INSERT INTO stock_ledger (item_id, transaction_type, reference_table, reference_id, weight_change, quantity_change, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(itemId, transactionType, referenceTable || null, referenceId || null, weightChange, quantityChange || 0, notes || null);
}

/**
 * Create a new inventory item. This is the entry point for stock coming from
 * a direct purchase, opening stock, karigar job-work receipt, or old-gold melt.
 */
function createItem(payload) {
  const db = getDb();
  const tx = db.transaction(() => {
    const netWeight = round2(payload.grossWeight - (payload.stoneWeight || 0));
    const itemCode = payload.itemCode || generateItemCode(db, payload.categoryId, payload.metalType);

    // FIXED: Removed karigar_job_id from the query to match your current database schema
    const info = db.prepare(
      `INSERT INTO items (
        item_code, name, category_id, metal_type, purity_id, gross_weight, stone_weight, net_weight,
        stone_details, stone_charge, making_charge_type, making_charge_value, wastage_percent,
        huid_number, hallmark_certificate_no, purchase_id, artisan_job_id, source_type,
        cost_rate_per_gram, quantity, location, image_path, certificate_path
      ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
    ).run(
      itemCode, payload.name, payload.categoryId || null, payload.metalType, payload.purityId,
      payload.grossWeight, payload.stoneWeight || 0, netWeight,
      payload.stoneDetails || null, payload.stoneCharge || 0,
      payload.makingChargeType || 'PER_GRAM', payload.makingChargeValue || 0, payload.wastagePercent || 0,
      payload.huidNumber || null, payload.hallmarkCertificateNo || null,
      payload.purchaseId || null, payload.karigarJobId || null, payload.sourceType || 'PURCHASE',
      payload.costRatePerGram || null, payload.quantity || 1, payload.location || null, payload.imagePath || null, payload.certificatePath || null
    );

    const itemId = info.lastInsertRowid;
    const ledgerType = payload.sourceType === 'KARIGAR' ? 'KARIGAR_IN'
      : payload.sourceType === 'OLD_GOLD_MELT' ? 'OLD_GOLD_MELT_IN'
      : payload.sourceType === 'OPENING_STOCK' ? 'OPENING_STOCK_IN'
      : 'PURCHASE_IN';

    addStockLedgerEntry(db, {
      itemId, transactionType: ledgerType, referenceTable: payload.referenceTable,
      referenceId: payload.referenceId, weightChange: netWeight, quantityChange: payload.quantity || 1,
      notes: 'Item added to stock',
    });

    return getItemById(itemId);
  });
  return tx();
}

function updateItem(id, payload) {
  const db = getDb();
  const existing = getItemById(id);
  if (!existing) throw new Error('Item not found');
  const netWeight = round2((payload.grossWeight ?? existing.gross_weight) - (payload.stoneWeight ?? existing.stone_weight));
  db.prepare(
    `UPDATE items SET
      name = ?, category_id = ?, metal_type = ?, purity_id = ?, gross_weight = ?, stone_weight = ?, net_weight = ?,
      stone_details = ?, stone_charge = ?, making_charge_type = ?, making_charge_value = ?, wastage_percent = ?,
      huid_number = ?, hallmark_certificate_no = ?, location = ?, image_path = ?, updated_at = datetime('now')
      , certificate_path = ?
     WHERE id = ?`
  ).run(
    payload.name ?? existing.name, payload.categoryId ?? existing.category_id,
    payload.metalType ?? existing.metal_type, payload.purityId ?? existing.purity_id,
    payload.grossWeight ?? existing.gross_weight, payload.stoneWeight ?? existing.stone_weight, netWeight,
    payload.stoneDetails ?? existing.stone_details, payload.stoneCharge ?? existing.stone_charge,
    payload.makingChargeType ?? existing.making_charge_type, payload.makingChargeValue ?? existing.making_charge_value,
    payload.wastagePercent ?? existing.wastage_percent, payload.huidNumber ?? existing.huid_number,
    payload.hallmarkCertificateNo ?? existing.hallmark_certificate_no,
    payload.location ?? existing.location, payload.imagePath ?? existing.image_path, payload.certificatePath ?? existing.certificate_path, id
  );
  return getItemById(id);
}

function getItemById(id) {
  return getDb().prepare(
    `SELECT i.*, c.name AS category_name, p.purity_name, p.metal_type AS purity_metal_type, p.fineness_percent
     FROM items i
     LEFT JOIN categories c ON c.id = i.category_id
     LEFT JOIN purity_master p ON p.id = i.purity_id
     WHERE i.id = ?`
  ).get(id);
}

function getItemByCode(itemCode) {
  return getDb().prepare(
    `SELECT i.*, c.name AS category_name, p.purity_name, p.fineness_percent
     FROM items i
     LEFT JOIN categories c ON c.id = i.category_id
     LEFT JOIN purity_master p ON p.id = i.purity_id
     WHERE i.item_code = ?`
  ).get(itemCode);
}

function listItems(filters = {}) {
  const db = getDb();
  let sql = `SELECT i.*, c.name AS category_name, p.purity_name
             FROM items i
             LEFT JOIN categories c ON c.id = i.category_id
             LEFT JOIN purity_master p ON p.id = i.purity_id
             WHERE 1=1`;
  const params = [];
  if (filters.status) { sql += ' AND i.status = ?'; params.push(filters.status); }
  else { sql += " AND i.status != 'SOLD'"; }
  if (filters.metalType) { sql += ' AND i.metal_type = ?'; params.push(filters.metalType); }
  if (filters.categoryId) { sql += ' AND i.category_id = ?'; params.push(filters.categoryId); }
  if (filters.search) {
    sql += ' AND (i.name LIKE ? OR i.item_code LIKE ? OR i.huid_number LIKE ?)';
    const like = `%${filters.search}%`;
    params.push(like, like, like);
  }
  sql += ' ORDER BY i.created_at DESC';
  return db.prepare(sql).all(...params);
}

/** Marks an item as sold (called by billingService when an invoice is finalized). */
function markItemSold(db, itemId, invoiceId) {
  // 1. Fetch the current item to check its quantity and weight
  const item = db.prepare('SELECT quantity, net_weight FROM items WHERE id = ?').get(itemId);
  if (!item) return;
  
  if (item.quantity > 1) {
    // If there are multiple pieces, just reduce the quantity by 1, keep it IN_STOCK
    db.prepare("UPDATE items SET quantity = quantity - 1, updated_at = datetime('now') WHERE id = ?").run(itemId);
  } else {
    // If it's the last piece, drop quantity to 0 and mark it completely SOLD
    db.prepare("UPDATE items SET quantity = 0, status = 'SOLD', updated_at = datetime('now') WHERE id = ?").run(itemId);
  }

  // Calculate the weight of a single piece (if they grouped them together)
  const unitWeight = item.quantity > 0 ? (item.net_weight / item.quantity) : item.net_weight;

  // Add the ledger entry for just the 1 piece sold
  addStockLedgerEntry(db, {
    itemId, transactionType: 'SALE_OUT', referenceTable: 'invoices', referenceId: invoiceId,
    weightChange: -unitWeight, 
    quantityChange: -1, 
    notes: 'Sold via invoice',
  });
}

/** Reverses a sale (invoice cancelled/returned) - restores item to stock. */
function markItemReturned(db, itemId, invoiceId) {
  const item = db.prepare('SELECT quantity, net_weight FROM items WHERE id = ?').get(itemId);
  if (!item) return;
  
  // Bring the quantity back up by 1 and ensure it is visible in stock
  db.prepare("UPDATE items SET quantity = quantity + 1, status = 'IN_STOCK', updated_at = datetime('now') WHERE id = ?").run(itemId);
  
  // Calculate weight for 1 piece to return to ledger
  const unitWeight = item.quantity > 0 ? (item.net_weight / item.quantity) : item.net_weight;

  addStockLedgerEntry(db, {
    itemId, transactionType: 'SALE_RETURN_IN', referenceTable: 'invoices', referenceId: invoiceId,
    weightChange: unitWeight, 
    quantityChange: 1, 
    notes: 'Returned to stock (invoice cancelled/returned)',
  });
}

function getStockLedgerForItem(itemId) {
  return getDb().prepare('SELECT * FROM stock_ledger WHERE item_id = ? ORDER BY created_at DESC, id DESC').all(itemId);
}

function createStockAudit(payload) {
  const db = getDb();
  const tx = db.transaction(() => {
    const info = db.prepare(
      `INSERT INTO stock_audits (audit_date, title, description, created_by, status) VALUES (?, ?, ?, ?, 'OPEN')`
    ).run(payload.auditDate || new Date().toISOString().slice(0, 10), payload.title || 'Stock Audit', payload.description || null, payload.createdBy || null);
    const auditId = info.lastInsertRowid;
    const insertItem = db.prepare(
      `INSERT INTO stock_audit_items (audit_id, item_id, expected_quantity, expected_weight, counted_quantity, counted_weight, variance_quantity, variance_weight)
       VALUES (?, ?, ?, ?, ?, ?, 0, 0)`
    );
    const items = listItems({ status: 'IN_STOCK' });
    for (const item of items) {
      insertItem.run(auditId, item.id, item.quantity || 1, item.net_weight || 0, item.quantity || 1, item.net_weight || 0);
    }
    return getStockAuditById(auditId);
  });
  return tx();
}

function getStockAuditById(id) {
  const db = getDb();
  const audit = db.prepare('SELECT * FROM stock_audits WHERE id = ?').get(id);
  if (!audit) return null;
  const items = db.prepare(`
    SELECT sai.*, i.item_code, i.name, i.metal_type, i.net_weight AS current_net_weight, i.quantity AS current_quantity
    FROM stock_audit_items sai
    LEFT JOIN items i ON i.id = sai.item_id
    WHERE sai.audit_id = ?
    ORDER BY i.name
  `).all(id);
  return { ...audit, items };
}

function listStockAudits() {
  return getDb().prepare(`
    SELECT sa.*, COUNT(sai.id) AS item_count, SUM(CASE WHEN sai.variance_quantity <> 0 OR sai.variance_weight <> 0 THEN 1 ELSE 0 END) AS variance_count
    FROM stock_audits sa
    LEFT JOIN stock_audit_items sai ON sai.audit_id = sa.id
    GROUP BY sa.id
    ORDER BY sa.created_at DESC
  `).all();
}

function saveStockAuditItems(auditId, rows) {
  const db = getDb();
  const updateItem = db.prepare(`
    UPDATE stock_audit_items
    SET counted_quantity = ?, counted_weight = ?, variance_quantity = ?, variance_weight = ?, notes = ?
    WHERE audit_id = ? AND item_id = ?
  `);
  for (const row of rows || []) {
    const expectedQty = Number(row.expected_quantity || 0);
    const expectedWeight = Number(row.expected_weight || 0);
    const countedQty = Number(row.counted_quantity ?? expectedQty);
    const countedWeight = Number(row.counted_weight ?? expectedWeight);
    updateItem.run(
      countedQty,
      countedWeight,
      Math.round(countedQty - expectedQty),
      round2(countedWeight - expectedWeight),
      row.notes || null,
      auditId,
      row.item_id
    );
  }
  return getStockAuditById(auditId);
}

function completeStockAudit(auditId) {
  const db = getDb();
  const tx = db.transaction(() => {
    const audit = db.prepare('SELECT * FROM stock_audits WHERE id = ?').get(auditId);
    if (!audit) throw new Error('Audit not found');
    if (audit.status === 'COMPLETED') return getStockAuditById(auditId);
    const rows = db.prepare(`
      SELECT sai.*, i.gross_weight AS current_gross_weight, i.net_weight AS current_net_weight, i.quantity AS current_quantity
      FROM stock_audit_items sai
      LEFT JOIN items i ON i.id = sai.item_id
      WHERE sai.audit_id = ?
    `).all(auditId);
    for (const row of rows) {
      const countedQuantity = Math.max(0, Number(row.counted_quantity || 0));
      const countedWeight = round2(Math.max(0, Number(row.counted_weight || 0)));
      const currentItem = getItemById(row.item_id);
      if (!currentItem) continue;
      const weightVariance = round2(countedWeight - (row.expected_weight || 0));
      const quantityVariance = Math.round(countedQuantity - (row.expected_quantity || 0));
      db.prepare(
        `UPDATE items SET gross_weight = ?, net_weight = ?, quantity = ?, updated_at = datetime('now') WHERE id = ?`
      ).run(countedWeight + (currentItem.stone_weight || 0), countedWeight, countedQuantity, row.item_id);
      if (quantityVariance !== 0 || weightVariance !== 0) {
        addStockLedgerEntry(db, {
          itemId: row.item_id,
          transactionType: weightVariance >= 0 || quantityVariance > 0 ? 'ADJUSTMENT_IN' : 'ADJUSTMENT_OUT',
          weightChange: weightVariance,
          quantityChange: quantityVariance,
          notes: `Stock audit ${audit.title}`,
        });
      }
    }
    db.prepare(`UPDATE stock_audits SET status='COMPLETED', completed_at=datetime('now') WHERE id=?`).run(auditId);
    return getStockAuditById(auditId);
  });
  return tx();
}

/** Aggregate stock valuation grouped by metal type and purity, at current rates. */
function getStockValuation() {
  const db = getDb();
  const rows = db.prepare(
    `SELECT i.metal_type, p.purity_name, p.id as purity_id, 
            SUM(i.quantity) as item_count,
            SUM(i.net_weight) as total_net_weight, 
            SUM(i.gross_weight) as total_gross_weight
     FROM items i JOIN purity_master p ON p.id = i.purity_id
     WHERE i.status = 'IN_STOCK'
     GROUP BY i.metal_type, p.id
     ORDER BY i.metal_type, p.fineness_percent DESC`
  ).all();
  const { getCurrentRateForPurity } = require('./rateService');
  return rows.map((r) => {
    let rate = 0;
    try { rate = getCurrentRateForPurity(r.purity_id); } catch (e) { rate = 0; }
    return { ...r, current_rate_per_gram: rate, estimated_value: round2(r.total_net_weight * rate) };
  });
}

function deleteItem(id) {
  const db = getDb();
  const item = getItemById(id);
  if (!item) throw new Error('Item not found');
  if (item.status === 'SOLD') throw new Error('Cannot delete a sold item. It is part of invoice history.');
  db.prepare('DELETE FROM stock_ledger WHERE item_id = ?').run(id);
  db.prepare('DELETE FROM items WHERE id = ?').run(id);
  return { success: true };
}

module.exports = {
  createItem, updateItem, getItemById, getItemByCode, listItems, deleteItem,
  markItemSold, markItemReturned, getStockLedgerForItem, getStockValuation, addStockLedgerEntry,
  createStockAudit, getStockAuditById, listStockAudits, saveStockAuditItems, completeStockAudit,
};