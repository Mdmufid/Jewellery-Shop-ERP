const { getDb } = require('../database/db');
const { nextNumber } = require('../utils/numberSequence');
const { round2 } = require('../utils/gst');
const inventoryService = require('./inventoryService');
const supplierService = require('./supplierService');

/**
 * Records a purchase bill from a supplier. Each line item becomes an
 * inventory item (status IN_STOCK) and the supplier's payable balance is
 * increased by the total bill amount, less any amount paid immediately.
 *
 * payload.items[]: { description, metalType, purityId, grossWeight, stoneWeight,
 *                     ratePerGram, makingCharge, hsnId, categoryId, wastagePercent,
 *                     makingChargeType, makingChargeValue, huidNumber }
 */
function createPurchase(payload) {
  const db = getDb();
  const tx = db.transaction(() => {
    const purchaseNumber = nextNumber('PURCHASE');
    let subtotal = 0, cgstTotal = 0, sgstTotal = 0, igstTotal = 0;

    const lineComputations = payload.items.map((line) => {
      const netWeight = round2(line.grossWeight - (line.stoneWeight || 0));
      const metalValue = round2(netWeight * line.ratePerGram);
      const amount = round2(metalValue + (line.makingCharge || 0));
      subtotal += amount;
      let cgst = 0, sgst = 0, igst = 0;
      if (line.hsnRates) {
        if (payload.isInterstate) {
          igst = round2((amount * line.hsnRates.igst_rate) / 100);
        } else {
          cgst = round2((amount * line.hsnRates.cgst_rate) / 100);
          sgst = round2((amount * line.hsnRates.sgst_rate) / 100);
        }
      }
      cgstTotal += cgst; sgstTotal += sgst; igstTotal += igst;
      return { ...line, netWeight, metalValue, amount, cgst, sgst, igst };
    });

    const totalAmount = round2(subtotal + cgstTotal + sgstTotal + igstTotal);

    const info = db.prepare(
      `INSERT INTO purchases (purchase_number, supplier_id, purchase_date, invoice_number,
        subtotal, cgst_amount, sgst_amount, igst_amount, total_amount, payment_status, amount_paid, notes)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`
    ).run(
      purchaseNumber, payload.supplierId, payload.purchaseDate, payload.invoiceNumber || null,
      subtotal, cgstTotal, sgstTotal, igstTotal, totalAmount,
      payload.amountPaid >= totalAmount ? 'PAID' : payload.amountPaid > 0 ? 'PARTIAL' : 'UNPAID',
      payload.amountPaid || 0, payload.notes || null
    );
    const purchaseId = info.lastInsertRowid;

    for (const line of lineComputations) {
      const piInfo = db.prepare(
        `INSERT INTO purchase_items (purchase_id, description, metal_type, purity_id, gross_weight,
          stone_weight, net_weight, rate_per_gram, making_charge, amount, hsn_id)
         VALUES (?,?,?,?,?,?,?,?,?,?,?)`
      ).run(
        purchaseId, line.description, line.metalType, line.purityId, line.grossWeight,
        line.stoneWeight || 0, line.netWeight, line.ratePerGram, line.makingCharge || 0, line.amount, line.hsnId || null
      );
      const purchaseItemId = piInfo.lastInsertRowid;

      // Auto-create the inventory item for this purchase line
      const createdItem = inventoryService.createItem({
        name: line.description,
        categoryId: line.categoryId,
        metalType: line.metalType,
        purityId: line.purityId,
        grossWeight: line.grossWeight,
        stoneWeight: line.stoneWeight || 0,
        stoneDetails: line.stoneDetails,
        stoneCharge: line.stoneCharge || 0,
        makingChargeType: line.makingChargeType || 'PER_GRAM',
        makingChargeValue: line.makingChargeValue || 0,
        wastagePercent: line.wastagePercent || 0,
        huidNumber: line.huidNumber,
        hallmarkCertificateNo: line.hallmarkCertificateNo,
        purchaseId,
        sourceType: 'PURCHASE',
        costRatePerGram: line.ratePerGram,
        quantity: line.quantity || 1,
        referenceTable: 'purchases',
        referenceId: purchaseId,
      });

      db.prepare('UPDATE purchase_items SET item_id = ? WHERE id = ?').run(createdItem.id, purchaseItemId);
    }

    supplierService.postLedgerEntry(db, {
      supplierId: payload.supplierId, transactionType: 'PURCHASE', referenceTable: 'purchases',
      referenceId: purchaseId, credit: totalAmount, notes: `Purchase bill ${purchaseNumber}`,
    });

    if (payload.amountPaid > 0) {
      supplierService.postLedgerEntry(db, {
        supplierId: payload.supplierId, transactionType: 'PAYMENT_MADE', referenceTable: 'purchases',
        referenceId: purchaseId, debit: payload.amountPaid, notes: `Payment against ${purchaseNumber}`,
      });
    }

    return getPurchaseById(purchaseId);
  });
  return tx();
}

function getPurchaseById(id) {
  const db = getDb();
  const purchase = db.prepare(
    `SELECT p.*, s.name AS supplier_name, s.gstin AS supplier_gstin
     FROM purchases p JOIN suppliers s ON s.id = p.supplier_id WHERE p.id = ?`
  ).get(id);
  if (!purchase) return null;
  purchase.items = db.prepare(
    `SELECT pi.*, pm.purity_name, h.hsn_code
     FROM purchase_items pi
     LEFT JOIN purity_master pm ON pm.id = pi.purity_id
     LEFT JOIN hsn_master h ON h.id = pi.hsn_id
     WHERE pi.purchase_id = ?`
  ).all(id);
  return purchase;
}

function listPurchases(filters = {}) {
  const db = getDb();
  let sql = `SELECT p.*, s.name AS supplier_name FROM purchases p JOIN suppliers s ON s.id = p.supplier_id WHERE 1=1`;
  const params = [];
  if (filters.supplierId) { sql += ' AND p.supplier_id = ?'; params.push(filters.supplierId); }
  if (filters.fromDate) { sql += ' AND p.purchase_date >= ?'; params.push(filters.fromDate); }
  if (filters.toDate) { sql += ' AND p.purchase_date <= ?'; params.push(filters.toDate); }
  sql += ' ORDER BY p.purchase_date DESC, p.id DESC';
  return db.prepare(sql).all(...params);
}

module.exports = { createPurchase, getPurchaseById, listPurchases };
