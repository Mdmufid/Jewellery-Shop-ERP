const { getDb } = require('../database/db');
const { nextNumber } = require('../utils/numberSequence');
const { round2 } = require('../utils/gst');

/**
 * Records an old-gold exchange (customer brings old jewellery to trade in).
 * The "effective fine weight" accounts for the tested purity and a melting
 * loss deduction percentage (standard trade practice), and is valued at the
 * current rate for that metal's pure (fine) rate.
 *
 *   effectiveFineWeight = netWeight * (purityTestedPercent/100) * (1 - deductionPercent/100)
 *   totalValue = effectiveFineWeight * ratePerGram (fine gold/silver rate per gram)
 */
function createExchange(payload) {
  const db = getDb();
  const tx = db.transaction(() => {
    const exchangeNumber = nextNumber('OLD_GOLD');
    const netWeight = round2(payload.grossWeight - (payload.stoneWeight || 0));
    const effectiveFineWeight = round2(
      netWeight * (payload.purityTestedPercent / 100) * (1 - (payload.deductionPercent || 0) / 100)
    );
    const totalValue = round2(effectiveFineWeight * payload.ratePerGram);

    // EXACT MATH: 14 Columns = 13 placeholders (?) + 1 literal string ('PENDING')
    const info = db.prepare(
      `INSERT INTO old_gold_exchanges (
        exchange_number, 
        customer_id, 
        exchange_date, 
        metal_type,
        gross_weight, 
        stone_weight, 
        net_weight, 
        purity_tested_percent, 
        deduction_percent,
        effective_fine_weight, 
        rate_per_gram, 
        total_value, 
        status, 
        notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?)`
    ).run(
      exchangeNumber, 
      payload.customerId || null, 
      payload.exchangeDate, 
      payload.metalType,
      payload.grossWeight, 
      payload.stoneWeight || 0, 
      netWeight, 
      payload.purityTestedPercent,
      payload.deductionPercent || 0, 
      effectiveFineWeight, 
      payload.ratePerGram, 
      totalValue, 
      payload.notes || null
    );
    
    return getExchangeById(info.lastInsertRowid);
  });
  return tx();
}

function getExchangeById(id) {
  return getDb().prepare(
    `SELECT e.*, c.name AS customer_name, c.phone AS customer_phone
     FROM old_gold_exchanges e LEFT JOIN customers c ON c.id = e.customer_id WHERE e.id = ?`
  ).get(id);
}

function listExchanges(filters = {}) {
  const db = getDb();
  let sql = `SELECT e.*, c.name AS customer_name FROM old_gold_exchanges e
             LEFT JOIN customers c ON c.id = e.customer_id WHERE 1=1`;
  const params = [];
  if (filters.status) { sql += ' AND e.status = ?'; params.push(filters.status); }
  if (filters.customerId) { sql += ' AND e.customer_id = ?'; params.push(filters.customerId); }
  sql += ' ORDER BY e.exchange_date DESC, e.id DESC';
  return db.prepare(sql).all(...params);
}

/** Lists exchanges not yet applied to any invoice, for the given customer (used in Billing to pick a trade-in credit). */
function listPendingExchangesForCustomer(customerId) {
  return getDb().prepare(
    `SELECT * FROM old_gold_exchanges WHERE customer_id = ? AND status = 'PENDING' ORDER BY exchange_date DESC`
  ).all(customerId);
}

/** Marks an exchange as consumed against an invoice. Called from billingService inside its transaction. */
function markExchangeAdjusted(db, exchangeId, invoiceId) {
  db.prepare(
    "UPDATE old_gold_exchanges SET status = 'ADJUSTED_IN_INVOICE', invoice_id = ? WHERE id = ?"
  ).run(invoiceId, exchangeId);
}

/** Settle an exchange for cash payout instead of adjusting against a future purchase. */
function settleForCash(exchangeId, { paymentMode, referenceNumber }) {
  const db = getDb();
  const exchange = getExchangeById(exchangeId);
  if (!exchange) throw new Error('Exchange not found');
  if (exchange.status !== 'PENDING') throw new Error('This exchange has already been settled or adjusted');
  db.prepare("UPDATE old_gold_exchanges SET status = 'SETTLED_CASH', notes = COALESCE(notes,'') || ? WHERE id = ?")
    .run(` | Cash settled via ${paymentMode}${referenceNumber ? ' Ref#' + referenceNumber : ''}`, exchangeId);
  return getExchangeById(exchangeId);
}

module.exports = {
  createExchange, getExchangeById, listExchanges, listPendingExchangesForCustomer,
  markExchangeAdjusted, settleForCash,
};
