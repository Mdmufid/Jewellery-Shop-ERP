const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');
const { app } = require('electron');
const billingService = require('./billingService');
const settingsService = require('./settingsService');

function numFmt(n) {
  return Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// Convert numbers to Indian Word Format (Lakhs, Crores, etc.)
function numberToWords(num) {
  if (num === 0) return 'Zero';
  const a = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  
  let str = '';
  let n = Math.floor(num);
  
  if (n > 999999999) return 'Amount too large';
  
  const crores = Math.floor(n / 10000000);
  n -= crores * 10000000;
  const lakhs = Math.floor(n / 100000);
  n -= lakhs * 100000;
  const thousands = Math.floor(n / 1000);
  n -= thousands * 1000;
  const hundreds = Math.floor(n / 100);
  n -= hundreds * 100;
  
  if (crores > 0) str += numberToWords(crores) + ' Crore ';
  if (lakhs > 0) str += numberToWords(lakhs) + ' Lakh ';
  if (thousands > 0) str += (thousands < 20 ? a[thousands] : b[Math.floor(thousands / 10)] + (thousands % 10 !== 0 ? ' ' + a[thousands % 10] : '')) + ' Thousand ';
  if (hundreds > 0) str += a[hundreds] + ' Hundred ';
  if (n > 0) str += (str !== '' ? 'and ' : '') + (n < 20 ? a[n] : b[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + a[n % 10] : ''));
  
  return str.trim();
}

function generateInvoicePdf(invoiceId, destinationPath) {
  const invoice = billingService.getInvoiceById(invoiceId);
  if (!invoice) throw new Error('Invoice not found');
  const settings = settingsService.getAllSettings();

  const outDir = destinationPath ? path.dirname(destinationPath) : path.join(app.getPath('documents'), 'Luxury Jewellers Invoices');
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  const outPath = destinationPath || path.join(outDir, `${invoice.invoice_number.replace(/\//g, '-')}.pdf`);

  const doc = new PDFDocument({ size: 'A4', margin: 30 });
  const stream = fs.createWriteStream(outPath);
  doc.pipe(stream);

  // ==========================================
  // 1. TOP HEADER SECTION (Logos & Text)
  // ==========================================
  doc.fontSize(8).font('Helvetica-Bold');
  doc.text(`GSTIN : 12345678 ${settings.shop_gstin || ''}`, 30, 30);
  doc.text(`Email - mdmufid2004@gmail.com ${settings.shop_email || ''}\nMob No -8582803336 ${settings.shop_phone || ''}`, 350, 30, { align: 'right' });

  const headerY = 55;

  // --- LEFT LOGO (Shop Logo) ---
  doc.image(path.join(__dirname, '../../public/assets/icon.png'), 30, headerY, { width: 80, height: 80 });

  // --- CENTER TEXT ---
  doc.fontSize(16).text(settings.shop_name || 'LUXURY JEWELLERS', 120, headerY, { width: 355, align: 'center' });
  doc.fontSize(9).text('Dealer In Hallmark Gold, Silver & Diamond Ornaments', { width: 355, align: 'center' });
  doc.fontSize(8).font('Helvetica').text(settings.shop_address || '', { width: 355, align: 'center' });
  
  // --- RIGHT LOGO (Hallmark Logo) ---
  doc.image(path.join(__dirname, '../../public/assets/hallmark.png'), 485, headerY, { width: 80, height: 80 });
  
  const taxInvoiceY = 145; 
  
  doc.fontSize(10).font('Helvetica-Bold').text('TAX INVOICE', 30, taxInvoiceY, { width: 535, align: 'center', underline: true });
  
  // ==========================================
  // 2. CUSTOMER & INVOICE DETAILS BOX
  // ==========================================
  const infoY = 165; 
  const boxHeight = 75; 

  doc.rect(30, infoY, 535, boxHeight).stroke(); 
  doc.moveTo(350, infoY).lineTo(350, infoY + boxHeight).stroke(); 

  // Left Side: Customer
  doc.fontSize(8).font('Helvetica-Bold').text('Customer Details :', 35, infoY + 5);
  doc.font('Helvetica').text(`Name : ${invoice.customer_name || 'Cash Customer'}`, 35, infoY + 18);
  doc.text(`Address : ${invoice.customer_address || ''}`, 35, infoY + 30, { width: 300, height: 22, ellipsis: true });
  
  doc.text(`Phone : ${invoice.customer_phone || ''}`, 35, infoY + 58);
  doc.text(`PAN : ${invoice.customer_pan || ''}`, 180, infoY + 58);

  // Right Side: Invoice Info
  doc.font('Helvetica-Bold').text(`Invoice no : `, 360, infoY + 15, { continued: true }).font('Helvetica').text(invoice.invoice_number);
  doc.font('Helvetica-Bold').text(`Date : `, 360, infoY + 35, { continued: true }).font('Helvetica').text(invoice.invoice_date);

  // ==========================================
  // 3. DYNAMIC ITEMS TABLE
  // ==========================================
  let tableY = infoY + boxHeight + 5; 
  const colX = [30, 55, 145, 180, 215, 250, 285, 305, 345, 385, 425, 465, 505, 565];
  
  doc.rect(30, tableY, 535, 20).fillAndStroke('#f0f0f0', '#000');
  doc.fillColor('#000').fontSize(7).font('Helvetica-Bold');
  
  const headers = ['Type', 'Description', 'Hsn\nCode', 'Purity', 'Gross\nWt.', 'Net\nWt.', 'Pcs.', 'Rate', 'Value', 'Dia/Stn.\n(Cts)', 'Making\nCharges', 'Dia/Stn\nValue', 'Amount\n(Rupees)'];
  for (let i = 0; i < headers.length; i++) {
    doc.text(headers[i], colX[i] + 2, tableY + 3, { width: colX[i+1] - colX[i] - 4, align: 'center' });
  }

  tableY += 20;
  doc.font('Helvetica');

  invoice.items.forEach((item) => {
    doc.text('S', colX[0] + 2, tableY + 5, { width: 21, align: 'center' });
    doc.text(item.description, colX[1] + 2, tableY + 5, { width: 86, align: 'left' });
    doc.text(item.hsn_code || '-', colX[2] + 2, tableY + 5, { width: 31, align: 'center' });
    doc.text(item.purity_name, colX[3] + 2, tableY + 5, { width: 31, align: 'center' });
    doc.text(item.gross_weight.toFixed(3), colX[4] + 2, tableY + 5, { width: 31, align: 'right' });
    doc.text(item.net_weight.toFixed(3), colX[5] + 2, tableY + 5, { width: 31, align: 'right' });
    doc.text('1', colX[6] + 2, tableY + 5, { width: 16, align: 'center' });
    doc.text(item.rate_per_gram.toFixed(2), colX[7] + 2, tableY + 5, { width: 36, align: 'right' });
    doc.text(numFmt(item.taxable_value), colX[8] + 2, tableY + 5, { width: 36, align: 'right' });
    doc.text('-', colX[9] + 2, tableY + 5, { width: 36, align: 'center' });
    doc.text(numFmt(item.making_charge), colX[10] + 2, tableY + 5, { width: 36, align: 'right' });
    doc.text('-', colX[11] + 2, tableY + 5, { width: 36, align: 'center' });
    doc.text(numFmt(item.taxable_value), colX[12] + 2, tableY + 5, { width: 56, align: 'right' });

    tableY += 20; 
  });

  const tableBottomY = tableY + 5; 

  colX.forEach(x => { doc.moveTo(x, infoY + boxHeight + 5).lineTo(x, tableBottomY).stroke(); });
  
  doc.rect(30, tableBottomY, 535, 15).stroke();
  doc.font('Helvetica-Bold').text('Total', 35, tableBottomY + 4);
  doc.text('Gold Wt : ' + invoice.items.reduce((sum, item) => sum + item.net_weight, 0).toFixed(3), 145, tableBottomY + 4);
  doc.text(numFmt(invoice.taxable_amount), 507, tableBottomY + 4, { width: 56, align: 'right' });

  // ==========================================
  // 4. TOTALS & CALCULATIONS
  // ==========================================
  let calcY = tableBottomY + 15;
  const rightColX = 425; 
  
  function drawCalcRow(label, val, y) {
    doc.rect(30, y, 535, 15).stroke(); 
    doc.moveTo(425, y).lineTo(425, y + 15).stroke(); 
    doc.moveTo(505, y).lineTo(505, y + 15).stroke(); 

    doc.font('Helvetica-Bold').text(label, rightColX, y + 4, { width: 75, align: 'right' });
    doc.font('Helvetica').text(val, 507, y + 4, { width: 56, align: 'right' });
  }

  if (!invoice.is_interstate) {
    drawCalcRow('SGST', numFmt(invoice.sgst_amount), calcY); calcY += 15;
    drawCalcRow('CGST', numFmt(invoice.cgst_amount), calcY); calcY += 15;
  } else {
    drawCalcRow('IGST', numFmt(invoice.igst_amount), calcY); calcY += 15;
  }
  
  // NEW LOGIC: Only display Old Gold deduction if it is greater than 0
  if (invoice.old_gold_amount && invoice.old_gold_amount > 0) {
    drawCalcRow('Less: Old Gold', '-' + numFmt(invoice.old_gold_amount), calcY); 
    calcY += 15;
  }
  
  drawCalcRow('ROUND OFF', numFmt(invoice.round_off), calcY); calcY += 15;
  
  // Total Amount Row
  doc.rect(30, calcY, 535, 15).stroke(); 
  doc.moveTo(425, calcY).lineTo(425, calcY + 15).stroke();
  doc.moveTo(505, calcY).lineTo(505, calcY + 15).stroke();
  
  doc.font('Helvetica-Bold').text('Total Amt with tax', rightColX, calcY + 4, { width: 75, align: 'right' });
  doc.text(numFmt(invoice.grand_total), 507, calcY + 4, { width: 56, align: 'right' });
  
  const amountInWords = numberToWords(Math.round(invoice.grand_total));
  doc.text(`Rs. ${amountInWords} Only`, 35, calcY + 4);

  calcY += 15;
  
  // Only show these rows if they actually exist, otherwise they clutter the PDF
  if(invoice.amount_paid > 0) {
      drawCalcRow(`RECEIPT ${invoice.payment_mode || 'PAYMENT'}`, numFmt(invoice.amount_paid), calcY); calcY += 15; 
  }
  
  // Balance Amount Row
  doc.rect(30, calcY, 535, 15).stroke(); 
  doc.moveTo(425, calcY).lineTo(425, calcY + 15).stroke();
  doc.moveTo(505, calcY).lineTo(505, calcY + 15).stroke();

  doc.font('Helvetica-Bold').text('Balance Amount', rightColX, calcY + 4, { width: 75, align: 'right' });
  doc.text(invoice.balance_due > 0 ? numFmt(invoice.balance_due) : 'NIL', 507, calcY + 4, { width: 56, align: 'right' });

  // ==========================================
  // 5. TAX BREAKDOWN TABLE
  // ==========================================
  let taxY = calcY + 15;
  const tX = [30, 200, 280, 315, 385, 420, 490, 565]; 

  doc.rect(30, taxY, 535, 20).stroke();
  doc.moveTo(tX[2], taxY + 10).lineTo(tX[6], taxY + 10).stroke(); 
  
  doc.fontSize(7).font('Helvetica-Bold');
  doc.text('HSN \\ SAC', tX[0], taxY + 6, { width: tX[1]-tX[0], align: 'center' });
  doc.text('Taxable\nValue', tX[1], taxY + 3, { width: tX[2]-tX[1], align: 'center' });
  doc.text('Central Tax', tX[2], taxY + 2, { width: tX[4]-tX[2], align: 'center' });
  doc.text('State Tax', tX[4], taxY + 2, { width: tX[6]-tX[4], align: 'center' });
  doc.text('Total\nTax Amt', tX[6], taxY + 3, { width: tX[7]-tX[6], align: 'center' });
  
  doc.text('Rate', tX[2], taxY + 12, { width: tX[3]-tX[2], align: 'center' });
  doc.text('Amount', tX[3], taxY + 12, { width: tX[4]-tX[3], align: 'center' });
  doc.text('Rate', tX[4], taxY + 12, { width: tX[5]-tX[4], align: 'center' });
  doc.text('Amount', tX[5], taxY + 12, { width: tX[6]-tX[5], align: 'center' });

  taxY += 20;
  doc.rect(30, taxY, 535, 15).stroke();
  doc.font('Helvetica');
  doc.text(invoice.items[0]?.hsn_code || '', tX[0], taxY + 4, { width: tX[1]-tX[0], align: 'center' });
  doc.text(numFmt(invoice.taxable_amount), tX[1]-5, taxY + 4, { width: tX[2]-tX[1], align: 'right' });
  doc.text((invoice.items[0]?.cgst_rate || 0) + '%', tX[2], taxY + 4, { width: tX[3]-tX[2], align: 'center' });
  doc.text(numFmt(invoice.cgst_amount), tX[3]-5, taxY + 4, { width: tX[4]-tX[3], align: 'right' });
  doc.text((invoice.items[0]?.sgst_rate || 0) + '%', tX[4], taxY + 4, { width: tX[5]-tX[4], align: 'center' });
  doc.text(numFmt(invoice.sgst_amount), tX[5]-5, taxY + 4, { width: tX[6]-tX[5], align: 'right' });
  doc.text(numFmt((invoice.cgst_amount || 0) + (invoice.sgst_amount || 0)), tX[6]-5, taxY + 4, { width: tX[7]-tX[6], align: 'right' });

  tX.forEach(x => { doc.moveTo(x, calcY + 15).lineTo(x, taxY + 15).stroke(); });
  [tX[3], tX[5]].forEach(x => { doc.moveTo(x, calcY + 25).lineTo(x, taxY + 15).stroke(); });

  // ==========================================
  // 6. FOOTER & SIGNATURES
  // ==========================================
  let footY = taxY + 25;
  doc.fontSize(8).font('Helvetica-Bold').text('Terms & Conditions :', 35, footY);
  
  doc.fontSize(7).font('Helvetica');
  const terms = settings.invoice_terms ? settings.invoice_terms.split('\n') : [
    "GOODS ONCE SOLD WILL NOT BE TAKEN BACK.",
    "ONLY HALLMARKED GOLD WILL BE TAKEN BACK AFTER DEDUCTION.",
    "IF THE MONEY IS NOT PAID WITHIN 15 DAYS THEN 18% INTEREST WILL BE CHARGED.",
    "ALL SUBJECT TO JURISDICTION."
  ];
  
  terms.forEach((term, index) => {
    doc.text(`• ${term}`, 35, footY + 12 + (index * 10));
  });

  doc.font('Helvetica-Bold').text(`FOR ${settings.shop_name || 'LUXURY JEWELLERS'}`, 350, footY, { width: 215, align: 'right' });
  doc.text('E & O.E', 350, footY + 12, { width: 215, align: 'right' });

  doc.font('Helvetica-Bold').text('Customer Signature', 50, footY + 70);
  doc.text('AUTHORISED SIGNATORY', 400, footY + 70, { width: 150, align: 'right' });
  
  doc.moveTo(35, footY + 68).lineTo(150, footY + 68).stroke();
  doc.moveTo(400, footY + 68).lineTo(565, footY + 68).stroke();

  doc.end();

  return new Promise((resolve, reject) => {
    stream.on('finish', () => resolve({ path: outPath }));
    stream.on('error', reject);
  });
}

module.exports = { generateInvoicePdf };