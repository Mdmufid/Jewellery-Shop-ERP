const bcrypt = require('bcryptjs');
const { getDb } = require('../database/db');

function login(username, password) {
  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE username = ? AND is_active = 1').get(username);
  if (!user) throw new Error('Invalid username or password');
  const valid = bcrypt.compareSync(password, user.password_hash);
  if (!valid) throw new Error('Invalid username or password');
  return { id: user.id, username: user.username, fullName: user.full_name, role: user.role };
}

function createUser({ username, password, fullName, role }) {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (existing) throw new Error('Username already exists');
  const hash = bcrypt.hashSync(password, 10);
  const info = db.prepare(
    'INSERT INTO users (username, password_hash, full_name, role) VALUES (?,?,?,?)'
  ).run(username, hash, fullName, role);
  return getUserById(info.lastInsertRowid);
}

function getUserById(id) {
  const db = getDb();
  const u = db.prepare('SELECT id, username, full_name, role, is_active FROM users WHERE id = ?').get(id);
  return u;
}

function listUsers() {
  return getDb().prepare('SELECT id, username, full_name, role, is_active FROM users ORDER BY full_name').all();
}

function changePassword(userId, oldPassword, newPassword) {
  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  if (!user) throw new Error('User not found');
  if (!bcrypt.compareSync(oldPassword, user.password_hash)) throw new Error('Current password is incorrect');
  const hash = bcrypt.hashSync(newPassword, 10);
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, userId);
  return { success: true };
}

function resetPassword(adminUserId, targetUserId, newPassword) {
  const db = getDb();
  const admin = db.prepare('SELECT role FROM users WHERE id = ?').get(adminUserId);
  if (!admin || admin.role !== 'ADMIN') throw new Error('Only an administrator can reset passwords');
  const hash = bcrypt.hashSync(newPassword, 10);
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, targetUserId);
  return { success: true };
}

function setUserActive(userId, isActive) {
  getDb().prepare('UPDATE users SET is_active = ? WHERE id = ?').run(isActive ? 1 : 0, userId);
  return getUserById(userId);
}

// NEW FUNCTION: Verifies the typed password against active admin hashes
function verifyAdminPassword(plainTextPassword) {
  const db = getDb();
  const admins = db.prepare(`SELECT password_hash FROM users WHERE role = 'ADMIN' AND is_active = 1`).all();
  
  if (!admins || admins.length === 0) {
    throw new Error('No active admin accounts found in the system');
  }

  for (const admin of admins) {
    if (bcrypt.compareSync(plainTextPassword, admin.password_hash)) {
      return true; // Match found
    }
  }

  return false; // No match found
}

// Updated exports to include verifyAdminPassword
module.exports = { 
  login, 
  createUser, 
  listUsers, 
  changePassword, 
  resetPassword, 
  setUserActive, 
  getUserById, 
  verifyAdminPassword 
};