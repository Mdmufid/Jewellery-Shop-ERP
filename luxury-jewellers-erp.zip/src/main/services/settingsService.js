const { getDb } = require('../database/db');

function getAllSettings() {
  const rows = getDb().prepare('SELECT key, value FROM settings').all();
  const obj = {};
  for (const r of rows) obj[r.key] = r.value;
  return obj;
}

function getSetting(key) {
  const row = getDb().prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : null;
}

function updateSettings(patch) {
  const db = getDb();
  const upsert = db.prepare(
    `INSERT INTO settings (key, value) VALUES (?, ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value`
  );
  const tx = db.transaction((entries) => {
    for (const [key, value] of entries) upsert.run(key, String(value ?? ''));
  });
  tx(Object.entries(patch));
  return getAllSettings();
}

function listCategories() {
  return getDb().prepare(
    `SELECT c.*, h.hsn_code FROM categories c LEFT JOIN hsn_master h ON h.id = c.hsn_id ORDER BY c.name`
  ).all();
}

function createCategory({ name, hsnId }) {
  const db = getDb();
  const info = db.prepare('INSERT INTO categories (name, hsn_id) VALUES (?, ?)').run(name, hsnId || null);
  return db.prepare('SELECT * FROM categories WHERE id = ?').get(info.lastInsertRowid);
}

function listHsnCodes() {
  return getDb().prepare('SELECT * FROM hsn_master ORDER BY hsn_code').all();
}

function updateHsnRate(id, { cgstRate, sgstRate, igstRate }) {
  const db = getDb();
  db.prepare('UPDATE hsn_master SET cgst_rate=?, sgst_rate=?, igst_rate=? WHERE id=?').run(cgstRate, sgstRate, igstRate, id);
  return db.prepare('SELECT * FROM hsn_master WHERE id = ?').get(id);
}

module.exports = { getAllSettings, getSetting, updateSettings, listCategories, createCategory, listHsnCodes, updateHsnRate };
