const { getDb } = require('../database/db');
const inventoryService = require('./inventoryService');
const { nextNumber } = require('../utils/numberSequence');

function createArtisan(payload) {
  const db = getDb();
  
  if (payload.phone && payload.phone.trim() !== '') {
    const existing = db.prepare('SELECT name FROM artisans WHERE phone = ? AND is_active = 1').get(payload.phone.trim());
    if (existing) throw new Error(`This phone number is already registered to ${existing.name}.`);
  }

  const tx = db.transaction(() => {
    const info = db.prepare(`
      INSERT INTO artisans (name, phone, address, metal_balance, cash_balance)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      payload.name, 
      payload.phone || null, 
      payload.address || null, 
      payload.openingMetal || 0, 
      payload.openingCash || 0
    );

    const id = info.lastInsertRowid;

    if (payload.openingMetal) {
      db.prepare(`
        INSERT INTO artisan_metal_ledger (artisan_id, transaction_type, weight_out, balance, notes)
        VALUES (?, 'OPENING_BALANCE', ?, ?, 'Initial metal balance')
      `).run(id, payload.openingMetal, payload.openingMetal);
    }

    if (payload.openingCash) {
      db.prepare(`
        INSERT INTO artisan_cash_ledger (artisan_id, transaction_type, credit, balance, notes)
        VALUES (?, 'OPENING_BALANCE', ?, ?, 'Initial pending making charges')
      `).run(id, payload.openingCash, payload.openingCash);
    }

    return getArtisanById(id);
  });

  return tx();
}

function getArtisanById(id) {
  return getDb().prepare('SELECT * FROM artisans WHERE id = ?').get(id);
}

function listArtisans(search) {
  const db = getDb();
  if (search) {
    const like = `%${search}%`;
    return db.prepare('SELECT * FROM artisans WHERE is_active = 1 AND name LIKE ? ORDER BY name').all(like);
  }
  return db.prepare('SELECT * FROM artisans WHERE is_active = 1 ORDER BY name').all();
}

function deleteArtisan(id) {
  getDb().prepare('UPDATE artisans SET is_active = 0 WHERE id = ?').run(id);
  return { success: true };
}

function issueMetal(payload) {
  const db = getDb();
  const tx = db.transaction(() => {
    const artisan = getArtisanById(payload.artisanId);
    if (!artisan) throw new Error('Artisan not found');

    const newMetalBalance = artisan.metal_balance + parseFloat(payload.weight);

    db.prepare('UPDATE artisans SET metal_balance = ? WHERE id = ?').run(newMetalBalance, payload.artisanId);

    db.prepare(`
      INSERT INTO artisan_metal_ledger (artisan_id, transaction_type, weight_out, balance, notes)
      VALUES (?, 'ISSUE_METAL', ?, ?, ?)
    `).run(payload.artisanId, payload.weight, newMetalBalance, payload.notes || 'Raw metal issued');

    return getArtisanById(payload.artisanId);
  });
  return tx();
}

function payArtisan(payload) {
  const db = getDb();
  const tx = db.transaction(() => {
    const artisan = getArtisanById(payload.artisanId);
    if (!artisan) throw new Error('Artisan not found');

    const newCashBalance = artisan.cash_balance - parseFloat(payload.amount);

    db.prepare('UPDATE artisans SET cash_balance = ? WHERE id = ?').run(newCashBalance, payload.artisanId);

    db.prepare(`
      INSERT INTO artisan_cash_ledger (artisan_id, transaction_type, debit, balance, notes)
      VALUES (?, 'PAYMENT_MADE', ?, ?, ?)
    `).run(payload.artisanId, payload.amount, newCashBalance, payload.notes || `Payment via ${payload.paymentMode}`);

    return getArtisanById(payload.artisanId);
  });
  return tx();
}

function getMetalLedger(artisanId) {
  return getDb().prepare('SELECT * FROM artisan_metal_ledger WHERE artisan_id = ? ORDER BY created_at DESC').all(artisanId);
}

function getCashLedger(artisanId) {
  return getDb().prepare('SELECT * FROM artisan_cash_ledger WHERE artisan_id = ? ORDER BY created_at DESC').all(artisanId);
}

function receiveFinishedGoods(payload) {
  const db = getDb();
  
  const tx = db.transaction(() => {
    const artisan = getArtisanById(payload.artisanId);
    if (!artisan) throw new Error('Artisan not found');

    const fineMetalUsed = parseFloat(payload.fineWeightUsed);
    const newMetalBalance = artisan.metal_balance - fineMetalUsed;
    
    db.prepare('UPDATE artisans SET metal_balance = ? WHERE id = ?').run(newMetalBalance, payload.artisanId);
    
    db.prepare(`
      INSERT INTO artisan_metal_ledger (artisan_id, transaction_type, weight_in, balance, notes)
      VALUES (?, 'RECEIVE_GOODS', ?, ?, ?)
    `).run(payload.artisanId, fineMetalUsed, newMetalBalance, `Received: ${payload.description} (Wastage: ${payload.wastagePercent}%)`);

    const makingChargeAmount = parseFloat(payload.makingChargeTotal);
    const newCashBalance = artisan.cash_balance + makingChargeAmount;
    
    db.prepare('UPDATE artisans SET cash_balance = ? WHERE id = ?').run(newCashBalance, payload.artisanId);
    
    db.prepare(`
      INSERT INTO artisan_cash_ledger (artisan_id, transaction_type, credit, balance, notes)
      VALUES (?, 'MAKING_CHARGE', ?, ?, ?)
    `).run(payload.artisanId, makingChargeAmount, newCashBalance, `Labor for: ${payload.description}`);

    const createdItem = inventoryService.createItem({
      name: payload.description,
      categoryId: payload.categoryId,
      metalType: payload.metalType || 'GOLD',
      purityId: payload.purityId,
      grossWeight: payload.grossWeight,
      stoneWeight: payload.stoneWeight || 0,
      wastagePercent: payload.wastagePercent || 0,
      makingChargeType: payload.makingChargeType || 'PER_GRAM',
      makingChargeValue: payload.makingChargeValue || 0,
      huidNumber: payload.huidNumber,
      quantity: payload.quantity || 1,
      sourceType: 'ARTISAN',
      referenceTable: 'artisans',
      referenceId: payload.artisanId
    });

    return { artisan: getArtisanById(payload.artisanId), item: createdItem };
  });
  
  return tx();
}

function listJobs() {
  const db = getDb();
  return db.prepare(`
    SELECT j.*, a.name AS artisan_name, p.purity_name 
    FROM artisan_jobs j 
    JOIN artisans a ON j.artisan_id = a.id 
    LEFT JOIN purity_master p ON j.purity_id = p.id
    ORDER BY j.issue_date DESC, j.id DESC
  `).all();
}

function issueJob(payload) {
  const db = getDb();
  const tx = db.transaction(() => {
    const jobNumber = nextNumber('ARTISAN_JOB'); 
    
    const info = db.prepare(`
      INSERT INTO artisan_jobs (job_number, artisan_id, issue_date, metal_type, purity_id, metal_issued_weight, expected_item_description, notes)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      jobNumber, payload.artisanId, payload.issueDate, payload.metalType, payload.purityId, 
      payload.metalIssuedWeight, payload.expectedItemDescription, payload.notes || null
    );
    
    return { id: info.lastInsertRowid, job_number: jobNumber };
  });
  return tx();
}

function lossReport(filters) {
  return {
    totalJobs: 0, totalIssued: 0, totalWastage: 0, avgWastagePercent: 0,
    totalMaking: 0, exceedCount: 0, allowedPercent: 0, excessiveJobs: []
  };
}

module.exports = {
  createArtisan, getArtisanById, listArtisans, deleteArtisan,
  issueMetal, payArtisan, getMetalLedger, getCashLedger, receiveFinishedGoods,
  listJobs, issueJob, lossReport
};