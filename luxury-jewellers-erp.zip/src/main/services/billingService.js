const { getDb } = require('../database/db');
const { nextNumber } = require('../utils/numberSequence');
const { computeTax, roundOffTotal, isInterstateSupply, round2 } = require('../utils/gst');
const { priceItem } = require('../utils/pricing');
const inventoryService = require('./inventoryService');
const customerService = require('./customerService');
const oldGoldService = require('./oldGoldService');

/**
 * Creates a sales invoice.
 *
 * payload = {
 *   invoiceDate, customerId (nullable for walk-in), placeOfSupplyStateCode,
 *   shopStateCode,
 *   lineItems: [{ itemId, description, hsnCode, metalType, purityName, grossWeight,
 *                 stoneWeight, ratePerGram, makingChargeType, makingChargeValue,
 *                 wastagePercent, stoneCharge, cgstRate, sgstRate, igstRate, huidNumber }],
 *   oldGoldExchangeIds: [id,...]   // pending exchanges to adjust as credit
 *   discountAmount,
 *   payments: [{ amount, paymentMode, referenceNumber }],
 *   createdBy
 * }
 */
function createInvoice(payload) {
  const db = getDb();
  const tx = db.transaction(() => {
    
    // --- NEW LOGIC: Auto-Create or Update Customer ---
    let finalCustomerId = payload.customerId;

    if (finalCustomerId) {
      // If a customer was selected, update their profile with any new info typed in the billing screen
      db.prepare(`
        UPDATE customers 
        SET name = ?, phone = ?, address = ?, pan_number = ? 
        WHERE id = ?
      `).run(
        payload.customerName, 
        payload.customerPhone, 
        payload.customerAddress, 
        payload.customerPan, 
        finalCustomerId
      );
    } else {
      // If it is a new walk-in, auto-create a new customer profile in the database
      const custInfo = db.prepare(`
        INSERT INTO customers (name, phone, address, pan_number, state_code) 
        VALUES (?, ?, ?, ?, ?)
      `).run(
        payload.customerName, 
        payload.customerPhone, 
        payload.customerAddress, 
        payload.customerPan, 
        payload.placeOfSupplyStateCode || '27'
      );
      finalCustomerId = custInfo.lastInsertRowid;
    }
    // --------------------------------------------------

    const calc = computeInvoice(payload);
    const isInterstate = isInterstateSupply(payload.shopStateCode, payload.placeOfSupplyStateCode);
    const invoiceNumber = nextNumber('INVOICE');
    const discount = round2(payload.discountAmount || 0);

    const info = db.prepare(
      `INSERT INTO invoices (
        invoice_number, invoice_date, customer_id, place_of_supply_state_code, is_interstate,
        subtotal, total_making_charges, total_stone_charges, taxable_amount,
        cgst_amount, sgst_amount, igst_amount, round_off, old_gold_exchange_value,
        scheme_redemption_value, discount_amount, grand_total, amount_paid, balance_due,
        status, created_by
      ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'COMPLETED', ?)`
    ).run(
      invoiceNumber, payload.invoiceDate, finalCustomerId, payload.placeOfSupplyStateCode, // <--- Now uses finalCustomerId
      isInterstate ? 1 : 0, round2(calc.subtotalMetal), round2(calc.totalMaking), round2(calc.totalStone), round2(calc.taxableAmount),
      round2(calc.cgstTotal), round2(calc.sgstTotal), round2(calc.igstTotal), calc.roundOff, calc.oldGoldValue, calc.schemeValue,
      discount, calc.grandTotal, calc.amountPaid, calc.balanceDue, payload.createdBy || null
    );
    const invoiceId = info.lastInsertRowid;

    // Insert items
    for (const line of calc.computedLines) {
      db.prepare(
        `INSERT INTO invoice_items (
          invoice_id, item_id, description, hsn_code, metal_type, purity_name, gross_weight,
          stone_weight, net_weight, rate_per_gram, metal_value, making_charge, stone_charge,
          taxable_value, cgst_rate, sgst_rate, igst_rate, cgst_amount, sgst_amount, igst_amount,
          line_total, huid_number
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
      ).run(
        invoiceId, line.itemId || null, line.description, line.hsnCode || null, line.metalType, line.purityName,
        line.grossWeight, line.stoneWeight || 0, line.netWeight, line.ratePerGram, line.metalValue,
        round2(line.makingCharge + line.wastageAmount), line.stoneCharge, line.taxableValue,
        line.cgstRate, line.sgstRate, line.igstRate, line.cgstAmount, line.sgstAmount, line.igstAmount,
        line.lineTotal, line.huidNumber || null
      );
      if (line.itemId) inventoryService.markItemSold(db, line.itemId, invoiceId);
    }

    // Payments
    for (const p of calc.payments) {
      db.prepare(
        'INSERT INTO invoice_payments (invoice_id, amount, payment_mode, reference_number) VALUES (?,?,?,?)'
      ).run(invoiceId, p.amount, p.paymentMode, p.referenceNumber || null);
    }

    // Adjust old gold exchanges
    for (const ex of calc.exchangesToAdjust) oldGoldService.markExchangeAdjusted(db, ex.id, invoiceId);

    // Ledger
    if (finalCustomerId) { // <--- Updated to use finalCustomerId
      customerService.postLedgerEntry(db, {
        customerId: finalCustomerId, transactionType: 'SALE', referenceTable: 'invoices',
        referenceId: invoiceId, debit: calc.grandTotal, notes: `Invoice ${invoiceNumber}`,
      });
      if (calc.amountPaid > 0) {
        customerService.postLedgerEntry(db, {
          customerId: finalCustomerId, transactionType: 'PAYMENT_RECEIVED', referenceTable: 'invoices',
          referenceId: invoiceId, credit: calc.amountPaid, notes: `Payment against ${invoiceNumber}`,
        });
      }
    }

    return getInvoiceById(invoiceId);
  });
  return tx();
}

/**
 * Compute invoice totals and a validated breakdown without writing to DB.
 * Useful for renderer previews and validations.
 */
function computeInvoice(payload) {
  const isInterstate = isInterstateSupply(payload.shopStateCode, payload.placeOfSupplyStateCode);

  let subtotalMetal = 0, totalMaking = 0, totalStone = 0, taxableAmount = 0;
  let cgstTotal = 0, sgstTotal = 0, igstTotal = 0;
  const computedLines = [];

  for (const line of payload.lineItems) {
    const netWeight = round2(line.grossWeight - (line.stoneWeight || 0));
    const priced = priceItem({
      netWeight, ratePerGram: line.ratePerGram, makingChargeType: line.makingChargeType,
      makingChargeValue: line.makingChargeValue, wastagePercent: line.wastagePercent, stoneCharge: line.stoneCharge,
    });
    const tax = computeTax(priced.taxableValue, {
      cgst_rate: line.cgstRate, sgst_rate: line.sgstRate, igst_rate: line.igstRate,
    }, isInterstate);
    const lineTotal = round2(priced.taxableValue + tax.cgstAmount + tax.sgstAmount + tax.igstAmount);

    subtotalMetal += priced.metalValue;
    totalMaking += priced.makingCharge + priced.wastageAmount;
    totalStone += priced.stoneCharge;
    taxableAmount += priced.taxableValue;
    cgstTotal += tax.cgstAmount; sgstTotal += tax.sgstAmount; igstTotal += tax.igstAmount;

    computedLines.push({ ...line, netWeight, ...priced, ...tax, lineTotal });
  }

  const discount = round2(payload.discountAmount || 0);

  // Old gold exchange credit
  let oldGoldValue = 0;
  const exchangesToAdjust = [];
  for (const exId of payload.oldGoldExchangeIds || []) {
    const ex = oldGoldService.getExchangeById(exId);
    if (!ex) throw new Error(`Old gold exchange #${exId} not found`);
    if (ex.status !== 'PENDING') throw new Error(`Old gold exchange ${ex.exchange_number} is not available for adjustment`);
    oldGoldValue += ex.total_value;
    exchangesToAdjust.push(ex);
  }
  oldGoldValue = round2(oldGoldValue);

  // Scheme redemption credit
  const schemeValue = 0;
  const enrollmentsToRedeem = [];

  const beforeRounding = round2(taxableAmount + cgstTotal + sgstTotal + igstTotal - discount - oldGoldValue - schemeValue);
  const { rounded: grandTotal, roundOff } = roundOffTotal(beforeRounding);

  const payments = payload.payments || [];
  const amountPaid = round2(payments.reduce((sum, p) => sum + p.amount, 0));
  const balanceDue = round2(grandTotal - amountPaid);

  return {
    isInterstate, computedLines, subtotalMetal, totalMaking, totalStone, taxableAmount,
    cgstTotal, sgstTotal, igstTotal, discount, oldGoldValue, schemeValue,
    beforeRounding, grandTotal, roundOff, payments, amountPaid, balanceDue,
    exchangesToAdjust, enrollmentsToRedeem
  };
}

function getInvoiceById(id) {
  const db = getDb();
  const invoice = db.prepare(
    `SELECT i.*, 
            c.name AS customer_name, 
            c.phone AS customer_phone, 
            c.gstin AS customer_gstin,
            c.pan_number AS customer_pan,  /* <--- ADDED PAN EXTRACTION */
            c.address AS customer_address, 
            c.state_code AS customer_state_code
     FROM invoices i 
     LEFT JOIN customers c ON c.id = i.customer_id 
     WHERE i.id = ?`
  ).get(id);
  
  if (!invoice) return null;
  invoice.items = db.prepare('SELECT * FROM invoice_items WHERE invoice_id = ?').all(id);
  invoice.payments = db.prepare('SELECT * FROM invoice_payments WHERE invoice_id = ?').all(id);
  return invoice;
}

function listInvoices(filters = {}) {
  const db = getDb();
  let sql = `SELECT i.*, c.name AS customer_name, c.phone AS customer_phone
             FROM invoices i LEFT JOIN customers c ON c.id = i.customer_id WHERE 1=1`;
  const params = [];
  if (filters.fromDate) { sql += ' AND i.invoice_date >= ?'; params.push(filters.fromDate); }
  if (filters.toDate) { sql += ' AND i.invoice_date <= ?'; params.push(filters.toDate); }
  if (filters.customerId) { sql += ' AND i.customer_id = ?'; params.push(filters.customerId); }
  if (filters.status) { sql += ' AND i.status = ?'; params.push(filters.status); }
  if (filters.search) { sql += ' AND i.invoice_number LIKE ?'; params.push(`%${filters.search}%`); }
  sql += ' ORDER BY i.invoice_date DESC, i.id DESC';
  return db.prepare(sql).all(...params);
}

/** Cancels a completed invoice: restores items to stock and reverses customer ledger impact. */
function cancelInvoice(invoiceId, reason) {
  const db = getDb();
  const tx = db.transaction(() => {
    const invoice = getInvoiceById(invoiceId);
    if (!invoice) throw new Error('Invoice not found');
    if (invoice.status !== 'COMPLETED') throw new Error('Only completed invoices can be cancelled');

    for (const line of invoice.items) {
      if (line.item_id) inventoryService.markItemReturned(db, line.item_id, invoiceId);
    }

    if (invoice.customer_id) {
      customerService.postLedgerEntry(db, {
        customerId: invoice.customer_id, transactionType: 'SALE_CANCELLED', referenceTable: 'invoices',
        referenceId: invoiceId, credit: invoice.grand_total, notes: `Invoice ${invoice.invoice_number} cancelled: ${reason || ''}`,
      });
    }

    db.prepare("UPDATE invoices SET status = 'CANCELLED' WHERE id = ?").run(invoiceId);
    return getInvoiceById(invoiceId);
  });
  return tx();
}

module.exports = { createInvoice, computeInvoice, getInvoiceById, listInvoices, cancelInvoice };
