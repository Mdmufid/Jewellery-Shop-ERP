const { getDb } = require('../database/db');

function listPurities() {
  return getDb().prepare('SELECT * FROM purity_master ORDER BY metal_type, fineness_percent DESC').all();
}

/** Returns the latest rate per gram for every purity as of a given date (defaults to today). */
function getCurrentRates(asOfDate) {
  const db = getDb();
  const date = asOfDate || new Date().toISOString().slice(0, 10);
  const purities = listPurities();
  return purities.map((p) => {
    const rate = db.prepare(
      `SELECT * FROM rate_master
       WHERE purity_id = ? AND effective_date <= ?
       ORDER BY effective_date DESC, id DESC LIMIT 1`
    ).get(p.id, date);
    return {
      ...p,
      rate_per_gram: rate ? rate.rate_per_gram : 0,
      rate_effective_date: rate ? rate.effective_date : null,
    };
  });
}

function getCurrentRateForPurity(purityId, asOfDate) {
  const db = getDb();
  const date = asOfDate || new Date().toISOString().slice(0, 10);
  const rate = db.prepare(
    `SELECT * FROM rate_master
     WHERE purity_id = ? AND effective_date <= ?
     ORDER BY effective_date DESC, id DESC LIMIT 1`
  ).get(purityId, date);
  if (!rate) throw new Error('No rate has been set for this purity yet. Please set today\'s rate in Rate Master.');
  return rate.rate_per_gram;
}

function setRate({ purityId, ratePerGram, effectiveDate, createdBy }) {
  const db = getDb();
  const date = effectiveDate || new Date().toISOString().slice(0, 10);
  const info = db.prepare(
    'INSERT INTO rate_master (purity_id, rate_per_gram, effective_date, created_by) VALUES (?, ?, ?, ?)'
  ).run(purityId, ratePerGram, date, createdBy || null);
  return { id: info.lastInsertRowid };
}

function getRateHistory(purityId, limit) {
  const db = getDb();
  return db.prepare(
    'SELECT * FROM rate_master WHERE purity_id = ? ORDER BY effective_date DESC, id DESC LIMIT ?'
  ).all(purityId, limit || 90);
}

module.exports = { listPurities, getCurrentRates, getCurrentRateForPurity, setRate, getRateHistory };
