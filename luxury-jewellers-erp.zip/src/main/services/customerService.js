const { getDb } = require('../database/db');
const { round2 } = require('../utils/gst');

function createCustomer(payload) {
  const db = getDb();
  const info = db.prepare(
    `INSERT INTO customers (name, phone, email, gstin, address, city, state_code, pan_number,
      opening_balance, current_balance, date_of_birth, anniversary_date, photo_path, secondary_phone,
      address2, zip_code, preferred_contact, loyalty_tier, communication_sms, communication_whatsapp, kyc_doc_path)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)` // <--- FIXED: Added the 21st question mark here!
  ).run(
    payload.name, payload.phone || null, payload.email || null, payload.gstin || null,
    payload.address || null, payload.city || null, payload.stateCode || '27', payload.panNumber || null,
    payload.openingBalance || 0, payload.openingBalance || 0, payload.dateOfBirth || null, payload.anniversaryDate || null,
    payload.photoPath || null, payload.secondaryPhone || null, payload.address2 || null, payload.zipCode || null,
    payload.preferredContact || null, payload.loyaltyTier || null, payload.communicationSms ? 1 : 0, payload.communicationWhatsapp ? 1 : 0,
    payload.kycDocPath || null
  );
  
  const id = info.lastInsertRowid;
  if (payload.openingBalance) {
    db.prepare(
      `INSERT INTO customer_ledger (customer_id, transaction_type, debit, credit, balance, notes)
       VALUES (?, 'OPENING_BALANCE', ?, 0, ?, 'Opening balance')`
    ).run(id, payload.openingBalance, payload.openingBalance);
  }
  return getCustomerById(id);
}

function updateCustomer(id, payload) {
  const db = getDb();
  const existing = getCustomerById(id);
  if (!existing) throw new Error('Customer not found');
  db.prepare(
    `UPDATE customers SET name=?, phone=?, email=?, gstin=?, address=?, city=?, state_code=?, pan_number=?,
      date_of_birth=?, anniversary_date=?, photo_path=?, secondary_phone=?, address2=?, zip_code=?, preferred_contact=?,
      loyalty_tier=?, communication_sms=?, communication_whatsapp=?, kyc_doc_path=? WHERE id=?`
  ).run(
    payload.name ?? existing.name, payload.phone ?? existing.phone, payload.email ?? existing.email,
    payload.gstin ?? existing.gstin, payload.address ?? existing.address, payload.city ?? existing.city,
    payload.stateCode ?? existing.state_code, payload.panNumber ?? existing.pan_number,
    payload.dateOfBirth ?? existing.date_of_birth, payload.anniversaryDate ?? existing.anniversary_date,
    payload.photoPath ?? existing.photo_path, payload.secondaryPhone ?? existing.secondary_phone,
    payload.address2 ?? existing.address2, payload.zipCode ?? existing.zip_code,
    payload.preferredContact ?? existing.preferred_contact, payload.loyaltyTier ?? existing.loyalty_tier,
    (payload.communicationSms === undefined ? existing.communication_sms : (payload.communicationSms ? 1 : 0)),
    (payload.communicationWhatsapp === undefined ? existing.communication_whatsapp : (payload.communicationWhatsapp ? 1 : 0)),
    payload.kycDocPath ?? existing.kyc_doc_path,
    id
  );
  return getCustomerById(id);
}

function getCustomerById(id) {
  return getDb().prepare('SELECT * FROM customers WHERE id = ?').get(id);
}

function listCustomers(search) {
  const db = getDb();
  if (search) {
    const like = `%${search}%`;
    return db.prepare(
      'SELECT * FROM customers WHERE is_active = 1 AND (name LIKE ? OR phone LIKE ?) ORDER BY name'
    ).all(like, like);
  }
  return db.prepare('SELECT * FROM customers WHERE is_active = 1 ORDER BY name').all();
}

function getCustomerLedger(customerId) {
  return getDb().prepare(
    'SELECT * FROM customer_ledger WHERE customer_id = ? ORDER BY created_at DESC, id DESC'
  ).all(customerId);
}

/** Posts a ledger entry and updates the running balance on the customer record. Must run inside caller's transaction. */
function postLedgerEntry(db, { customerId, transactionType, referenceTable, referenceId, debit, credit, notes }) {
  const customer = db.prepare('SELECT current_balance FROM customers WHERE id = ?').get(customerId);
  const newBalance = round2(customer.current_balance + (debit || 0) - (credit || 0));
  db.prepare(
    `INSERT INTO customer_ledger (customer_id, transaction_type, reference_table, reference_id, debit, credit, balance, notes)
     VALUES (?,?,?,?,?,?,?,?)`
  ).run(customerId, transactionType, referenceTable || null, referenceId || null, debit || 0, credit || 0, newBalance, notes || null);
  db.prepare('UPDATE customers SET current_balance = ? WHERE id = ?').run(newBalance, customerId);
  return newBalance;
}

module.exports = {
  createCustomer, updateCustomer, getCustomerById, listCustomers,
  getCustomerLedger, postLedgerEntry,
};