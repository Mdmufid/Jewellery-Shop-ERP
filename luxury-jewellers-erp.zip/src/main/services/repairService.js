const { getDb } = require('../database/db');
const { nextNumber } = require('../utils/numberSequence');
const { round2 } = require('../utils/gst');

function getRepairById(id) {
  return getDb().prepare(
    `SELECT r.*, c.name AS customer_name, c.phone AS customer_phone
     FROM repairs r
     LEFT JOIN customers c ON c.id = r.customer_id
     WHERE r.id = ?`
  ).get(id);
}

function listRepairPhotos(repairId) {
  return getDb().prepare('SELECT * FROM repair_photos WHERE repair_id = ? ORDER BY taken_at').all(repairId);
}

function addRepairPhoto(repairId, filePath, caption) {
  const db = getDb();
  const info = db.prepare('INSERT INTO repair_photos (repair_id, file_path, caption) VALUES (?,?,?)').run(repairId, filePath, caption || null);
  return listRepairPhotos(repairId);
}

function listStatusHistory(repairId) {
  return getDb().prepare('SELECT rsh.*, u.full_name AS changed_by_name FROM repair_status_history rsh LEFT JOIN users u ON u.id = rsh.changed_by WHERE repair_id = ? ORDER BY changed_at').all(repairId);
}

function addStatusHistory(repairId, status, note, changedBy) {
  const db = getDb();
  db.prepare('INSERT INTO repair_status_history (repair_id, status, note, changed_by) VALUES (?,?,?,?)').run(repairId, status, note || null, changedBy || null);
  return listStatusHistory(repairId);
}

function createRepair(payload) {
  const db = getDb();
  const tx = db.transaction(() => {
    const repairNumber = nextNumber('REPAIR');
    const totalCharge = round2(payload.totalCharge || 0);
    const advancePaid = round2(payload.advancePaid || 0);
    const balanceDue = round2(Math.max(totalCharge - advancePaid, 0));

    const info = db.prepare(
      `INSERT INTO repairs (
        repair_number, customer_id, received_date, item_description, issue_details,
        photo_path, advance_paid, expected_ready_date, total_charge, balance_due,
        status, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?)`
    ).run(
      repairNumber,
      payload.customerId || null,
      payload.receivedDate,
      payload.itemDescription,
      payload.issueDetails,
      payload.photoPath || null,
      advancePaid,
      payload.expectedReadyDate || null,
      totalCharge,
      balanceDue,
      payload.notes || null
    );
    return getRepairById(info.lastInsertRowid);
  });

  return tx();
}

function listRepairs(filters = {}) {
  const db = getDb();
  let sql = `SELECT r.*, c.name AS customer_name, c.phone AS customer_phone
             FROM repairs r LEFT JOIN customers c ON c.id = r.customer_id
             WHERE 1=1`;
  const params = [];
  if (filters.status) { sql += ' AND r.status = ?'; params.push(filters.status); }
  if (filters.customerId) { sql += ' AND r.customer_id = ?'; params.push(filters.customerId); }
  sql += ' ORDER BY r.received_date DESC, r.id DESC';
  return db.prepare(sql).all(...params);
}

function updateRepair(id, payload) {
  const db = getDb();
  const existing = getRepairById(id);
  if (!existing) throw new Error('Repair not found');

  const totalCharge = payload.totalCharge !== undefined ? round2(payload.totalCharge || 0) : round2(existing.total_charge || 0);
  const advancePaid = payload.advancePaid !== undefined ? round2(payload.advancePaid || 0) : round2(existing.advance_paid || 0);
  const status = payload.status || existing.status;
  const completedAt = status === 'DELIVERED' ? (payload.completedAt || new Date().toISOString().slice(0, 10)) : (payload.completedAt || existing.completed_at || null);
  const balanceDue = round2(Math.max(totalCharge - advancePaid, 0));

  db.prepare(
    `UPDATE repairs SET
      customer_id = ?, received_date = ?, item_description = ?, issue_details = ?,
      photo_path = ?, advance_paid = ?, expected_ready_date = ?, total_charge = ?,
      balance_due = ?, status = ?, completed_at = ?, notes = ?, updated_at = datetime('now')
     WHERE id = ?`
  ).run(
    payload.customerId ?? existing.customer_id ?? null,
    payload.receivedDate || existing.received_date,
    payload.itemDescription || existing.item_description,
    payload.issueDetails || existing.issue_details,
    payload.photoPath !== undefined ? payload.photoPath : existing.photo_path,
    advancePaid,
    payload.expectedReadyDate ?? existing.expected_ready_date ?? null,
    totalCharge,
    balanceDue,
    status,
    completedAt,
    payload.notes ?? existing.notes ?? null,
    id
  );

  // record status change in history when status changed
  if (payload.status && payload.status !== existing.status) {
    try { addStatusHistory(id, payload.status, payload.statusNote || null, payload.changedBy || null); } catch (e) { /* best-effort */ }
  }

  return getRepairById(id);
}

module.exports = { createRepair, getRepairById, listRepairs, updateRepair, listRepairPhotos, addRepairPhoto, listStatusHistory, addStatusHistory };

