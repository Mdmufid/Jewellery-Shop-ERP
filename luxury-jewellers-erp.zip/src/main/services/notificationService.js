const { shell, clipboard } = require('electron');
const invoicePdfService = require('./invoicePdfService');
const settingsService = require('./settingsService');

function normalizePhone(phone) {
  if (!phone) return null;
  const digits = String(phone).replace(/\D/g, '');
  if (digits.length === 10) return `91${digits}`; // assume India
  return digits;
}

async function sendWhatsapp(invoiceId, phone) {
  const normalized = normalizePhone(phone);
  if (!normalized) throw new Error('Invalid phone number');
  const invoice = require('./billingService').getInvoiceById(invoiceId);
  if (!invoice) throw new Error('Invoice not found');

  const pdfResult = await invoicePdfService.generateInvoicePdf(invoiceId);
  const settings = settingsService.getAllSettings();

  const message = `Invoice ${invoice.invoice_number} - Amount: Rs. ${Number(invoice.grand_total || 0).toFixed(2)}.\n` +
    `Customer: ${invoice.customer_name || 'Walk-in'}\n` +
    `Invoice Date: ${invoice.invoice_date}\n` +
    `PDF saved at: ${pdfResult.path}\n` +
    `${settings.shop_name ? `\n${settings.shop_name}` : ''}`;

  const url = `https://wa.me/${normalized}?text=${encodeURIComponent(message)}`;
  // Open WhatsApp chat with prefilled message and reveal the PDF file to allow attaching.
  shell.openExternal(url);
  try { shell.showItemInFolder(pdfResult.path); } catch (e) { /* best-effort */ }
  return { path: pdfResult.path, waUrl: url };
}

async function sendSms(invoiceId, phone) {
  const normalized = normalizePhone(phone);
  if (!normalized) throw new Error('Invalid phone number');
  const invoice = require('./billingService').getInvoiceById(invoiceId);
  if (!invoice) throw new Error('Invoice not found');

  const settings = settingsService.getAllSettings();
  const text = `Invoice ${invoice.invoice_number} - Amount: Rs. ${Number(invoice.grand_total || 0).toFixed(2)}. Thank you for your purchase.`;

  // If an SMS provider is configured in settings, integrate here. For now copy to clipboard and return instructions.
  clipboard.writeText(text);
  return { copiedToClipboard: true, message: 'Message copied to clipboard. Configure SMS provider in Settings to send directly.' };
}

module.exports = { sendWhatsapp, sendSms };
