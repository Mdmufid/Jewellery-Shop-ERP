-- ==========================================================================
-- LUXURY JEWELLERS ERP - DATABASE SCHEMA (SQLite)
-- ==========================================================================
PRAGMA foreign_keys = ON;

-- --------------------------------------------------------------------------
-- SETTINGS (shop profile, GSTIN, invoice prefix, financial year, etc.)
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);

-- --------------------------------------------------------------------------
-- USERS & ROLES
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  full_name     TEXT NOT NULL,
  role          TEXT NOT NULL CHECK(role IN ('ADMIN','MANAGER','CASHIER')),
  is_active     INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- --------------------------------------------------------------------------
-- METAL PURITY MASTER
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS purity_master (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  metal_type       TEXT NOT NULL CHECK(metal_type IN ('GOLD','SILVER','PLATINUM')),
  purity_name      TEXT NOT NULL,
  fineness_percent REAL NOT NULL,
  UNIQUE(metal_type, purity_name)
);

-- --------------------------------------------------------------------------
-- DAILY RATE MASTER (gold/silver rate per gram history)
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS rate_master (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  purity_id          INTEGER NOT NULL REFERENCES purity_master(id),
  rate_per_gram      REAL NOT NULL,
  effective_date     TEXT NOT NULL,
  effective_datetime TEXT NOT NULL DEFAULT (datetime('now')),
  created_by         INTEGER REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_rate_master_purity_date ON rate_master(purity_id, effective_date);

-- --------------------------------------------------------------------------
-- HSN / GST TAX MASTER
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS hsn_master (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  hsn_code    TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL,
  cgst_rate   REAL NOT NULL,
  sgst_rate   REAL NOT NULL,
  igst_rate   REAL NOT NULL
);

-- --------------------------------------------------------------------------
-- CATEGORIES
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
  id     INTEGER PRIMARY KEY AUTOINCREMENT,
  name   TEXT NOT NULL UNIQUE,
  hsn_id INTEGER REFERENCES hsn_master(id)
);

-- --------------------------------------------------------------------------
-- SUPPLIERS
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS suppliers (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  name            TEXT NOT NULL,
  gstin           TEXT,
  phone           TEXT,
  email           TEXT,
  address         TEXT,
  state_code      TEXT,
  opening_balance REAL NOT NULL DEFAULT 0,
  current_balance REAL NOT NULL DEFAULT 0,
  is_active       INTEGER NOT NULL DEFAULT 1,
  created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS supplier_ledger (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  supplier_id      INTEGER NOT NULL REFERENCES suppliers(id),
  transaction_type TEXT NOT NULL,
  reference_table  TEXT,
  reference_id     INTEGER,
  debit            REAL NOT NULL DEFAULT 0,
  credit           REAL NOT NULL DEFAULT 0,
  balance          REAL NOT NULL,
  notes            TEXT,
  created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

-- --------------------------------------------------------------------------
-- ARTISANS (goldsmiths / job workers) & JOB WORK
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS artisans (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  name                TEXT NOT NULL,
  phone               TEXT,
  address             TEXT,
  metal_balance       REAL NOT NULL DEFAULT 0, 
  cash_balance        REAL NOT NULL DEFAULT 0, 
  is_active           INTEGER NOT NULL DEFAULT 1,
  created_at          TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS artisan_metal_ledger (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artisan_id INTEGER NOT NULL REFERENCES artisans(id) ON DELETE CASCADE,
  transaction_type TEXT NOT NULL, 
  weight_in REAL NOT NULL DEFAULT 0,  
  weight_out REAL NOT NULL DEFAULT 0, 
  balance REAL NOT NULL DEFAULT 0,    
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS artisan_cash_ledger (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artisan_id INTEGER NOT NULL REFERENCES artisans(id) ON DELETE CASCADE,
  transaction_type TEXT NOT NULL, 
  debit REAL NOT NULL DEFAULT 0,  
  credit REAL NOT NULL DEFAULT 0, 
  balance REAL NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS artisan_jobs (
  id                      INTEGER PRIMARY KEY AUTOINCREMENT,
  job_number              TEXT NOT NULL UNIQUE,
  artisan_id              INTEGER NOT NULL REFERENCES artisans(id),
  issue_date              TEXT NOT NULL,
  metal_type              TEXT NOT NULL CHECK(metal_type IN ('GOLD','SILVER','PLATINUM')),
  purity_id               INTEGER REFERENCES purity_master(id),
  metal_issued_weight     REAL NOT NULL,
  expected_item_description TEXT,
  status                  TEXT NOT NULL DEFAULT 'ISSUED' CHECK(status IN ('ISSUED','RECEIVED','CLOSED','CANCELLED')),
  received_date           TEXT,
  received_gross_weight   REAL,
  stone_weight            REAL DEFAULT 0,
  net_metal_weight        REAL,
  wastage_weight          REAL DEFAULT 0,
  making_charge_amount    REAL DEFAULT 0,
  item_id                 INTEGER REFERENCES items(id),
  notes                   TEXT,
  created_at              TEXT NOT NULL DEFAULT (datetime('now'))
);

-- --------------------------------------------------------------------------
-- INVENTORY ITEMS
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS items (
  id                      INTEGER PRIMARY KEY AUTOINCREMENT,
  item_code               TEXT NOT NULL UNIQUE,
  name                    TEXT NOT NULL,
  category_id             INTEGER REFERENCES categories(id),
  metal_type              TEXT NOT NULL CHECK(metal_type IN ('GOLD','SILVER','PLATINUM')),
  purity_id               INTEGER NOT NULL REFERENCES purity_master(id),
  gross_weight            REAL NOT NULL,
  stone_weight            REAL NOT NULL DEFAULT 0,
  net_weight              REAL NOT NULL,
  stone_details           TEXT,
  stone_charge            REAL NOT NULL DEFAULT 0,
  making_charge_type      TEXT NOT NULL DEFAULT 'PER_GRAM' CHECK(making_charge_type IN ('PER_GRAM','FIXED','PERCENTAGE')),
  making_charge_value     REAL NOT NULL DEFAULT 0,
  wastage_percent         REAL NOT NULL DEFAULT 0,
  huid_number             TEXT,
  hallmark_certificate_no TEXT,
  purchase_id             INTEGER REFERENCES purchases(id),
  artisan_job_id          INTEGER,
  source_type             TEXT NOT NULL DEFAULT 'PURCHASE' CHECK(source_type IN ('PURCHASE','ARTISAN','OLD_GOLD_MELT','OPENING_STOCK')),
  cost_rate_per_gram      REAL,
  status                  TEXT NOT NULL DEFAULT 'IN_STOCK' CHECK(status IN ('IN_STOCK','SOLD','RETURNED','MELTED','TRANSFERRED')),
  quantity                INTEGER NOT NULL DEFAULT 1,
  location                TEXT,
  image_path              TEXT,
  certificate_path        TEXT,
  created_at              TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at              TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_items_status ON items(status);
CREATE INDEX IF NOT EXISTS idx_items_category ON items(category_id);
CREATE INDEX IF NOT EXISTS idx_items_metal_purity ON items(metal_type, purity_id);

CREATE TABLE IF NOT EXISTS stock_ledger (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id           INTEGER NOT NULL REFERENCES items(id),
  transaction_type  TEXT NOT NULL CHECK(transaction_type IN
                     ('PURCHASE_IN','SALE_OUT','SALE_RETURN_IN','ARTISAN_IN',
                      'OLD_GOLD_MELT_IN','ADJUSTMENT_IN','ADJUSTMENT_OUT',
                      'OPENING_STOCK_IN')),
  reference_table   TEXT,
  reference_id      INTEGER,
  weight_change     REAL NOT NULL,
  quantity_change   INTEGER NOT NULL DEFAULT 0,
  notes             TEXT,
  created_at        TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_stock_ledger_item ON stock_ledger(item_id);

CREATE TABLE IF NOT EXISTS stock_audits (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  audit_date    TEXT NOT NULL,
  title         TEXT NOT NULL,
  description   TEXT,
  status        TEXT NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN','COMPLETED','CANCELLED')),
  created_by    INTEGER REFERENCES users(id),
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  completed_at  TEXT
);

CREATE TABLE IF NOT EXISTS stock_audit_items (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  audit_id           INTEGER NOT NULL REFERENCES stock_audits(id) ON DELETE CASCADE,
  item_id            INTEGER NOT NULL REFERENCES items(id),
  expected_quantity  INTEGER NOT NULL DEFAULT 1,
  expected_weight    REAL NOT NULL DEFAULT 0,
  counted_quantity   INTEGER NOT NULL DEFAULT 1,
  counted_weight     REAL NOT NULL DEFAULT 0,
  variance_quantity  INTEGER NOT NULL DEFAULT 0,
  variance_weight    REAL NOT NULL DEFAULT 0,
  notes              TEXT,
  created_at         TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(audit_id, item_id)
);
CREATE INDEX IF NOT EXISTS idx_stock_audit_items_audit ON stock_audit_items(audit_id);

-- --------------------------------------------------------------------------
-- PURCHASES
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS purchases (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  purchase_number TEXT NOT NULL UNIQUE,
  supplier_id     INTEGER NOT NULL REFERENCES suppliers(id),
  purchase_date   TEXT NOT NULL,
  invoice_number  TEXT,
  subtotal        REAL NOT NULL DEFAULT 0,
  cgst_amount     REAL NOT NULL DEFAULT 0,
  sgst_amount     REAL NOT NULL DEFAULT 0,
  igst_amount     REAL NOT NULL DEFAULT 0,
  total_amount    REAL NOT NULL DEFAULT 0,
  payment_status  TEXT NOT NULL DEFAULT 'UNPAID' CHECK(payment_status IN ('UNPAID','PARTIAL','PAID')),
  amount_paid     REAL NOT NULL DEFAULT 0,
  notes           TEXT,
  created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS purchase_items (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  purchase_id    INTEGER NOT NULL REFERENCES purchases(id),
  description    TEXT NOT NULL,
  metal_type     TEXT NOT NULL,
  purity_id      INTEGER REFERENCES purity_master(id),
  gross_weight   REAL NOT NULL,
  stone_weight   REAL NOT NULL DEFAULT 0,
  net_weight     REAL NOT NULL,
  rate_per_gram  REAL NOT NULL,
  making_charge  REAL NOT NULL DEFAULT 0,
  amount         REAL NOT NULL,
  hsn_id         INTEGER REFERENCES hsn_master(id),
  item_id        INTEGER REFERENCES items(id)
);

-- --------------------------------------------------------------------------
-- CUSTOMERS
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS customers (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  name             TEXT NOT NULL,
  phone            TEXT UNIQUE,
  email            TEXT,
  gstin            TEXT,
  address          TEXT,
  city             TEXT,
  state_code       TEXT NOT NULL DEFAULT '27',
  pan_number       TEXT,
  loyalty_points   REAL NOT NULL DEFAULT 0,
  opening_balance  REAL NOT NULL DEFAULT 0,
  current_balance  REAL NOT NULL DEFAULT 0,
  date_of_birth    TEXT,
  anniversary_date TEXT,
  photo_path       TEXT,
  secondary_phone  TEXT,
  address2         TEXT,
  zip_code         TEXT,
  preferred_contact TEXT,
  loyalty_tier     TEXT,
  communication_sms INTEGER NOT NULL DEFAULT 1,
  communication_whatsapp INTEGER NOT NULL DEFAULT 1,
  kyc_doc_path     TEXT,
  is_active        INTEGER NOT NULL DEFAULT 1,
  created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(phone);

CREATE TABLE IF NOT EXISTS customer_ledger (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id      INTEGER NOT NULL REFERENCES customers(id),
  transaction_type TEXT NOT NULL,
  reference_table  TEXT,
  reference_id     INTEGER,
  debit            REAL NOT NULL DEFAULT 0,
  credit           REAL NOT NULL DEFAULT 0,
  balance          REAL NOT NULL,
  notes            TEXT,
  created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_customer_ledger_customer ON customer_ledger(customer_id);

-- --------------------------------------------------------------------------
-- SCHEMES / LOYALTY (installment gold savings schemes)
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS schemes (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  scheme_name         TEXT NOT NULL,
  duration_months     INTEGER NOT NULL,
  installment_amount  REAL NOT NULL,
  bonus_percent       REAL NOT NULL DEFAULT 0,
  description         TEXT,
  is_active           INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS scheme_enrollments (
  id                     INTEGER PRIMARY KEY AUTOINCREMENT,
  scheme_id              INTEGER NOT NULL REFERENCES schemes(id),
  customer_id            INTEGER NOT NULL REFERENCES customers(id),
  enrollment_number      TEXT NOT NULL UNIQUE,
  start_date             TEXT NOT NULL,
  status                 TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','MATURED','CLOSED','DEFAULTED')),
  total_paid             REAL NOT NULL DEFAULT 0,
  installments_paid      INTEGER NOT NULL DEFAULT 0,
  maturity_value         REAL,
  redeemed_in_invoice_id INTEGER,
  created_at             TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS scheme_payments (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  enrollment_id      INTEGER NOT NULL REFERENCES scheme_enrollments(id),
  installment_number INTEGER NOT NULL,
  amount             REAL NOT NULL,
  payment_date       TEXT NOT NULL,
  payment_mode       TEXT NOT NULL,
  receipt_number     TEXT NOT NULL UNIQUE
);

-- --------------------------------------------------------------------------
-- OLD GOLD EXCHANGE (buy-back / trade-in)
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS old_gold_exchanges (
  id                     INTEGER PRIMARY KEY AUTOINCREMENT,
  exchange_number        TEXT NOT NULL UNIQUE,
  customer_id            INTEGER REFERENCES customers(id),
  exchange_date          TEXT NOT NULL,
  metal_type             TEXT NOT NULL CHECK(metal_type IN ('GOLD','SILVER','PLATINUM')),
  gross_weight           REAL NOT NULL,
  stone_weight           REAL NOT NULL DEFAULT 0,
  net_weight             REAL NOT NULL,
  purity_tested_percent  REAL NOT NULL,
  deduction_percent      REAL NOT NULL DEFAULT 0,
  effective_fine_weight  REAL NOT NULL,
  rate_per_gram          REAL NOT NULL,
  total_value            REAL NOT NULL,
  status                 TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','ADJUSTED_IN_INVOICE','MELTED','SETTLED_CASH')),
  invoice_id             INTEGER,
  notes                  TEXT,
  created_at             TEXT NOT NULL DEFAULT (datetime('now'))
);

-- --------------------------------------------------------------------------
-- REPAIRS / JOB CARDS
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS repairs (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  repair_number       TEXT NOT NULL UNIQUE,
  customer_id         INTEGER REFERENCES customers(id),
  received_date       TEXT NOT NULL,
  item_description    TEXT NOT NULL,
  issue_details       TEXT NOT NULL,
  photo_path          TEXT,
  advance_paid        REAL NOT NULL DEFAULT 0,
  expected_ready_date TEXT,
  total_charge        REAL NOT NULL DEFAULT 0,
  balance_due         REAL NOT NULL DEFAULT 0,
  status              TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','READY','DELIVERED','CANCELLED')),
  completed_at        TEXT,
  notes               TEXT,
  created_at          TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at          TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_repairs_status ON repairs(status);
CREATE INDEX IF NOT EXISTS idx_repairs_customer ON repairs(customer_id);

-- --------------------------------------------------------------------------
-- REPAIR PHOTOS (multiple photos per repair for before/after)
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS repair_photos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  repair_id INTEGER NOT NULL REFERENCES repairs(id) ON DELETE CASCADE,
  file_path TEXT NOT NULL,
  caption TEXT,
  taken_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_repair_photos_repair ON repair_photos(repair_id);

-- --------------------------------------------------------------------------
-- REPAIR STATUS HISTORY (timeline of status changes)
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS repair_status_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  repair_id INTEGER NOT NULL REFERENCES repairs(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  note TEXT,
  changed_by INTEGER REFERENCES users(id),
  changed_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_repair_status_history_repair ON repair_status_history(repair_id);

-- --------------------------------------------------------------------------
-- SALES INVOICES
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS invoices (
  id                      INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_number          TEXT NOT NULL UNIQUE,
  invoice_date            TEXT NOT NULL,
  customer_id             INTEGER REFERENCES customers(id),
  place_of_supply_state_code TEXT NOT NULL,
  is_interstate           INTEGER NOT NULL DEFAULT 0,
  subtotal                REAL NOT NULL DEFAULT 0,
  total_making_charges    REAL NOT NULL DEFAULT 0,
  total_stone_charges     REAL NOT NULL DEFAULT 0,
  taxable_amount          REAL NOT NULL DEFAULT 0,
  cgst_amount             REAL NOT NULL DEFAULT 0,
  sgst_amount             REAL NOT NULL DEFAULT 0,
  igst_amount             REAL NOT NULL DEFAULT 0,
  round_off               REAL NOT NULL DEFAULT 0,
  old_gold_exchange_value REAL NOT NULL DEFAULT 0,
  scheme_redemption_value REAL NOT NULL DEFAULT 0,
  discount_amount         REAL NOT NULL DEFAULT 0,
  grand_total             REAL NOT NULL DEFAULT 0,
  amount_paid             REAL NOT NULL DEFAULT 0,
  balance_due             REAL NOT NULL DEFAULT 0,
  status                  TEXT NOT NULL DEFAULT 'COMPLETED' CHECK(status IN ('COMPLETED','CANCELLED','RETURNED')),
  created_by              INTEGER REFERENCES users(id),
  created_at              TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_invoices_date ON invoices(invoice_date);
CREATE INDEX IF NOT EXISTS idx_invoices_customer ON invoices(customer_id);

CREATE TABLE IF NOT EXISTS invoice_items (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_id     INTEGER NOT NULL REFERENCES invoices(id),
  item_id        INTEGER REFERENCES items(id),
  description    TEXT NOT NULL,
  hsn_code       TEXT,
  metal_type     TEXT NOT NULL,
  purity_name    TEXT NOT NULL,
  gross_weight   REAL NOT NULL,
  stone_weight   REAL NOT NULL DEFAULT 0,
  net_weight     REAL NOT NULL,
  rate_per_gram  REAL NOT NULL,
  metal_value    REAL NOT NULL,
  making_charge  REAL NOT NULL DEFAULT 0,
  stone_charge   REAL NOT NULL DEFAULT 0,
  taxable_value  REAL NOT NULL,
  cgst_rate      REAL NOT NULL DEFAULT 0,
  sgst_rate      REAL NOT NULL DEFAULT 0,
  igst_rate      REAL NOT NULL DEFAULT 0,
  cgst_amount    REAL NOT NULL DEFAULT 0,
  sgst_amount    REAL NOT NULL DEFAULT 0,
  igst_amount    REAL NOT NULL DEFAULT 0,
  line_total     REAL NOT NULL,
  huid_number    TEXT
);
CREATE INDEX IF NOT EXISTS idx_invoice_items_invoice ON invoice_items(invoice_id);

CREATE TABLE IF NOT EXISTS invoice_payments (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_id       INTEGER NOT NULL REFERENCES invoices(id),
  amount           REAL NOT NULL,
  payment_mode     TEXT NOT NULL CHECK(payment_mode IN ('CASH','CARD','UPI','BANK_TRANSFER','CHEQUE','OLD_GOLD','SCHEME')),
  reference_number TEXT,
  payment_date     TEXT NOT NULL DEFAULT (datetime('now'))
);

-- --------------------------------------------------------------------------
-- NUMBER SEQUENCES (invoice / purchase / job / exchange numbering)
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS number_sequences (
  seq_name       TEXT PRIMARY KEY,
  prefix         TEXT NOT NULL,
  current_number INTEGER NOT NULL DEFAULT 0,
  financial_year TEXT
);

-- --------------------------------------------------------------------------
-- AUDIT LOG
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER REFERENCES users(id),
  action     TEXT NOT NULL,
  entity     TEXT NOT NULL,
  entity_id  INTEGER,
  details    TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);