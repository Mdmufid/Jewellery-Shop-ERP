const path = require('path');
const fs = require('fs');
const { app } = require('electron');
const Database = require('better-sqlite3');
const log = require('electron-log');

let db = null;

function getDbPath() {
  const userDataPath = app.getPath('userData');
  const dbDir = path.join(userDataPath, 'data');
  if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
  return path.join(dbDir, 'luxury_jewellers.db');
}

function runSchema(database) {
  // In packaged app the schema.sql ships as an extraResource; in dev it lives next to this file.
  const packagedSchemaPath = path.join(process.resourcesPath || '', 'schema.sql');
  const devSchemaPath = path.join(__dirname, 'schema.sql');
  const schemaPath = fs.existsSync(packagedSchemaPath) ? packagedSchemaPath : devSchemaPath;
  const schema = fs.readFileSync(schemaPath, 'utf-8');
  database.exec(schema);
}

function ensureItemFileColumns(database) {
  const columns = database.prepare('PRAGMA table_info(items)').all();
  const columnNames = new Set(columns.map((column) => column.name));
  if (!columnNames.has('certificate_path')) {
    database.prepare('ALTER TABLE items ADD COLUMN certificate_path TEXT').run();
  }
}

function ensureCustomerColumns(database) {
  const columns = database.prepare('PRAGMA table_info(customers)').all();
  const columnNames = new Set(columns.map((c) => c.name));
  const alters = [];
  if (!columnNames.has('photo_path')) alters.push("ALTER TABLE customers ADD COLUMN photo_path TEXT");
  if (!columnNames.has('secondary_phone')) alters.push("ALTER TABLE customers ADD COLUMN secondary_phone TEXT");
  if (!columnNames.has('address2')) alters.push("ALTER TABLE customers ADD COLUMN address2 TEXT");
  if (!columnNames.has('zip_code')) alters.push("ALTER TABLE customers ADD COLUMN zip_code TEXT");
  if (!columnNames.has('preferred_contact')) alters.push("ALTER TABLE customers ADD COLUMN preferred_contact TEXT");
  if (!columnNames.has('loyalty_tier')) alters.push("ALTER TABLE customers ADD COLUMN loyalty_tier TEXT");
  if (!columnNames.has('communication_sms')) alters.push("ALTER TABLE customers ADD COLUMN communication_sms INTEGER NOT NULL DEFAULT 1");
  if (!columnNames.has('communication_whatsapp')) alters.push("ALTER TABLE customers ADD COLUMN communication_whatsapp INTEGER NOT NULL DEFAULT 1");
  if (!columnNames.has('kyc_doc_path')) alters.push("ALTER TABLE customers ADD COLUMN kyc_doc_path TEXT");
  for (const sql of alters) {
    try { database.prepare(sql).run(); } catch (err) { /* ignore if cannot alter for some reason */ }
  }
}

function ensureRepairTables(database) {
  // create repair_photos and repair_status_history if they don't exist
  const photosExists = database.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='repair_photos'").get();
  if (!photosExists) {
    database.prepare(`CREATE TABLE IF NOT EXISTS repair_photos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      repair_id INTEGER NOT NULL REFERENCES repairs(id) ON DELETE CASCADE,
      file_path TEXT NOT NULL,
      caption TEXT,
      taken_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`).run();
    database.prepare('CREATE INDEX IF NOT EXISTS idx_repair_photos_repair ON repair_photos(repair_id)').run();
  }
  const histExists = database.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='repair_status_history'").get();
  if (!histExists) {
    database.prepare(`CREATE TABLE IF NOT EXISTS repair_status_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      repair_id INTEGER NOT NULL REFERENCES repairs(id) ON DELETE CASCADE,
      status TEXT NOT NULL,
      note TEXT,
      changed_by INTEGER REFERENCES users(id),
      changed_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`).run();
    database.prepare('CREATE INDEX IF NOT EXISTS idx_repair_status_history_repair ON repair_status_history(repair_id)').run();
  }
}

function ensureStockAuditTables(database) {
  const auditsExists = database.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='stock_audits'").get();
  if (!auditsExists) {
    database.prepare(`CREATE TABLE IF NOT EXISTS stock_audits (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      audit_date TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      status TEXT NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN','COMPLETED','CANCELLED')),
      created_by INTEGER REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      completed_at TEXT
    )`).run();
  }
  const auditItemsExists = database.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='stock_audit_items'").get();
  if (!auditItemsExists) {
    database.prepare(`CREATE TABLE IF NOT EXISTS stock_audit_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      audit_id INTEGER NOT NULL REFERENCES stock_audits(id) ON DELETE CASCADE,
      item_id INTEGER NOT NULL REFERENCES items(id),
      expected_quantity INTEGER NOT NULL DEFAULT 1,
      expected_weight REAL NOT NULL DEFAULT 0,
      counted_quantity INTEGER NOT NULL DEFAULT 1,
      counted_weight REAL NOT NULL DEFAULT 0,
      variance_quantity INTEGER NOT NULL DEFAULT 0,
      variance_weight REAL NOT NULL DEFAULT 0,
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(audit_id, item_id)
    )`).run();
    database.prepare('CREATE INDEX IF NOT EXISTS idx_stock_audit_items_audit ON stock_audit_items(audit_id)').run();
  }
}

function seedIfEmpty(database) {
  const fy = currentFinancialYear();

  const purityCount = database.prepare('SELECT COUNT(*) AS c FROM purity_master').get().c;
  if (purityCount === 0) {
    const insertPurity = database.prepare(
      'INSERT INTO purity_master (metal_type, purity_name, fineness_percent) VALUES (?, ?, ?)'
    );
    const purities = [
      ['GOLD', '24K (999)', 99.9],
      ['GOLD', '22K (916)', 91.6],
      ['GOLD', '20K (833)', 83.3],
      ['GOLD', '18K (750)', 75.0],
      ['GOLD', '14K (585)', 58.5],
      ['SILVER', '999 Fine Silver', 99.9],
      ['SILVER', '925 Sterling Silver', 92.5],
      ['PLATINUM', '950 Platinum', 95.0],
    ];
    const tx = database.transaction((rows) => {
      for (const row of rows) insertPurity.run(...row);
    });
    tx(purities);
  }

  const hsnCount = database.prepare('SELECT COUNT(*) AS c FROM hsn_master').get().c;
  if (hsnCount === 0) {
    // Official CBIC HSN codes applicable to jewellery trade (GST rates as per
    // Schedule I & Schedule II of CGST Rate Notifications: 1.5% CGST + 1.5% SGST
    // on gold/silver/platinum jewellery articles (HSN 7113), 0.125% CGST + 0.125%
    // SGST on unworked/semi-worked precious metal (HSN 7108/7106), and 1.5%+1.5%
    // on imitation/other articles is NOT applicable here (that attracts standard
    // rates) - shop should verify current notification rates in Settings.
    const insertHsn = database.prepare(
      'INSERT INTO hsn_master (hsn_code, description, cgst_rate, sgst_rate, igst_rate) VALUES (?, ?, ?, ?, ?)'
    );
    const rows = [
      ['7113', 'Articles of jewellery of precious metal (gold/silver/platinum)', 1.5, 1.5, 3.0],
      ['7108', 'Gold (unwrought or in semi-manufactured forms)', 0.125, 0.125, 0.25],
      ['7106', 'Silver (unwrought or in semi-manufactured forms)', 1.5, 1.5, 3.0],
      ['7118', 'Coins of precious metal', 1.5, 1.5, 3.0],
      ['9988', 'Job work services - jewellery making (making charges)', 2.5, 2.5, 5.0],
    ];
    const tx = database.transaction((rs) => { for (const r of rs) insertHsn.run(...r); });
    tx(rows);
  }

  const categoryCount = database.prepare('SELECT COUNT(*) AS c FROM categories').get().c;
  if (categoryCount === 0) {
    const jewelleryHsn = database.prepare("SELECT id FROM hsn_master WHERE hsn_code = '7113'").get();
    const insertCat = database.prepare('INSERT INTO categories (name, hsn_id) VALUES (?, ?)');
    const cats = ['Ring', 'Necklace', 'Bangle', 'Bracelet', 'Chain', 'Earring',
      'Pendant', 'Mangalsutra', 'Nose Pin', 'Anklet (Payal)', 'Coin/Bar', 'Other'];
    const tx = database.transaction((names) => {
      for (const n of names) insertCat.run(n, jewelleryHsn ? jewelleryHsn.id : null);
    });
    tx(cats);
  }

  const seqCount = database.prepare('SELECT COUNT(*) AS c FROM number_sequences').get().c;
  if (seqCount === 0) {
    const insertSeq = database.prepare(
      'INSERT INTO number_sequences (seq_name, prefix, current_number, financial_year) VALUES (?, ?, 0, ?)'
    );
    const tx = database.transaction(() => {
      insertSeq.run('INVOICE', 'INV', fy);
      insertSeq.run('PURCHASE', 'PUR', fy);
      insertSeq.run('ARTISAN_JOB', 'JOB', fy);
      insertSeq.run('OLD_GOLD', 'OGE', fy);
      insertSeq.run('REPAIR', 'RPR', fy);
      insertSeq.run('SCHEME_ENROLL', 'SCH', fy);
      insertSeq.run('SCHEME_RECEIPT', 'RCT', fy);
    });
    tx();
  } else {
    const ensureSeq = database.prepare(
      'INSERT OR IGNORE INTO number_sequences (seq_name, prefix, current_number, financial_year) VALUES (?, ?, 0, ?)'
    );
    ensureSeq.run('REPAIR', 'RPR', fy);
  }

  const settingsCount = database.prepare('SELECT COUNT(*) AS c FROM settings').get().c;
  if (settingsCount === 0) {
    const insertSetting = database.prepare('INSERT INTO settings (key, value) VALUES (?, ?)');
    const tx = database.transaction(() => {
      insertSetting.run('shop_name', 'Luxury Jewellers');
      insertSetting.run('shop_address', '');
      insertSetting.run('shop_phone', '');
      insertSetting.run('shop_email', '');
      insertSetting.run('shop_gstin', '');
      insertSetting.run('shop_state_code', '27');
      insertSetting.run('shop_pan', '');
      insertSetting.run('invoice_terms', 'Goods once sold will only be exchanged as per store policy. Making charges and wastage are non-refundable.');
      insertSetting.run('round_off_enabled', '1');
      insertSetting.run('last_backup_at', '');
    });
    tx();
  }

  const userCount = database.prepare('SELECT COUNT(*) AS c FROM users').get().c;
  if (userCount === 0) {
    const bcrypt = require('bcryptjs');
    const hash = bcrypt.hashSync('admin123', 10);
    database.prepare(
      'INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)'
    ).run('admin', hash, 'Administrator', 'ADMIN');
  }
}

function currentFinancialYear() {
  const now = new Date();
  const y = now.getFullYear();
  const m = now.getMonth() + 1; // 1-12
  // Indian FY: Apr-Mar
  if (m >= 4) return `${y}-${String(y + 1).slice(2)}`;
  return `${y - 1}-${String(y).slice(2)}`;
}

function initDatabase() {
  if (db) return db;
  const dbPath = getDbPath();
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  runSchema(db);
  ensureItemFileColumns(db);
  ensureCustomerColumns(db);
  ensureRepairTables(db);
  ensureStockAuditTables(db);
  seedIfEmpty(db);
  log.info(`Database initialized at ${dbPath}`);
  return db;
}

function getDb() {
  if (!db) return initDatabase();
  return db;
}

module.exports = { initDatabase, getDb, getDbPath, currentFinancialYear };
