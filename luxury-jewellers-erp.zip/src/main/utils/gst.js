/**
 * GST calculation utilities.
 *
 * Indian GST rule for intra-state supply: CGST + SGST (each half of the total rate).
 * For inter-state supply: IGST (full rate) is charged instead.
 * Place of supply is determined by comparing the shop's registered state code
 * with the customer's state code (for B2B/B2C with address) or defaulting to
 * intra-state for walk-in retail customers.
 */

function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

/**
 * @param {number} taxableValue - value on which tax is computed
 * @param {object} rates - { cgst_rate, sgst_rate, igst_rate } as percentages
 * @param {boolean} isInterstate
 */
function computeTax(taxableValue, rates, isInterstate) {
  if (isInterstate) {
    const igstAmount = round2((taxableValue * rates.igst_rate) / 100);
    return { cgstAmount: 0, sgstAmount: 0, igstAmount, cgstRate: 0, sgstRate: 0, igstRate: rates.igst_rate };
  }
  const cgstAmount = round2((taxableValue * rates.cgst_rate) / 100);
  const sgstAmount = round2((taxableValue * rates.sgst_rate) / 100);
  return { cgstAmount, sgstAmount, igstAmount: 0, cgstRate: rates.cgst_rate, sgstRate: rates.sgst_rate, igstRate: 0 };
}

/**
 * Rounds the final invoice total to the nearest rupee and returns the
 * round-off adjustment (can be positive or negative), per standard Indian
 * retail invoicing practice.
 */
function roundOffTotal(amount) {
  const rounded = Math.round(amount);
  const roundOff = round2(rounded - amount);
  return { rounded, roundOff };
}

function isInterstateSupply(shopStateCode, customerStateCode) {
  if (!customerStateCode) return false; // walk-in customer without state -> treat as intra-state
  return String(shopStateCode) !== String(customerStateCode);
}

module.exports = { computeTax, roundOffTotal, isInterstateSupply, round2 };
