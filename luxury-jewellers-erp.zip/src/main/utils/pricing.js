const { round2 } = require('./gst');

/**
 * Computes the making charge amount for an item given its type.
 * - PER_GRAM: making_charge_value is Rs. per gram of net weight
 * - FIXED: making_charge_value is a flat Rs. amount
 * - PERCENTAGE: making_charge_value is a % of the metal value
 */
function computeMakingCharge({ makingChargeType, makingChargeValue, netWeight, metalValue }) {
  switch (makingChargeType) {
    case 'PER_GRAM':
      return round2(netWeight * makingChargeValue);
    case 'FIXED':
      return round2(makingChargeValue);
    case 'PERCENTAGE':
      return round2((metalValue * makingChargeValue) / 100);
    default:
      throw new Error(`Unknown making charge type: ${makingChargeType}`);
  }
}

/**
 * Computes wastage charge: an additional weight (in grams, expressed as a
 * percentage of net weight) billed at the metal rate to account for
 * manufacturing loss. Common in Indian jewellery retail as "wastage %".
 */
function computeWastageAmount({ netWeight, wastagePercent, ratePerGram }) {
  const wastageWeight = round2((netWeight * wastagePercent) / 100);
  return round2(wastageWeight * ratePerGram);
}

/**
 * Full pricing breakdown for one billable line (used by both the Inventory
 * "estimated selling price" preview and the live Billing screen).
 */
function priceItem({ netWeight, ratePerGram, makingChargeType, makingChargeValue, wastagePercent, stoneCharge }) {
  const metalValue = round2(netWeight * ratePerGram);
  const makingCharge = computeMakingCharge({ makingChargeType, makingChargeValue, netWeight, metalValue });
  const wastageAmount = computeWastageAmount({ netWeight, wastagePercent: wastagePercent || 0, ratePerGram });
  const stone = round2(stoneCharge || 0);
  const taxableValue = round2(metalValue + makingCharge + wastageAmount + stone);
  return { metalValue, makingCharge, wastageAmount, stoneCharge: stone, taxableValue };
}

module.exports = { computeMakingCharge, computeWastageAmount, priceItem };
