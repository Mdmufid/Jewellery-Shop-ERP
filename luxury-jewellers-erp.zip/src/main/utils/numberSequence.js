const { getDb, currentFinancialYear } = require('../database/db');

/**
 * Atomically generates the next formatted document number for a sequence,
 * e.g. INV/2526/00001. Resets the counter automatically when the Indian
 * financial year (Apr-Mar) rolls over.
 */
function nextNumber(seqName) {
  const db = getDb();
  const fy = currentFinancialYear();

  const tx = db.transaction(() => {
    const row = db.prepare('SELECT * FROM number_sequences WHERE seq_name = ?').get(seqName);
    if (!row) {
      throw new Error(`Unknown number sequence: ${seqName}`);
    }
    let currentNumber = row.current_number;
    let financialYear = row.financial_year;
    if (financialYear !== fy) {
      // New financial year started - reset counter
      financialYear = fy;
      currentNumber = 0;
    }
    currentNumber += 1;
    db.prepare(
      'UPDATE number_sequences SET current_number = ?, financial_year = ? WHERE seq_name = ?'
    ).run(currentNumber, financialYear, seqName);

    const fyTag = fy.replace('-', '');
    const padded = String(currentNumber).padStart(5, '0');
    return `${row.prefix}/${fyTag}/${padded}`;
  });

  return tx();
}

module.exports = { nextNumber };
