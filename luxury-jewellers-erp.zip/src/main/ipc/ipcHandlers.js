const { ipcMain, shell } = require('electron');
const { getDb } = require('../database/db');
const log = require('electron-log');
const axios = require('axios');
const cheerio = require('cheerio');

const authService = require('../services/authService');
const settingsService = require('../services/settingsService');
const rateService = require('../services/rateService');
const inventoryService = require('../services/inventoryService');
const customerService = require('../services/customerService');
const supplierService = require('../services/supplierService');
const purchaseService = require('../services/purchaseService');
const artisanService = require('../services/artisanService');
const oldGoldService = require('../services/oldGoldService');
const repairService = require('../services/repairService');
const billingService = require('../services/billingService');
const reportService = require('../services/reportService');
const backupService = require('../services/backupService');
const invoicePdfService = require('../services/invoicePdfService');
const notificationService = require('../services/notificationService');
const auditPdfService = require('../services/auditPdfService');



/** Wraps a handler so any thrown Error becomes a clean { message } the renderer can display. */
function safe(fn) {
  return async (event, ...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (err) {
      log.error(err);
      return { ok: false, error: err.message || 'Unexpected error' };
    }
  };
}

function registerIpcHandlers(mainWindow) {
  // Auth
  ipcMain.handle('auth:login', safe((u, p) => authService.login(u, p)));
  ipcMain.handle('auth:listUsers', safe(() => authService.listUsers()));
  ipcMain.handle('auth:createUser', safe((payload) => authService.createUser(payload)));
  ipcMain.handle('auth:changePassword', safe((userId, oldPw, newPw) => authService.changePassword(userId, oldPw, newPw)));
  ipcMain.handle('auth:resetPassword', safe((adminId, targetId, newPw) => authService.resetPassword(adminId, targetId, newPw)));
  ipcMain.handle('auth:setUserActive', safe((userId, active) => authService.setUserActive(userId, active)));

  // Settings
  ipcMain.handle('settings:getAll', safe(() => settingsService.getAllSettings()));
  ipcMain.handle('settings:update', safe((patch) => settingsService.updateSettings(patch)));
  ipcMain.handle('settings:listCategories', safe(() => settingsService.listCategories()));
  ipcMain.handle('settings:createCategory', safe((payload) => settingsService.createCategory(payload)));
  ipcMain.handle('settings:listHsnCodes', safe(() => settingsService.listHsnCodes()));
  ipcMain.handle('settings:updateHsnRate', safe((id, payload) => settingsService.updateHsnRate(id, payload)));

// Rates
  ipcMain.handle('rates:listPurities', safe(() => rateService.listPurities()));
  ipcMain.handle('rates:getCurrent', safe((asOfDate) => rateService.getCurrentRates(asOfDate)));
  ipcMain.handle('rates:set', safe((payload) => rateService.setRate(payload)));
  ipcMain.handle('rates:history', safe((purityId, limit) => rateService.getRateHistory(purityId, limit)));
  
  // 🚀 THE SMART SCRAPER WITH WEEKEND FALLBACK
  ipcMain.handle('rates:fetchIBJA', safe(async () => {
    try {
      console.log("Fetching live rates from IBJA website...");
      
      const axios = require('axios');
      const cheerio = require('cheerio');

      const response = await axios.get('https://ibjarates.com/', {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Cache-Control': 'no-cache'
        },
        timeout: 10000
      });
      
      const $ = cheerio.load(response.data);
      let scrapedData = {};

      // ==========================================================
      // STRATEGY 1: Try the Left Side "Live" Table (Weekdays)
      // ==========================================================
      $('tr').each((i, el) => {
        const firstCol = $(el).find('td').eq(0).text().trim().toLowerCase();
        const amCol = $(el).find('td').eq(1).text().trim();
        const pmCol = $(el).find('td').eq(2).text().trim();
        
        // Use PM rate if available, otherwise fallback to AM rate
        const rate = (pmCol && pmCol !== '-' && pmCol !== '') ? pmCol : amCol;

        if (firstCol === 'gold 999') scrapedData.gold_999 = rate;
        if (firstCol === 'gold 995') scrapedData.gold_995 = rate;
        if (firstCol === 'gold 916') scrapedData.gold_916 = rate;
        if (firstCol === 'gold 750') scrapedData.gold_750 = rate;
        if (firstCol === 'gold 585') scrapedData.gold_585 = rate;
        if (firstCol === 'silver 999') scrapedData.silver_999 = rate;
      });

      // Validate Strategy 1
      if (scrapedData.gold_916 && scrapedData.gold_916.length > 0) {
        console.log("Success: Parsed LIVE rates from the left table.");
        return scrapedData;
      }

      // ==========================================================
      // STRATEGY 2: Fallback to Right Side "History" Table (Weekends)
      // ==========================================================
      console.log("Live rates missing (weekend/holiday). Falling back to historical table...");
      const firstHistRow = $('#tab-am tbody tr').first();
      
      if (firstHistRow.length > 0) {
        scrapedData = {
          date: firstHistRow.find('td').eq(0).text().trim(),
          // The history table format is: Date | 999 | 995 | 916 | 750 | 585 | Silver | Platinum
          gold_999: firstHistRow.find('td').eq(1).text().trim(),
          gold_995: firstHistRow.find('td').eq(2).text().trim(),
          gold_916: firstHistRow.find('td').eq(3).text().trim(),
          gold_750: firstHistRow.find('td').eq(4).text().trim(),
          gold_585: firstHistRow.find('td').eq(5).text().trim(),
          silver_999: firstHistRow.find('td').eq(6).text().trim()
        };

        if (scrapedData.gold_916) {
          console.log("Success: Parsed FALLBACK historical rates:", scrapedData);
          return scrapedData;
        }
      }

      throw new Error("Could not extract the prices from either table layout.");
    } catch (error) {
      console.error("Scraper Error Details:", error.message);
      throw error;
    }
  }));
  
  // Inventory
  ipcMain.handle('inventory:create', safe((payload) => inventoryService.createItem(payload)));
  ipcMain.handle('inventory:update', safe((id, payload) => inventoryService.updateItem(id, payload)));
  ipcMain.handle('inventory:getById', safe((id) => inventoryService.getItemById(id)));
  ipcMain.handle('inventory:getByCode', safe((code) => inventoryService.getItemByCode(code)));
  ipcMain.handle('inventory:list', safe((filters) => inventoryService.listItems(filters)));
  ipcMain.handle('inventory:delete', safe((id) => inventoryService.deleteItem(id)));
  ipcMain.handle('inventory:ledger', safe((itemId) => inventoryService.getStockLedgerForItem(itemId)));
  ipcMain.handle('inventory:valuation', safe(() => inventoryService.getStockValuation()));
  ipcMain.handle('inventory:createAudit', safe((payload) => inventoryService.createStockAudit(payload)));
  ipcMain.handle('inventory:getAudit', safe((id) => inventoryService.getStockAuditById(id)));
  ipcMain.handle('inventory:listAudits', safe(() => inventoryService.listStockAudits()));
  ipcMain.handle('inventory:saveAuditItems', safe((auditId, rows) => inventoryService.saveStockAuditItems(auditId, rows)));
  ipcMain.handle('inventory:completeAudit', safe((auditId) => inventoryService.completeStockAudit(auditId)));
  ipcMain.handle('inventory:printAudit', safe(async (auditId) => {
    const result = await auditPdfService.generateAuditPdf(auditId);
    shell.openPath(result.path);
    return result;
  }));

  // Customers
  ipcMain.handle('customers:create', safe((payload) => customerService.createCustomer(payload)));
  ipcMain.handle('customers:update', safe((id, payload) => customerService.updateCustomer(id, payload)));
  ipcMain.handle('customers:getById', safe((id) => customerService.getCustomerById(id)));
  ipcMain.handle('customers:list', safe((search) => customerService.listCustomers(search)));
  ipcMain.handle('customers:ledger', safe((id) => customerService.getCustomerLedger(id)));
  ipcMain.handle('customers:receivePayment', safe((paymentData) => {
    const db = getDb();
    const { 
      customerId, 
      invoiceId, 
      amount, 
      paymentMode, 
      referenceNumber, 
      notes 
    } = paymentData;

    // Wrap the entire payment process in a single atomic transaction
    const processPayment = db.transaction(() => {
      // 1. Fetch the current customer balance
      const customer = db.prepare('SELECT current_balance FROM customers WHERE id = ?').get(customerId);
      if (!customer) throw new Error('Customer not found.');

      // Subtract the payment amount to reduce their debt
      const newCustomerBalance = customer.current_balance - amount;

      // 2. Update the customer's total outstanding balance
      db.prepare('UPDATE customers SET current_balance = ? WHERE id = ?')
        .run(newCustomerBalance, customerId);

      // 3. Insert the payment record into the customer_ledger
      db.prepare(`
        INSERT INTO customer_ledger 
        (customer_id, transaction_type, reference_table, reference_id, debit, credit, balance, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        customerId, 
        'PAYMENT_RECEIVED', 
        invoiceId ? 'invoices' : null, 
        invoiceId || null, 
        0, // Debit
        amount, // Credit
        newCustomerBalance, 
        notes || 'Settlement of due amount'
      );

      // 4. If this payment is tied to a specific invoice, update invoice totals
      if (invoiceId) {
        const invoice = db.prepare('SELECT balance_due, amount_paid FROM invoices WHERE id = ?').get(invoiceId);
        if (invoice) {
          const newBalanceDue = invoice.balance_due - amount;
          const newAmountPaid = invoice.amount_paid + amount;

          db.prepare('UPDATE invoices SET amount_paid = ?, balance_due = ? WHERE id = ?')
            .run(newAmountPaid, newBalanceDue, invoiceId);

          db.prepare(`
            INSERT INTO invoice_payments 
            (invoice_id, amount, payment_mode, reference_number) 
            VALUES (?, ?, ?, ?)
          `).run(invoiceId, amount, paymentMode, referenceNumber || null);
        }
      }
    });

    processPayment();
    
    return { success: true, message: 'Payment successfully recorded and ledger updated.' };
  }));

  ipcMain.handle('customers:printReceipt', safe(async (receiptData) => {
    const { BrowserWindow } = require('electron');
    const db = getDb();
    
    // Fetch your store details dynamically from your settings table
    const shopName = db.prepare("SELECT value FROM settings WHERE key = 'shop_name'").get()?.value || 'Luxury Jewellers';
    const shopAddress = db.prepare("SELECT value FROM settings WHERE key = 'shop_address'").get()?.value || '';
    const shopPhone = db.prepare("SELECT value FROM settings WHERE key = 'shop_phone'").get()?.value || '';

    // Build the HTML receipt template
    const html = `
      <html>
        <head>
          <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; padding: 20px; color: #000; }
            .header { text-align: center; border-bottom: 2px solid #ccc; padding-bottom: 15px; margin-bottom: 20px; }
            .title { font-size: 26px; font-weight: bold; margin: 0; text-transform: uppercase; }
            .row { display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 15px; }
            .amount-box { font-size: 22px; font-weight: bold; text-align: center; margin: 25px 0; border: 2px dashed #000; padding: 15px; background-color: #f9f9f9; }
            .footer { text-align: center; font-size: 13px; margin-top: 50px; color: #555; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1 class="title">${shopName}</h1>
            <div>${shopAddress}</div>
            <div>Phone: ${shopPhone}</div>
            <h3 style="margin-top: 20px; text-decoration: underline;">PAYMENT RECEIPT</h3>
          </div>
          <div class="row">
            <span><strong>Date:</strong> ${new Date(receiptData.date).toLocaleDateString('en-IN')}</span>
            <span><strong>Receipt No:</strong> REC-${Date.now().toString().slice(-6)}</span>
          </div>
          <div class="row">
            <span><strong>Customer:</strong> ${receiptData.customerName}</span>
            <span><strong>Phone:</strong> ${receiptData.customerPhone}</span>
          </div>
          <div class="amount-box">
            Amount Received: ₹${Number(receiptData.amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
          <div class="row">
            <span><strong>Payment Notes:</strong> ${receiptData.notes || '-'}</span>
          </div>
          <div class="row">
            <span><strong>Remaining Balance:</strong> ₹${Number(receiptData.balance).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
          </div>
          <div class="footer">
            Thank you for your business!<br><br><br>
            _________________________<br>
            Authorized Signatory
          </div>
        </body>
      </html>
    `;

    // Create a hidden window to process the print job
    let printWindow = new BrowserWindow({ show: false });
    
    // Load the HTML into the window safely
    printWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`);

    // Once loaded, trigger the print dialog
    printWindow.webContents.on('did-finish-load', () => {
      printWindow.webContents.print({ silent: false }, (success, failureReason) => {
        if (!success) console.error('Print failed:', failureReason);
        printWindow.close();
      });
    });

    return { success: true };
  }));

  // Suppliers
  ipcMain.handle('suppliers:create', safe((payload) => supplierService.createSupplier(payload)));
  ipcMain.handle('suppliers:update', safe((id, payload) => supplierService.updateSupplier(id, payload)));
  ipcMain.handle('suppliers:getById', safe((id) => supplierService.getSupplierById(id)));
  ipcMain.handle('suppliers:list', safe((search) => supplierService.listSuppliers(search)));
  ipcMain.handle('suppliers:ledger', safe((id) => supplierService.getSupplierLedger(id)));
  ipcMain.handle('suppliers:recordPayment', safe((payload) => supplierService.recordSupplierPayment(payload)));
  // Wire up your payment function
  ipcMain.handle('suppliers:makePayment', safe((payload) => supplierService.recordSupplierPayment(payload)));
  ipcMain.handle('suppliers:delete', safe((id) => supplierService.deleteSupplier(id)));

 // Purchases
  ipcMain.handle('purchases:create', safe((payload) => purchaseService.createPurchase(payload)));
  ipcMain.handle('purchases:getById', safe((id) => purchaseService.getPurchaseById(id)));
  ipcMain.handle('purchases:list', safe((filters) => purchaseService.listPurchases(filters || {})));

  // Artisans
  ipcMain.handle('artisans:create', safe((payload) => artisanService.createArtisan(payload)));
  ipcMain.handle('artisans:list', safe((search) => artisanService.listArtisans(search)));
  ipcMain.handle('artisans:getById', safe((id) => artisanService.getArtisanById(id)));
  ipcMain.handle('artisans:delete', safe((id) => artisanService.deleteArtisan(id)));
  ipcMain.handle('artisans:issueMetal', safe((payload) => artisanService.issueMetal(payload)));
  ipcMain.handle('artisans:pay', safe((payload) => artisanService.payArtisan(payload)));
  ipcMain.handle('artisans:metalLedger', safe((id) => artisanService.getMetalLedger(id)));
  ipcMain.handle('artisans:cashLedger', safe((id) => artisanService.getCashLedger(id)));
  ipcMain.handle('artisans:receiveGoods', safe((payload) => artisanService.receiveFinishedGoods(payload)));
  ipcMain.handle('artisans:listJobs', safe(() => artisanService.listJobs()));
  ipcMain.handle('artisans:issueJob', safe((payload) => artisanService.issueJob(payload)));
  ipcMain.handle('artisans:lossReport', safe((filters) => artisanService.lossReport(filters)));

  // Old Gold Exchange
  ipcMain.handle('oldgold:create', safe((payload) => oldGoldService.createExchange(payload)));
  ipcMain.handle('oldgold:list', safe((filters) => oldGoldService.listExchanges(filters)));
  ipcMain.handle('oldgold:pendingForCustomer', safe((customerId) => oldGoldService.listPendingExchangesForCustomer(customerId)));
  ipcMain.handle('oldgold:settleCash', safe((id, payload) => oldGoldService.settleForCash(id, payload)));

  // Repairs
  ipcMain.handle('repairs:create', safe((payload) => repairService.createRepair(payload)));
  ipcMain.handle('repairs:update', safe((id, payload) => repairService.updateRepair(id, payload)));
  ipcMain.handle('repairs:getById', safe((id) => repairService.getRepairById(id)));
  ipcMain.handle('repairs:list', safe((filters) => repairService.listRepairs(filters)));
  ipcMain.handle('repairs:listPhotos', safe((repairId) => repairService.listRepairPhotos(repairId)));
  ipcMain.handle('repairs:addPhoto', safe((repairId, filePath, caption) => repairService.addRepairPhoto(repairId, filePath, caption)));
  ipcMain.handle('repairs:statusHistory', safe((repairId) => repairService.listStatusHistory(repairId)));
  ipcMain.handle('repairs:addStatus', safe((repairId, status, note, changedBy) => repairService.addStatusHistory(repairId, status, note, changedBy)));

  // Billing
  ipcMain.handle('billing:create', safe((payload) => billingService.createInvoice(payload)));
  ipcMain.handle('billing:compute', safe((payload) => billingService.computeInvoice(payload)));
  ipcMain.handle('billing:getById', safe((id) => billingService.getInvoiceById(id)));
  ipcMain.handle('billing:list', safe((filters) => billingService.listInvoices(filters)));
  ipcMain.handle('billing:cancel', safe((id, reason) => billingService.cancelInvoice(id, reason)));
  ipcMain.handle('billing:printPdf', safe(async (invoiceId) => {
    const result = await invoicePdfService.generateInvoicePdf(invoiceId);
    shell.openPath(result.path);
    return result;
  }));
  ipcMain.handle('billing:savePdf', safe(async (invoiceId, destPath) => invoicePdfService.generateInvoicePdf(invoiceId, destPath)));

  // Reports
  ipcMain.handle('reports:salesRegister', safe((from, to) => reportService.salesRegister(from, to)));
  ipcMain.handle('reports:salesSummary', safe((from, to) => reportService.salesSummary(from, to)));
  ipcMain.handle('reports:gstSummary', safe((from, to) => reportService.gstSummary(from, to)));
  ipcMain.handle('reports:stockSummary', safe(() => reportService.stockSummary()));
  ipcMain.handle('reports:outstandingCustomers', safe(() => reportService.outstandingCustomerDues()));
  ipcMain.handle('reports:outstandingSuppliers', safe(() => reportService.outstandingSupplierDues()));
  ipcMain.handle('reports:outstandingKarigars', safe(() => reportService.outstandingKarigarDues()));
  ipcMain.handle('reports:dailyTrend', safe((from, to) => reportService.dailySalesTrend(from, to)));
  ipcMain.handle('reports:topCategories', safe((from, to) => reportService.topSellingCategories(from, to)));
  ipcMain.handle('reports:dashboard', safe(() => reportService.dashboardSnapshot()));

  // Backup / Restore
  ipcMain.handle('backup:now', safe(() => backupService.backupNow()));
  ipcMain.handle('backup:saveAs', safe(() => backupService.backupNowWithDialog(mainWindow)));
  ipcMain.handle('backup:restore', safe(() => backupService.restoreFromDialog(mainWindow)));

  // Notifications
  ipcMain.handle('notifications:sendWhatsapp', safe((invoiceId, phone) => notificationService.sendWhatsapp(invoiceId, phone)));
  ipcMain.handle('notifications:sendSms', safe((invoiceId, phone) => notificationService.sendSms(invoiceId, phone)));

  // System / External Links
  ipcMain.handle('open-external-url', safe(async (url) => {
    await shell.openExternal(url);
    return true;
  }));
}


module.exports = { registerIpcHandlers };

ipcMain.handle('verify-admin', async (event, password) => {
  try {
    const isValid = authService.verifyAdminPassword(password); 
    return { success: isValid };
  } catch (error) {
    return { success: false, error: error.message };
  }
});