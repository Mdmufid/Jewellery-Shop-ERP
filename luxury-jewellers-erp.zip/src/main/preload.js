const { contextBridge, ipcRenderer } = require('electron');

/**
 * Every IPC call returns { ok, data } or { ok:false, error }. This wrapper
 * unwraps that envelope so renderer code can simply `await window.api.x()`
 * and `try/catch` around real business errors (e.g. "insufficient stock").
 */
function invoke(channel) {
  return async (...args) => {
    const result = await ipcRenderer.invoke(channel, ...args);
    if (!result || result.ok === undefined) return result;
    if (!result.ok) throw new Error(result.error);
    return result.data;
  };
}

contextBridge.exposeInMainWorld('api', {
  auth: {
    login: invoke('auth:login'),
    verifyAdmin: (password) => ipcRenderer.invoke('verify-admin', password),
    listUsers: invoke('auth:listUsers'),
    createUser: invoke('auth:createUser'),
    changePassword: invoke('auth:changePassword'),
    resetPassword: invoke('auth:resetPassword'),
    setUserActive: invoke('auth:setUserActive'),
  },
  system: {
    openExternal: (url) => ipcRenderer.invoke('open-external-url', url)
  },
  settings: {
    getAll: invoke('settings:getAll'),
    update: invoke('settings:update'),
    listCategories: invoke('settings:listCategories'),
    createCategory: invoke('settings:createCategory'),
    listHsnCodes: invoke('settings:listHsnCodes'),
    updateHsnRate: invoke('settings:updateHsnRate'),
  },
  rates: {
    listPurities: invoke('rates:listPurities'),
    getCurrent: invoke('rates:getCurrent'),
    set: invoke('rates:set'),
    history: invoke('rates:history'),
    // ADD THIS NEW LINE:
    fetchIBJA: () => ipcRenderer.invoke('rates:fetchIBJA'),
  },
  inventory: {
    create: invoke('inventory:create'),
    update: invoke('inventory:update'),
    getById: invoke('inventory:getById'),
    getByCode: invoke('inventory:getByCode'),
    list: invoke('inventory:list'),
    delete: invoke('inventory:delete'),
    ledger: invoke('inventory:ledger'),
    valuation: invoke('inventory:valuation'),
    createAudit: invoke('inventory:createAudit'),
    getAudit: invoke('inventory:getAudit'),
    listAudits: invoke('inventory:listAudits'),
    saveAuditItems: invoke('inventory:saveAuditItems'),
    completeAudit: invoke('inventory:completeAudit'),
    printAudit: invoke('inventory:printAudit'),
  },
  customers: {
    create: invoke('customers:create'),
    update: invoke('customers:update'),
    getById: invoke('customers:getById'),
    list: invoke('customers:list'),
    ledger: invoke('customers:ledger'),
    // Add the new payment line below using your existing pattern:
    receivePayment: invoke('customers:receivePayment'),
    printReceipt: invoke('customers:printReceipt'),
  },
  suppliers: {
    create: invoke('suppliers:create'),
    update: invoke('suppliers:update'),
    getById: invoke('suppliers:getById'),
    list: invoke('suppliers:list'),
    ledger: invoke('suppliers:ledger'),
    recordPayment: invoke('suppliers:recordPayment'),
    makePayment: invoke('suppliers:makePayment'),
    delete: invoke('suppliers:delete'),
  },
 purchases: {
    create: invoke('purchases:create'),
    getById: invoke('purchases:getById'),
    list: invoke('purchases:list'),
  },
  artisans: {
    create: invoke('artisans:create'),
    list: invoke('artisans:list'),
    getById: invoke('artisans:getById'),
    delete: invoke('artisans:delete'),
    issueMetal: invoke('artisans:issueMetal'),
    pay: invoke('artisans:pay'),
    metalLedger: invoke('artisans:metalLedger'),
    cashLedger: invoke('artisans:cashLedger'),
    receiveGoods: invoke('artisans:receiveGoods'),
    
    // These three were from your old Karigar file, so we expose them too:
    listJobs: invoke('artisans:listJobs'),
    issueJob: invoke('artisans:issueJob'),
    lossReport: invoke('artisans:lossReport')
  },
  oldGold: {
    create: invoke('oldgold:create'),
    list: invoke('oldgold:list'),
    pendingForCustomer: invoke('oldgold:pendingForCustomer'),
    settleForCash: invoke('oldGold:settleForCash'),
  },
  repairs: {
    create: invoke('repairs:create'),
    update: invoke('repairs:update'),
    getById: invoke('repairs:getById'),
    list: invoke('repairs:list'),
    listPhotos: invoke('repairs:listPhotos'),
    addPhoto: invoke('repairs:addPhoto'),
    statusHistory: invoke('repairs:statusHistory'),
    addStatus: invoke('repairs:addStatus'),
  },
  billing: {
    create: invoke('billing:create'),
    compute: invoke('billing:compute'),
    getById: invoke('billing:getById'),
    list: invoke('billing:list'),
    cancel: invoke('billing:cancel'),
    printPdf: invoke('billing:printPdf'),
    savePdf: invoke('billing:savePdf'),
  },
  notifications: {
    sendWhatsapp: invoke('notifications:sendWhatsapp'),
    sendSms: invoke('notifications:sendSms'),
  },
  reports: {
    salesRegister: invoke('reports:salesRegister'),
    salesSummary: invoke('reports:salesSummary'),
    gstSummary: invoke('reports:gstSummary'),
    stockSummary: invoke('reports:stockSummary'),
    outstandingCustomers: invoke('reports:outstandingCustomers'),
    outstandingSuppliers: invoke('reports:outstandingSuppliers'),
    outstandingKarigars: invoke('reports:outstandingKarigars'),
    dailyTrend: invoke('reports:dailyTrend'),
    topCategories: invoke('reports:topCategories'),
    dashboard: invoke('reports:dashboard'),
  },
  backup: {
    now: invoke('backup:now'),
    saveAs: invoke('backup:saveAs'),
    restore: invoke('backup:restore'),
  },
});
