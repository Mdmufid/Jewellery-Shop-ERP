const path = require('path');
const { app, BrowserWindow, Menu, dialog } = require('electron');
const log = require('electron-log');

const { initDatabase } = require('./database/db');
const { registerIpcHandlers } = require('./ipc/ipcHandlers');
const backupService = require('./services/backupService');

log.initialize?.();
log.info('Luxury Jewellers ERP starting...');

const isDev = process.env.NODE_ENV === 'development';
let mainWindow = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1100,
    minHeight: 700,
    backgroundColor: '#0b0b0d',
    icon: path.join(__dirname, '..', '..', 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
    show: false,
  });

  mainWindow.once('ready-to-show', () => mainWindow.show());

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  } else {
    mainWindow.loadFile(path.join(__dirname, '..', '..', 'renderer', 'dist', 'index.html'));
  }

  buildMenu();
}

function buildMenu() {
  const template = [
    {
      label: 'File',
      submenu: [
        {
          label: 'Backup Now (Save As...)',
          click: async () => {
            const result = await backupService.backupNowWithDialog(mainWindow);
            if (!result.canceled) {
              dialog.showMessageBox(mainWindow, { message: `Backup saved to:\n${result.path}` });
            }
          },
        },
        {
          label: 'Restore From Backup...',
          click: async () => {
            const confirm = await dialog.showMessageBox(mainWindow, {
              type: 'warning',
              buttons: ['Cancel', 'Restore'],
              defaultId: 0,
              message: 'Restoring will replace all current data with the backup file. A safety copy of your current data will be kept. The app will need to restart. Continue?',
            });
            if (confirm.response !== 1) return;
            const result = await backupService.restoreFromDialog(mainWindow);
            if (!result.canceled) {
              dialog.showMessageBox(mainWindow, { message: 'Restore complete. The application will now restart.' })
                .then(() => { app.relaunch(); app.exit(0); });
            }
          },
        },
        { type: 'separator' },
        { role: 'quit' },
      ],
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { role: 'resetZoom' },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

app.whenReady().then(() => {
  initDatabase();
  createWindow();
  registerIpcHandlers(mainWindow);
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

process.on('uncaughtException', (err) => {
  log.error('Uncaught exception:', err);
});
