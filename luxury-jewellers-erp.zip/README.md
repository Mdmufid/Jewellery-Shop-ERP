# Luxury Jewellers — Billing & Inventory Management System

A production-grade Windows desktop application for jewellery retail: GST-compliant
billing, inventory (with HUID/hallmark tracking), old-gold exchange, karigar
(goldsmith) job-work, gold savings schemes, supplier/purchase management, and
business reports — all running fully offline on a single local database.

Built with **Electron + React (Vite) + SQLite (better-sqlite3)**. All data stays
on your own PC. No internet connection or subscription is required to run it.

---

## 1. What's included

| Module | What it does |
|---|---|
| **Billing / POS** | Create GST tax invoices with live CGST/SGST/IGST calculation, per-item making charges & wastage, old-gold and scheme redemption as credit, split payments, PDF invoice printing |
| **Inventory** | Item master with gross/net weight, purity, stone details, HUID hallmark number, full stock ledger (audit trail), stock valuation at current rates |
| **Rate Master** | Daily gold/silver/platinum rate entry per purity, with history |
| **Customers** | Customer database and running account ledger |
| **Suppliers & Purchases** | Record purchase bills; each line automatically becomes inventory stock and updates the supplier's payable ledger |
| **Karigar / Job Work** | Issue raw metal to a goldsmith, receive the finished piece, automatic wastage calculation and making-charge payable tracking |
| **Old Gold Exchange** | Record customer trade-ins with tested purity and melting deduction, redeemable as invoice credit or cash settlement |
| **Repairs** | Track repair tokens, expected delivery dates, advance payments, ready/delivered status, and balance due |
| **Reports** | Sales register, GST (HSN-wise) summary for GSTR-1 filing, stock valuation, outstanding dues (customers/suppliers/karigars) |
| **Settings** | Shop profile & GSTIN, HSN/GST rate master, categories, staff user accounts with roles, backup & restore |

Every number in this app is computed from real formulas (see
`src/main/utils/gst.js` and `src/main/utils/pricing.js`) — there is no mock or
placeholder data. The only seeded data on first run is the **official CBIC HSN
codes and GST rates for jewellery (HSN 7113, 7108, 7106, 7118, 9988)** and
standard gold/silver/platinum purity definitions, so you can start billing
immediately. **Please verify the seeded GST rates against the current CBIC
notification for your state before going live** — rates are configurable in
Settings → Categories & HSN.

---

## 2. Project structure

```
luxury-jewellers-erp/
├── package.json                  # Electron + build config (electron-builder)
├── build/                        # Windows icon (icon.ico) used by the installer
├── src/main/                     # Electron main process (Node.js backend)
│   ├── main.js                   # App entry point, window & menu setup
│   ├── preload.js                # Secure contextBridge API exposed to the UI
│   ├── database/
│   │   ├── db.js                 # SQLite connection, schema load, seed data
│   │   └── schema.sql            # Full relational schema (all modules)
│   ├── services/                 # Business logic (one file per module)
│   │   ├── billingService.js     # Invoice creation, GST calc, stock/ledger updates
│   │   ├── inventoryService.js
│   │   ├── purchaseService.js
│   │   ├── karigarService.js
│   │   ├── oldGoldService.js
│   │   ├── customerService.js
│   │   ├── supplierService.js
│   │   ├── rateService.js
│   │   ├── reportService.js
│   │   ├── settingsService.js
│   │   ├── authService.js
│   │   ├── backupService.js
│   │   └── invoicePdfService.js  # PDF tax invoice generation (pdfkit)
│   ├── ipc/ipcHandlers.js        # Registers all ipcMain.handle channels
│   └── utils/                    # gst.js, pricing.js, numberSequence.js
└── renderer/                     # React front-end (Vite)
    ├── index.html
    └── src/
        ├── main.jsx, App.jsx
        ├── context/               # AuthContext, ToastContext
        ├── components/            # Layout, Modal
        ├── styles/theme.css       # Luxury black & gold design system
        └── pages/                 # One folder per module (Billing, Inventory, ...)
```

---

## 3. Prerequisites

- **Node.js 20 LTS** (or later) — https://nodejs.org
- **Windows 10/11** for building the final installer (or build on any OS and
  hand the `release/` output to a Windows machine — see note below)
- Because this app uses `better-sqlite3`, a **native Node module**, on Windows
  you need either:
  - Visual Studio Build Tools (Desktop development with C++ workload), or
  - simply let `npm install` download a prebuilt binary automatically (works
    for most standard Node versions without any extra setup)

> **Note on cross-compiling:** `better-sqlite3` must be compiled/fetched for
> the exact platform you will run the app on. Run `npm install` **on the
> Windows machine** (or use `electron-builder install-app-deps` after
> installing) so the correct native binary is fetched — don't copy
> `node_modules` from macOS/Linux to Windows.

---

## 4. Getting started (development)

```bash
cd luxury-jewellers-erp
npm install
npm run dev
```

This starts the Vite dev server and launches Electron pointed at it, with
hot-reload for the UI. The SQLite database is created automatically on first
launch at:

```
%APPDATA%\luxury-jewellers-erp\data\luxury_jewellers.db
```

### Default login

```
Username: admin
Password: admin123
```

**Change this password immediately** after first login via
Settings → Users → Change My Password.

---

## 5. Building the Windows installer

```bash
npm install
npm run dist:win
```

This runs `vite build` (renderer) followed by `electron-builder`, producing a
signed-ready NSIS installer at:

```
release/Luxury Jewellers Setup <version>.exe
```

Double-click it on any Windows 10/11 PC to install. It creates a desktop
shortcut and Start Menu entry. Uninstalling is available from
Windows Settings → Apps, same as any other application.

To just produce an unpacked test build without an installer:

```bash
npm run pack
```

---

## 6. Day-to-day operations

### Setting today's rate
Go to **Rate Master** every morning and enter the day's gold/silver rate per
gram for each purity before billing. Billing always uses the latest rate
effective on or before the invoice date.

### Making a sale
**Billing / POS** → search/scan the item → adjust rate/making/wastage if
needed → optionally attach a customer or old-gold exchange credit → record payment → **Complete Sale**. A PDF tax invoice can
be printed immediately from the invoice detail page.

### Backups
**Settings → Backup & Restore → Backup Now**. Point the destination at an
external drive or a cloud-synced folder (Google Drive/OneDrive desktop app)
for off-site safety. Restoring keeps an automatic safety copy of your current
data before overwriting anything, and the app will need a restart afterward.
Backups are also reachable from the **File** menu.

### Financial year numbering
Invoice/purchase/job/exchange numbers automatically reset on 1 April each
year (Indian financial year), formatted like `INV/2526/00001`.

---

## 7. Compliance notes

This app computes GST (CGST/SGST/IGST) based on the HSN codes and rates
configured in Settings, and determines intra-state vs inter-state supply by
comparing your shop's registered state code with the customer's/place-of-
supply state code. It also supports capturing the **BIS HUID** hallmark
number per item as required for hallmarked jewellery sales in India.

This software is a billing/inventory **tool**, not a tax advisor. Please have
your CA/GST practitioner verify HSN codes, tax rates, and invoice format
against current CBIC notifications applicable to your state before relying on
it for GST filing.

---

## 8. Support / extending the app

All business logic lives in `src/main/services/*.js` as plain, well-commented
functions — no framework magic — so it's straightforward for any Node.js
developer to extend (e.g. add e-way bill generation, SMS/WhatsApp invoice
delivery, multi-branch sync, etc.) without needing to touch the UI layer.
